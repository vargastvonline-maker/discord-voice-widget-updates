const MESSAGE_LIMITS = Object.freeze({
  text: Object.freeze({
    key: 'text',
    label: 'Mensagem rápida',
    maxBytes: 2 * 1024
  }),
  link: Object.freeze({
    key: 'link',
    label: 'Link',
    maxBytes: 2 * 1024
  }),
  prompt: Object.freeze({
    key: 'prompt',
    label: 'Prompt',
    maxBytes: 32 * 1024
  })
});

const ACTIVE_MAX_FRAME_BYTES = 64 * 1024;
const ACTIVE_RATE_BYTE_LIMIT = 128 * 1024;
const ACTIVE_RATE_WINDOW_MS = 10_000;
const ACTIVE_RATE_MESSAGE_LIMIT = 20;

const FUTURE_PROMPT_64K = Object.freeze({
  enabled: false,
  maxBytes: 64 * 1024,
  recommendedFrameBytes: 128 * 1024,
  note: 'Reservado para avaliacao futura. Nao ativar sem novos testes e aprovacao.'
});

function payloadLimitForType(type) {
  return MESSAGE_LIMITS[type]?.maxBytes ?? null;
}

function utf8ByteLength(value) {
  const text = String(value ?? '');

  if (typeof Buffer !== 'undefined' && typeof Buffer.byteLength === 'function') {
    return Buffer.byteLength(text, 'utf8');
  }

  if (typeof TextEncoder !== 'undefined') {
    return new TextEncoder().encode(text).length;
  }

  throw new Error('No UTF-8 byte counter is available in this runtime.');
}

function payloadUsage(type, value) {
  const maxBytes = payloadLimitForType(type);
  if (!maxBytes) {
    return {
      type,
      bytes: utf8ByteLength(value),
      maxBytes: 0,
      ratio: 1,
      percent: 100,
      overLimit: true
    };
  }

  const bytes = utf8ByteLength(value);
  const ratio = Math.min(1, bytes / maxBytes);

  return {
    type,
    bytes,
    maxBytes,
    ratio,
    percent: Math.round(ratio * 100),
    overLimit: bytes > maxBytes
  };
}

const api = {
  MESSAGE_LIMITS,
  ACTIVE_MAX_FRAME_BYTES,
  ACTIVE_RATE_BYTE_LIMIT,
  ACTIVE_RATE_WINDOW_MS,
  ACTIVE_RATE_MESSAGE_LIMIT,
  FUTURE_PROMPT_64K,
  payloadLimitForType,
  utf8ByteLength,
  payloadUsage
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = api;
}

if (typeof window !== 'undefined') {
  window.CensoredFlowLimits = api;
}
