const fs = require('fs');
const http = require('http');
const path = require('path');
const { senderKeyFor } = require('../service/notification-controller');

const MAX_HTTP_BODY_BYTES = 40 * 1024;

function json(res, statusCode, value) {
  const body = JSON.stringify(value);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function text(res, statusCode, value, contentType = 'text/plain; charset=utf-8') {
  res.writeHead(statusCode, {
    'Content-Type': contentType,
    'Content-Length': Buffer.byteLength(value),
    'Cache-Control': 'no-store'
  });
  res.end(value);
}

function readJsonBody(req, maxBytes = MAX_HTTP_BODY_BYTES) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;

    req.on('data', (chunk) => {
      total += chunk.length;
      if (total > maxBytes) {
        const error = new Error('HTTP body too large.');
        error.code = 'HTTP_BODY_TOO_LARGE';
        reject(error);
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });

    req.on('end', () => {
      try {
        const raw = Buffer.concat(chunks).toString('utf8');
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        const error = new Error('Invalid JSON.');
        error.code = 'INVALID_JSON';
        reject(error);
      }
    });

    req.on('error', reject);
  });
}

function createUiServer({
  bridge,
  notifications = null,
  identityLinker = null,
  host = '127.0.0.1',
  port = 0,
  rendererDir = path.join(__dirname, 'renderer'),
  limitsFile = path.resolve(__dirname, '..', 'protocol', 'limits.js')
}) {
  if (host !== '127.0.0.1') {
    throw new Error('Lab UI server is restricted to 127.0.0.1.');
  }

  const eventClients = new Set();

  function broadcast(eventName, value) {
    const payload = `event: ${eventName}\ndata: ${JSON.stringify(value)}\n\n`;
    for (const res of eventClients) {
      try { res.write(payload); } catch {}
    }
  }

  const onMessage = (message) => broadcast('message', message);
  const onStatus = (state) => broadcast('status', state);
  const onRejected = (event) => broadcast('rejected', event);
  const onRelayError = (event) => broadcast('relay-error', event);
  const onNotify = (value) => broadcast('notification', value);
  const onNotificationOpen = (value) => broadcast('notification-open', {
    id: value?.id || null,
    senderKey: value ? senderKeyFor(value) : null
  });
  const onConversationOpen = (value) => broadcast('conversation-open', value);
  const onNotificationDismiss = (value) => broadcast('notification-dismiss', {
    id: value?.id || null,
    senderKey: value ? senderKeyFor(value) : null
  });
  const onExpired = (value) => broadcast('message-expired', value);
  const onUnread = (value) => broadcast('unread', value);

  bridge.on('message', onMessage);
  bridge.on('status', onStatus);
  bridge.on('rejected', onRejected);
  bridge.on('relayError', onRelayError);

  notifications?.on('notify', onNotify);
  notifications?.on('open', onNotificationOpen);
  notifications?.on('conversationOpen', onConversationOpen);
  notifications?.on('dismiss', onNotificationDismiss);
  notifications?.on('expired', onExpired);
  notifications?.on('unread', onUnread);

  const staticFiles = new Map([
    ['/', { file: 'index.html', type: 'text/html; charset=utf-8' }],
    ['/index.html', { file: 'index.html', type: 'text/html; charset=utf-8' }],
    ['/app.js', { file: 'app.js', type: 'text/javascript; charset=utf-8' }],
    ['/styles.css', { file: 'styles.css', type: 'text/css; charset=utf-8' }],
    ['/notification.html', { file: 'notification.html', type: 'text/html; charset=utf-8' }],
    ['/notification.js', { file: 'notification.js', type: 'text/javascript; charset=utf-8' }],
    ['/notification.css', { file: 'notification.css', type: 'text/css; charset=utf-8' }]
  ]);

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1');

    if (req.method === 'GET' && staticFiles.has(url.pathname)) {
      const entry = staticFiles.get(url.pathname);
      const value = fs.readFileSync(path.join(rendererDir, entry.file), 'utf8');
      return text(res, 200, value, entry.type);
    }

    if (req.method === 'GET' && url.pathname === '/limits.js') {
      return text(
        res,
        200,
        fs.readFileSync(limitsFile, 'utf8'),
        'text/javascript; charset=utf-8'
      );
    }

    if (req.method === 'GET' && url.pathname === '/api/state') {
      return json(res, 200, bridge.snapshot());
    }

    if (req.method === 'GET' && url.pathname === '/api/notification') {
      return json(res, 200, {
        ok: true,
        current: notifications?.current() || null,
        pendingCount: notifications?.pendingCount() || 0,
        unread: notifications?.unreadSummary() || []
      });
    }

    if (req.method === 'GET' && url.pathname === '/api/recipient/resolve') {
      const discordUserId = String(url.searchParams.get('discordUserId') || '').trim();
      const recipient = await bridge.resolveRecipientByDiscordUserId?.(discordUserId) || null;
      return json(res, 200, {
        ok: true,
        available: Boolean(recipient),
        recipient
      });
    }

    if (req.method === 'POST' && url.pathname === '/api/conversation/start') {
      try {
        const body = await readJsonBody(req, 4 * 1024);
        const discordUserId = String(body?.discordUserId || '').trim();
        const recipient = await bridge.startConversationByDiscordUserId?.(discordUserId) || null;

        if (!recipient) {
          return json(res, 404, {
            ok: false,
            code: 'RECIPIENT_NOT_LINKED',
            message: 'Participante ainda não está disponível no CensoredFlow Messaging.'
          });
        }

        const senderKey = senderKeyFor({ sender: recipient });
        const event = { senderKey, sender: recipient };
        broadcast('conversation-start', event);

        return json(res, 200, {
          ok: true,
          senderKey,
          recipient
        });
      } catch (error) {
        return json(res, 400, {
          ok: false,
          code: error.code || 'START_CONVERSATION_FAILED',
          message: error.message || 'Falha ao iniciar conversa.'
        });
      }
    }

    if (req.method === 'GET' && url.pathname === '/events') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-store',
        'Connection': 'keep-alive'
      });
      res.write(`event: status\ndata: ${JSON.stringify(bridge.snapshot())}\n\n`);

      const unread = notifications?.unreadSummary() || [];
      res.write(`event: unread\ndata: ${JSON.stringify(unread)}\n\n`);

      const current = notifications?.current();
      if (current) {
        res.write(`event: notification\ndata: ${JSON.stringify(current)}\n\n`);
      }

      eventClients.add(res);
      req.on('close', () => eventClients.delete(res));
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/send') {
      try {
        const body = await readJsonBody(req);
        const mode = body.mode === 'prompt' ? 'prompt' : 'text';
        const payload = typeof body.payload === 'string' ? body.payload : '';

        if (!payload.trim()) {
          return json(res, 400, {
            ok: false,
            code: 'EMPTY_PAYLOAD',
            message: 'Mensagem vazia.'
          });
        }

        const result = await bridge.send({ mode, payload });
        return json(res, 200, { ok: true, ...result });
      } catch (error) {
        return json(res, 400, {
          ok: false,
          code: error.code || 'SEND_FAILED',
          message: error.message || 'Falha ao enviar.'
        });
      }
    }

    if (req.method === 'POST' && url.pathname === '/api/notification/open') {
      const item = notifications?.openCurrent() || null;
      return json(res, item ? 200 : 404, {
        ok: Boolean(item),
        id: item?.id || null,
        senderKey: item ? senderKeyFor(item) : null
      });
    }

    if (req.method === 'POST' && url.pathname === '/api/notification/dismiss') {
      const item = notifications?.dismissCurrent() || null;
      return json(res, item ? 200 : 404, {
        ok: Boolean(item),
        id: item?.id || null
      });
    }

    if (req.method === 'POST' && url.pathname === '/api/identity/discord-link') {
      if (typeof identityLinker !== 'function') {
        return json(res, 404, {
          ok: false,
          code: 'IDENTITY_LINK_UNAVAILABLE'
        });
      }

      try {
        const body = await readJsonBody(req, 4 * 1024);
        const runningDiscordUserId = String(
          bridge.snapshot()?.self?.discordUserId || ''
        ).trim();

        const result = identityLinker({
          discordUserId: body?.discordUserId,
          displayName: body?.displayName,
          avatarUrl: body?.avatarUrl ?? null
        });

        const linkedDiscordUserId = String(
          result.profile.discord?.discordUserId || ''
        ).trim();

        return json(res, 200, {
          ok: true,
          status: result.status,
          userId: result.profile.userId,
          discordUserId: linkedDiscordUserId || null,
          restartRequired: typeof result.restartRequired === 'boolean'
            ? result.restartRequired
            : runningDiscordUserId !== linkedDiscordUserId
        });
      } catch (error) {
        const statusCode = error.code === 'DISCORD_LINK_CONFLICT' ? 409 : 400;
        return json(res, statusCode, {
          ok: false,
          code: error.code || 'DISCORD_LINK_FAILED',
          message: error.message || 'Falha ao vincular Discord.',
          existingDiscordUserId: error.existingDiscordUserId || null,
          incomingDiscordUserId: error.incomingDiscordUserId || null
        });
      }
    }

    if (req.method === 'POST' && url.pathname === '/api/conversation/open') {
      try {
        const body = await readJsonBody(req, 4 * 1024);
        const senderKey = String(body?.senderKey || '').trim();

        if (!senderKey || senderKey.length > 200) {
          return json(res, 400, {
            ok: false,
            code: 'INVALID_SENDER_KEY'
          });
        }

        const items = notifications?.openConversationBySender(senderKey) || [];
        return json(res, items.length ? 200 : 404, {
          ok: items.length > 0,
          senderKey,
          openedCount: items.length,
          itemIds: items.map((item) => item.id)
        });
      } catch (error) {
        return json(res, 400, {
          ok: false,
          code: error.code || 'OPEN_CONVERSATION_FAILED',
          message: error.message || 'Falha ao abrir conversa.'
        });
      }
    }

    json(res, 404, { ok: false, code: 'NOT_FOUND' });
  });

  return {
    server,
    async start() {
      await new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(port, host, () => {
          server.off('error', reject);
          resolve();
        });
      });

      const address = server.address();
      return {
        host,
        port: address.port,
        url: `http://${host}:${address.port}/`
      };
    },
    async stop() {
      bridge.off('message', onMessage);
      bridge.off('status', onStatus);
      bridge.off('rejected', onRejected);
      bridge.off('relayError', onRelayError);

      notifications?.off('notify', onNotify);
      notifications?.off('open', onNotificationOpen);
      notifications?.off('conversationOpen', onConversationOpen);
      notifications?.off('dismiss', onNotificationDismiss);
      notifications?.off('expired', onExpired);
      notifications?.off('unread', onUnread);

      for (const res of eventClients) {
        try { res.end(); } catch {}
      }
      eventClients.clear();

      await new Promise((resolve) => server.close(() => resolve()));
    }
  };
}

module.exports = {
  MAX_HTTP_BODY_BYTES,
  createUiServer
};
