const crypto = require('crypto');
const {
  DEFAULT_TTL_MS,
  createExpiry
} = require('../service/ttl');
const { isValidDeviceId } = require('../service/identity');
const { isValidUserId } = require('../service/user-profile');
const {
  MESSAGE_LIMITS,
  payloadLimitForType,
  utf8ByteLength
} = require('./limits');

const SCHEMA_VERSION = 2;
const MESSAGE_TYPES = Object.freeze(Object.keys(MESSAGE_LIMITS));

function assertPayload(type, payload) {
  if (!MESSAGE_TYPES.includes(type)) {
    throw new TypeError(`Unsupported message type: ${type}`);
  }
  if (typeof payload !== 'string' || payload.trim().length === 0) {
    throw new TypeError('payload must be a non-empty string.');
  }

  const maxBytes = payloadLimitForType(type);
  const payloadBytes = utf8ByteLength(payload);
  if (payloadBytes > maxBytes) {
    throw new RangeError(
      `payload exceeds ${maxBytes} UTF-8 bytes for message type ${type}.`
    );
  }

  if (type === 'link') {
    let url;
    try {
      url = new URL(payload.trim());
    } catch {
      throw new TypeError('link payload must be a valid URL.');
    }
    if (url.protocol !== 'https:' && url.protocol !== 'http:') {
      throw new TypeError('link payload must use http or https.');
    }
  }
}

function createMessage({
  fromUser,
  fromDevice,
  toUser,
  type,
  payload,
  ttlMs = DEFAULT_TTL_MS,
  now = Date.now(),
  id = crypto.randomUUID(),
  signature = null
}) {
  if (!isValidUserId(fromUser)) {
    throw new TypeError('fromUser must be a valid CensoredFlow User ID.');
  }
  if (!isValidDeviceId(fromDevice)) {
    throw new TypeError('fromDevice must be a valid CensoredFlow Device ID.');
  }
  if (!isValidUserId(toUser)) {
    throw new TypeError('toUser must be a valid CensoredFlow User ID.');
  }
  if (fromUser === toUser) {
    throw new TypeError('fromUser and toUser must identify different users in this POC.');
  }
  if (typeof id !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) {
    throw new TypeError('id must be a UUID v4 string.');
  }

  assertPayload(type, payload);

  if (signature !== null && typeof signature !== 'string') {
    throw new TypeError('signature must be null or a base64 string.');
  }

  const createdAt = now;
  const expiresAt = createExpiry(createdAt, ttlMs);

  return Object.freeze({
    schemaVersion: SCHEMA_VERSION,
    id,
    fromUser,
    fromDevice,
    toUser,
    type,
    createdAt,
    expiresAt,
    payload: type === 'link' ? payload.trim() : payload,
    signature
  });
}

function signingPayload(message) {
  const canonical = {
    schemaVersion: message.schemaVersion,
    id: message.id,
    fromUser: message.fromUser,
    fromDevice: message.fromDevice,
    toUser: message.toUser,
    type: message.type,
    createdAt: message.createdAt,
    expiresAt: message.expiresAt,
    payload: message.payload
  };
  return Buffer.from(JSON.stringify(canonical), 'utf8');
}

function signMessage(message, privateKey) {
  const signature = crypto.sign(null, signingPayload(message), privateKey).toString('base64');
  return Object.freeze({
    ...message,
    signature
  });
}

function verifyMessageSignature(message, publicKey) {
  if (!message || typeof message.signature !== 'string' || !message.signature) return false;

  let signature;
  try {
    signature = Buffer.from(message.signature, 'base64');
  } catch {
    return false;
  }

  try {
    return crypto.verify(null, signingPayload(message), publicKey, signature);
  } catch {
    return false;
  }
}

module.exports = {
  SCHEMA_VERSION,
  MESSAGE_TYPES,
  MESSAGE_LIMITS,
  createMessage,
  signingPayload,
  signMessage,
  verifyMessageSignature
};
