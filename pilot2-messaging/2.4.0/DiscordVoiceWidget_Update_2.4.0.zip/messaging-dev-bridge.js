const http = require('http');
const { EventEmitter } = require('events');

function requestJson({
  host = '127.0.0.1',
  port,
  path,
  method = 'GET',
  body = null,
  timeoutMs = 1200
}) {
  return new Promise((resolve, reject) => {
    const payload = body == null ? null : JSON.stringify(body);
    const req = http.request({
      host,
      port,
      path,
      method,
      headers: payload ? {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload)
      } : undefined
    }, (res) => {
      const chunks = [];
      res.on('data', (chunk) => chunks.push(chunk));
      res.on('end', () => {
        const raw = Buffer.concat(chunks).toString('utf8');
        let value = null;
        try { value = raw ? JSON.parse(raw) : null; }
        catch {
          const error = new Error('Messaging Lab returned invalid JSON.');
          error.code = 'INVALID_JSON';
          reject(error);
          return;
        }

        if (res.statusCode < 200 || res.statusCode >= 300) {
          const error = new Error(value?.message || value?.code || ('HTTP ' + res.statusCode));
          error.code = value?.code || 'HTTP_ERROR';
          error.statusCode = res.statusCode;
          reject(error);
          return;
        }

        resolve(value);
      });
    });

    req.setTimeout(timeoutMs, () => {
      const error = new Error('Messaging Lab timeout.');
      error.code = 'TIMEOUT';
      req.destroy(error);
    });

    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

class MessagingDevBridge extends EventEmitter {
  constructor({
    host = '127.0.0.1',
    port = 39767,
    pollMs = 800
  } = {}) {
    super();
    this.host = host;
    this.port = port;
    this.pollMs = Math.max(400, Number(pollMs) || 800);
    this.timer = null;
    this.inFlight = false;
    this.lastUnreadJson = '';
    this.online = false;
  }

  get panelUrl() {
    return `http://${this.host}:${this.port}/`;
  }

  async pollOnce() {
    if (this.inFlight) return;
    this.inFlight = true;

    try {
      const state = await requestJson({
        host: this.host,
        port: this.port,
        path: '/api/notification'
      });

      const unread = Array.isArray(state?.unread) ? state.unread : [];
      const unreadJson = JSON.stringify(unread);
      const wasOnline = this.online;
      this.online = true;

      if (!wasOnline) this.emit('online', true);
      if (unreadJson !== this.lastUnreadJson) {
        this.lastUnreadJson = unreadJson;
        this.emit('unread', unread);
      }
    } catch (error) {
      if (this.online) {
        this.online = false;
        this.emit('online', false);
      }
      if (this.lastUnreadJson !== '[]') {
        this.lastUnreadJson = '[]';
        this.emit('unread', []);
      }
      this.emit('bridgeError', {
        code: error.code || 'BRIDGE_ERROR',
        message: error.message || String(error)
      });
    } finally {
      this.inFlight = false;
    }
  }

  start() {
    if (this.timer) return;
    this.pollOnce();
    this.timer = setInterval(() => this.pollOnce(), this.pollMs);
    this.timer.unref?.();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.inFlight = false;
  }

  async resolveRecipient(discordUserId) {
    const clean = String(discordUserId || '').trim();
    if (!/^\d{5,30}$/.test(clean)) {
      return { ok: true, available: false, recipient: null };
    }

    return requestJson({
      host: this.host,
      port: this.port,
      path: '/api/recipient/resolve?discordUserId=' + encodeURIComponent(clean)
    });
  }

  async startConversation(discordUserId) {
    const clean = String(discordUserId || '').trim();
    if (!/^\d{5,30}$/.test(clean)) {
      const error = new Error('Invalid Discord user id.');
      error.code = 'INVALID_DISCORD_USER_ID';
      throw error;
    }

    return requestJson({
      host: this.host,
      port: this.port,
      path: '/api/conversation/start',
      method: 'POST',
      body: { discordUserId: clean }
    });
  }

  async linkDiscordIdentity(identity) {
    const discordUserId = String(identity?.discordUserId || '').trim();
    const displayName = String(identity?.displayName || '').trim();
    const avatarUrl = identity?.avatarUrl == null
      ? null
      : String(identity.avatarUrl).trim();

    if (!/^\d{5,30}$/.test(discordUserId)) {
      const error = new Error('Invalid Discord user id.');
      error.code = 'INVALID_DISCORD_USER_ID';
      throw error;
    }
    if (!displayName || displayName.length > 100) {
      const error = new Error('Invalid Discord display name.');
      error.code = 'INVALID_DISCORD_DISPLAY_NAME';
      throw error;
    }

    return requestJson({
      host: this.host,
      port: this.port,
      path: '/api/identity/discord-link',
      method: 'POST',
      body: {
        discordUserId,
        displayName,
        avatarUrl: avatarUrl || null
      }
    });
  }

  async openConversation(senderKey) {
    const clean = String(senderKey || '').trim();
    if (!clean || clean.length > 200) {
      const error = new Error('Invalid senderKey.');
      error.code = 'INVALID_SENDER_KEY';
      throw error;
    }

    return requestJson({
      host: this.host,
      port: this.port,
      path: '/api/conversation/open',
      method: 'POST',
      body: { senderKey: clean }
    });
  }
}

module.exports = {
  requestJson,
  MessagingDevBridge
};
