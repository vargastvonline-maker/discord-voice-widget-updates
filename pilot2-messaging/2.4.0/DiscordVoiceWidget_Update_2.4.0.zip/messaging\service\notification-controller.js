const { EventEmitter } = require('events');
const { EphemeralInbox } = require('./inbox-buffer');

function previewText(value, maxChars = 120) {
  const clean = String(value || '').replace(/\s+/g, ' ').trim();
  if (clean.length <= maxChars) return clean;
  return clean.slice(0, Math.max(0, maxChars - 1)) + '…';
}

function senderKeyFor(item) {
  const sender = item?.sender || {};
  const discordUserId = String(sender.discordUserId || '').trim();
  if (discordUserId) return 'discord:' + discordUserId;

  const userId = String(sender.userId || '').trim();
  return userId ? 'cf:' + userId : 'unknown';
}

class NotificationController extends EventEmitter {
  constructor({
    bridge,
    inbox = new EphemeralInbox(),
    now = () => Date.now()
  }) {
    super();
    if (!bridge || typeof bridge.on !== 'function') {
      throw new TypeError('bridge is required.');
    }

    this.bridge = bridge;
    this.inbox = inbox;
    this.now = now;
    this.currentId = null;
    this.expiryTimer = null;

    this._onMessage = (message) => {
      if (this.inbox.push(message)) this._pump();
    };

    this._onInboxChange = () => {
      this.emit('unread', this.unreadSummary());

      if (!this.currentId) return;

      const stillPresent = this.inbox.snapshot().some(
        (item) => item.id === this.currentId
      );

      if (!stillPresent) {
        this._clearExpiryTimer();
        this.currentId = null;
        this._pump();
      }
    };

    bridge.on('message', this._onMessage);
    inbox.on('change', this._onInboxChange);
  }

  _clearExpiryTimer() {
    if (this.expiryTimer) clearTimeout(this.expiryTimer);
    this.expiryTimer = null;
  }

  _scheduleExpiry(item) {
    this._clearExpiryTimer();
    if (!item) return;

    const delay = Math.max(0, item.expiresAt - this.now());
    this.expiryTimer = setTimeout(() => {
      const expiredId = this.currentId;
      if (!expiredId) return;

      this._clearExpiryTimer();
      this.currentId = null;
      this.inbox.remove(expiredId);
      this.emit('expired', { id: expiredId });
      this._pump();
    }, Math.min(delay + 5, 2_147_483_647));
    this.expiryTimer.unref?.();
  }

  _publicView(item) {
    if (!item) return null;
    return {
      id: item.id,
      type: item.type,
      preview: previewText(item.payload),
      createdAt: item.createdAt,
      expiresAt: item.expiresAt,
      sender: item.sender
    };
  }

  unreadSummary() {
    const groups = new Map();
    const now = this.now();

    for (const item of this.inbox.snapshot()) {
      if (!item || !Number.isInteger(item.expiresAt) || now >= item.expiresAt) {
        continue;
      }

      const sender = item.sender || {};
      const key = senderKeyFor(item);
      const existing = groups.get(key) || {
        senderKey: key,
        count: 0,
        userId: sender.userId || null,
        discordUserId: sender.discordUserId || null,
        displayName: sender.displayName || sender.userId || 'CensoredFlow',
        avatarUrl: sender.avatarUrl || null,
        source: sender.source || 'censoredflow'
      };

      existing.count += 1;
      groups.set(key, existing);
    }

    return [...groups.values()];
  }

  _pump() {
    if (this.currentId) return this.current();
    const item = this.inbox.peek();
    if (!item) return null;

    this.currentId = item.id;
    this._scheduleExpiry(item);

    const view = this._publicView(item);
    this.emit('notify', view);
    return view;
  }

  current() {
    if (!this.currentId) return this._pump();

    const item = this.inbox.snapshot().find(
      (entry) => entry.id === this.currentId
    );

    if (!item || this.now() >= item.expiresAt) {
      const expiredId = this.currentId;
      this._clearExpiryTimer();
      this.currentId = null;
      if (item) this.inbox.remove(expiredId);
      return this._pump();
    }

    return this._publicView(item);
  }

  openCurrent() {
    const view = this.current();
    if (!view) return null;
    return this._openById(view.id);
  }

  openBySender(senderKey) {
    const cleanKey = String(senderKey || '').trim();
    if (!cleanKey) return null;

    const item = this.inbox.snapshot().find(
      (entry) => senderKeyFor(entry) === cleanKey && this.now() < entry.expiresAt
    );

    if (!item) return null;
    return this._openById(item.id);
  }

  openConversationBySender(senderKey) {
    const cleanKey = String(senderKey || '').trim();
    if (!cleanKey) return [];

    const snapshot = this.inbox.snapshot();
    const matchingIds = new Set(
      snapshot
        .filter((item) => senderKeyFor(item) === cleanKey && this.now() < item.expiresAt)
        .map((item) => item.id)
    );

    if (!matchingIds.size) return [];

    if (this.currentId && matchingIds.has(this.currentId)) {
      this._clearExpiryTimer();
      this.currentId = null;
    }

    const items = this.inbox.removeWhere((item) => matchingIds.has(item.id));
    if (!items.length) return [];

    this.emit('conversationOpen', {
      senderKey: cleanKey,
      itemIds: items.map((item) => item.id)
    });

    queueMicrotask(() => this._pump());
    return items;
  }

  _openById(id) {
    const wasCurrent = this.currentId === id;
    if (wasCurrent) {
      this._clearExpiryTimer();
      this.currentId = null;
    }

    const item = this.inbox.remove(id);
    if (!item) return null;

    this.emit('open', item);

    if (wasCurrent) {
      queueMicrotask(() => this._pump());
    }

    return item;
  }

  dismissCurrent() {
    const view = this.current();
    if (!view) return null;

    this._clearExpiryTimer();
    this.currentId = null;
    const item = this.inbox.remove(view.id);

    if (item) this.emit('dismiss', this._publicView(item));
    queueMicrotask(() => this._pump());
    return item;
  }

  pendingCount() {
    this.inbox.purgeExpired();
    return this.inbox.snapshot().length;
  }

  close() {
    this._clearExpiryTimer();
    this.bridge.off('message', this._onMessage);
    this.inbox.off('change', this._onInboxChange);
    this.currentId = null;
  }
}

module.exports = {
  previewText,
  senderKeyFor,
  NotificationController
};
