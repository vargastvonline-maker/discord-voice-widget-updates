const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('censoredFlowWindow', {
  reportLayout(layout) {
    const height = Number(layout?.height);
    ipcRenderer.send('dw-messaging-panel-layout', {
      height: Number.isFinite(height) ? height : 0,
      expanded: layout?.expanded === true
    });
  },

  hide() {
    ipcRenderer.send('dw-messaging-panel-hide');
  }
});
