const fs = require('fs');
const path = require('path');
const { EventEmitter } = require('events');

const {
  generateIdentity,
  writeIdentityDirectory,
  loadIdentityDirectory
} = require('./messaging/service/identity');
const {
  createUserProfile,
  authorizeDevice,
  isDeviceAuthorized,
  writeUserProfile,
  loadUserProfile,
  linkDiscordProfileFile
} = require('./messaging/service/user-profile');
const { MessagingTransport } = require('./messaging/service/transport');
const { MessagingService } = require('./messaging/service/messaging-service');
const { NotificationController } = require('./messaging/service/notification-controller');
const { MessagingBridge } = require('./messaging/bridge/messaging-bridge');
const { createUiServer } = require('./messaging/ui/ui-server');

function isLoopbackHost(hostname) {
  const value = String(hostname || '').toLowerCase();
  return value === '127.0.0.1' ||
    value === 'localhost' ||
    value === '[::1]' ||
    value === '::1';
}

function normalizeRelayUrl(raw) {
  const clean = String(raw || '').trim();
  if (!clean) return '';

  let url;
  try {
    url = new URL(clean);
  } catch {
    throw new Error('Messaging Relay URL is invalid.');
  }

  if (url.username || url.password) {
    throw new Error('Messaging Relay URL must not contain credentials.');
  }

  if (url.protocol === 'https:') url.protocol = 'wss:';
  if (url.protocol === 'http:' && isLoopbackHost(url.hostname)) url.protocol = 'ws:';

  if (url.protocol === 'ws:') {
    if (!isLoopbackHost(url.hostname)) {
      throw new Error('Unencrypted ws:// Messaging is allowed only on loopback.');
    }
  } else if (url.protocol !== 'wss:') {
    throw new Error('Messaging Relay URL must use wss://, or ws:// on loopback.');
  }

  if (!url.pathname || url.pathname === '/') {
    url.pathname = '/messaging';
  }

  return url.toString();
}

function readJsonIfExists(filePath) {
  try {
    if (!fs.existsSync(filePath)) return {};
    const value = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return value && typeof value === 'object' ? value : {};
  } catch {
    return {};
  }
}

function writeJson(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2) + '\n', 'utf8');
}

function copyLegacyIdentity(legacyIdentityDir, targetIdentityDir) {
  if (!legacyIdentityDir || !fs.existsSync(legacyIdentityDir)) return false;
  const identity = loadIdentityDirectory(legacyIdentityDir);
  writeIdentityDirectory(targetIdentityDir, identity);
  return true;
}

function ensurePersistentIdentity({
  dataDir,
  legacyProfilePath = '',
  legacyIdentityDir = ''
}) {
  fs.mkdirSync(dataDir, { recursive: true });

  const profilePath = path.join(dataDir, 'profile.json');
  const publicProfilePath = path.join(dataDir, 'public-profile.json');
  const identityDir = path.join(dataDir, 'device');

  const hasProfile = fs.existsSync(profilePath);
  const hasIdentity = fs.existsSync(path.join(identityDir, 'identity.json'));

  if (!hasProfile && !hasIdentity && legacyProfilePath && fs.existsSync(legacyProfilePath)) {
    const legacyProfile = loadUserProfile(legacyProfilePath);
    if (copyLegacyIdentity(legacyIdentityDir, identityDir)) {
      const legacyIdentity = loadIdentityDirectory(identityDir);
      if (
        isDeviceAuthorized(
          legacyProfile,
          legacyIdentity.deviceId,
          legacyIdentity.publicKeyPem
        )
      ) {
        writeUserProfile(profilePath, legacyProfile);
      }
    }
  }

  let identity;
  if (fs.existsSync(path.join(identityDir, 'identity.json'))) {
    identity = loadIdentityDirectory(identityDir);
  } else {
    identity = generateIdentity();
    writeIdentityDirectory(identityDir, identity);
  }

  let profile;
  if (fs.existsSync(profilePath)) {
    profile = loadUserProfile(profilePath);
  } else {
    profile = authorizeDevice(
      createUserProfile({ displayName: 'CensoredFlow User' }),
      {
        deviceId: identity.deviceId,
        publicKeyPem: identity.publicKeyPem,
        label: 'CensoredFlow Windows'
      }
    );
    writeUserProfile(profilePath, profile);
  }

  if (!isDeviceAuthorized(profile, identity.deviceId, identity.publicKeyPem)) {
    profile = authorizeDevice(profile, {
      deviceId: identity.deviceId,
      publicKeyPem: identity.publicKeyPem,
      label: 'CensoredFlow Windows'
    });
    writeUserProfile(profilePath, profile);
  }

  writeUserProfile(publicProfilePath, profile);

  return Object.freeze({
    identity,
    profile,
    profilePath,
    publicProfilePath,
    identityDir
  });
}

function loadRuntimeConfig({
  dataDir,
  defaultsPath = ''
}) {
  const defaults = defaultsPath ? readJsonIfExists(defaultsPath) : {};
  const localPath = path.join(dataDir, 'runtime-config.json');
  const local = readJsonIfExists(localPath);
  const merged = { ...defaults, ...local };

  let relayUrl = '';
  try {
    relayUrl = normalizeRelayUrl(merged.relayUrl || '');
  } catch (error) {
    return {
      relayUrl: '',
      enabled: false,
      error: error.message,
      localPath
    };
  }

  return {
    relayUrl,
    enabled: merged.enabled !== false && Boolean(relayUrl),
    error: null,
    localPath
  };
}

class MessagingRuntime extends EventEmitter {
  constructor({
    dataDir,
    defaultsPath = '',
    uiPort = 0,
    reconnectMs = 5000,
    ackTimeoutMs = 4000,
    legacyProfilePath = '',
    legacyIdentityDir = ''
  }) {
    super();
    if (!dataDir) throw new Error('MessagingRuntime dataDir is required.');

    this.dataDir = path.resolve(dataDir);
    this.defaultsPath = defaultsPath ? path.resolve(defaultsPath) : '';
    this.uiPort = uiPort;
    this.reconnectMs = Math.max(1000, Number(reconnectMs) || 5000);
    this.ackTimeoutMs = Math.max(1000, Number(ackTimeoutMs) || 4000);
    this.legacyProfilePath = legacyProfilePath;
    this.legacyIdentityDir = legacyIdentityDir;

    this.identity = null;
    this.profile = null;
    this.profilePath = '';
    this.publicProfilePath = '';
    this.config = null;

    this.transport = null;
    this.service = null;
    this.bridge = null;
    this.notifications = null;
    this.ui = null;
    this.uiInfo = null;

    this.connectBusy = false;
    this.reconnectTimer = null;
    this.stopping = false;
  }

  _writePublicProfile() {
    if (!this.profile || !this.publicProfilePath) return;
    writeUserProfile(this.publicProfilePath, this.profile);
  }

  _updateLiveProfile(profile) {
    this.profile = profile;
    if (this.transport) {
      this.transport.userProfile = profile;
      this.transport.profileCache.set(profile.userId, profile);
    }
    if (this.service) this.service.userProfile = profile;
    if (this.bridge) {
      this.bridge.selfProfile = profile;
      this.bridge.emit('status', this.bridge.snapshot());
    }
    this._writePublicProfile();
  }

  linkDiscordIdentity(link) {
    const result = linkDiscordProfileFile(this.profilePath, link);
    this._updateLiveProfile(result.profile);
    return Object.freeze({
      ...result,
      restartRequired: false
    });
  }

  _scheduleReconnect() {
    if (
      this.stopping ||
      !this.config?.enabled ||
      this.reconnectTimer ||
      this.bridge?.connected
    ) return;

    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this._connectNow().catch(() => {});
    }, this.reconnectMs);
    this.reconnectTimer.unref?.();
  }

  async _connectNow() {
    if (
      this.stopping ||
      !this.config?.enabled ||
      this.connectBusy ||
      this.bridge?.connected
    ) return false;

    this.connectBusy = true;
    try {
      await this.bridge.start();
      this.emit('relay', {
        connected: true,
        relayUrl: this.config.relayUrl
      });
      return true;
    } catch (error) {
      this.emit('relay', {
        connected: false,
        relayUrl: this.config.relayUrl,
        error: String(error?.message || error)
      });
      this._scheduleReconnect();
      return false;
    } finally {
      this.connectBusy = false;
    }
  }

  async start() {
    if (this.uiInfo) {
      return this.snapshot();
    }

    const persisted = ensurePersistentIdentity({
      dataDir: this.dataDir,
      legacyProfilePath: this.legacyProfilePath,
      legacyIdentityDir: this.legacyIdentityDir
    });

    this.identity = persisted.identity;
    this.profile = persisted.profile;
    this.profilePath = persisted.profilePath;
    this.publicProfilePath = persisted.publicProfilePath;

    this.config = loadRuntimeConfig({
      dataDir: this.dataDir,
      defaultsPath: this.defaultsPath
    });

    const transportUrl = this.config.relayUrl ||
      'ws://127.0.0.1:9/messaging';

    this.transport = new MessagingTransport({
      url: transportUrl,
      userProfile: this.profile,
      deviceIdentity: this.identity,
      resolveUserProfile: (userId) =>
        this.transport?.getCachedProfile?.(userId) ||
        (String(userId || '') === this.profile.userId ? this.profile : null),
      ackTimeoutMs: this.ackTimeoutMs
    });

    this.service = new MessagingService({
      userProfile: this.profile,
      deviceIdentity: this.identity,
      transport: this.transport
    });

    this.bridge = new MessagingBridge({
      messagingService: this.service,
      selfProfile: this.profile,
      targetProfile: null
    });

    this.notifications = new NotificationController({
      bridge: this.bridge
    });

    this.ui = createUiServer({
      bridge: this.bridge,
      notifications: this.notifications,
      identityLinker: (link) => this.linkDiscordIdentity(link),
      host: '127.0.0.1',
      port: this.uiPort,
      rendererDir: path.join(__dirname, 'messaging', 'ui', 'renderer'),
      limitsFile: path.join(__dirname, 'messaging', 'protocol', 'limits.js')
    });

    this.uiInfo = await this.ui.start();

    this.bridge.on('status', (state) => {
      this.emit('status', state);
      if (!state?.connected) this._scheduleReconnect();
    });

    if (this.config.enabled) {
      this._connectNow().catch(() => {});
    }

    return this.snapshot();
  }

  getPublicProfile() {
    if (!this.profile) return null;
    return JSON.parse(JSON.stringify(this.profile));
  }

  snapshot() {
    return {
      dataDir: this.dataDir,
      profilePath: this.profilePath,
      publicProfilePath: this.publicProfilePath,
      userId: this.profile?.userId || null,
      deviceId: this.identity?.deviceId || null,
      relayUrl: this.config?.relayUrl || '',
      relayEnabled: this.config?.enabled === true,
      relayConnected: this.bridge?.connected === true,
      panelUrl: this.uiInfo?.url || null,
      uiPort: this.uiInfo?.port || null,
      configError: this.config?.error || null
    };
  }

  async stop() {
    this.stopping = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    try { this.notifications?.close(); } catch {}
    try { this.bridge?.close(); } catch {}
    try { await this.ui?.stop(); } catch {}

    this.uiInfo = null;
  }
}

module.exports = {
  isLoopbackHost,
  normalizeRelayUrl,
  ensurePersistentIdentity,
  loadRuntimeConfig,
  MessagingRuntime
};
