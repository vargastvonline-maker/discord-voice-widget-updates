const { app, BrowserWindow, globalShortcut, ipcMain, clipboard, shell, screen, Menu, dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { DiscordRpcClient } = require('./rpc-client');
const { WidgetUpdater } = require('./updater-client');
const { MessagingDevBridge } = require('./messaging-dev-bridge');
const { MessagingRuntime } = require('./messaging-runtime');

const CONFIG = path.join(__dirname, 'config.json');
let win;
let volumeWin = null;
let visibilityWin = null;
let scaleWin = null;
let settingsWin = null;
let messagingPanelWin = null;
let messagingPanelAllowClose = false;
let messagingBridge = null;
let messagingRuntime = null;
let messagingUnreadRaw = [];
let messagingBridgeOnline = false;
let verifiedDiscordIdentity = null;
let verifiedDiscordLinkState = null;
let verifiedDiscordConflictShownKey = '';
let fitBusy = false;
let rpcClient = null;
let updateClient = null;
let updaterState = { status: 'idle', message: '', ready: null };
let updaterTimer = null;
let clickThrough = false;
let saveTimer;
let suppressRememberUntil = 0;
let fitTimer;
let manualResize = false;
let resizeOrigin = null;
let transientScalePct = null;
let moveOrigin = null;
let preferredPosition = null;
let preferredSaveTimer;
let globalChannelSnapshot = null;
let globalRenderedChannelId = null;
let globalRenderFallbackTimer = null;
let globalSpeaking = new Set();
let globalVoiceTimer = null;
let globalVoiceRefreshTimer = null;
let globalRpcSerial = 0;
let globalRootSubscribed = false;
let globalSubscribedChannel = null;
let stopRpcDispatch = null;
let globalRefreshBusy = false;
let gameModeWatcher = null;
let gameModeDebounceTimer = null;
let gameModeActive = false;
let gameModeImmersive = false;
let gameModeForegroundPid = 0;
let gameModeForegroundProcess = '';
let gameModeWatcherHealthy = false;
let gameModeOverlaySource = '';
let gameModeCandidate = null;
let gameModeCandidateKey = '';
let gameModeWatcherStopping = false;
let widgetPriorityState = null;
let pinnedWidgetHwnd = null;
let pinWidgetInFlightHwnd = null;
let widgetPriorityWatchdogTimer = null;
let primaryWidgetWatchdogTimer = null;
let widgetVisibilityDiagnosticKey = '';
let widgetFocusableState = null;

const devUserDataPath = String(process.env.CENSOREDFLOW_DEV_USER_DATA || '').trim();
if (devUserDataPath) {
  try { app.setPath('userData', path.resolve(devUserDataPath)); } catch {}
}

/* Single-instance gate: Watcher, Guardian and manual launch must not create
   multiple widget windows for the same Windows account. */
const isPrimaryWidgetInstance = app.requestSingleInstanceLock();
if (!isPrimaryWidgetInstance) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (!win || win.isDestroyed()) return;
    syncVoiceWindowVisibility(globalChannelSnapshot && globalChannelSnapshot.id);
  });
}

function readConfig() {
  try { return JSON.parse(fs.readFileSync(CONFIG, 'utf8')); }
  catch { return {}; }
}
function writeConfig(patch) {
  const cfg = { ...readConfig(), ...patch };
  fs.writeFileSync(CONFIG, JSON.stringify(cfg, null, 2), 'utf8');
}
function validOverlayUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' &&
      u.hostname === 'streamkit.discord.com' &&
      u.pathname.startsWith('/overlay/voice/');
  } catch { return false; }
}
function positionForNewWindow(width, height) {
  const display = screen.getPrimaryDisplay();
  const a = display.workArea;
  return { x: Math.max(a.x, a.x + a.width - width - 24), y: a.y + 90 };
}

function positionForSavedWindow(cfg, width, height) {
  const px = Number(cfg && cfg.preferredX);
  const py = Number(cfg && cfg.preferredY);
  const hasPreferred = Number.isFinite(px) && Number.isFinite(py);
  const rawX = hasPreferred ? px : Number(cfg && cfg.x);
  const rawY = hasPreferred ? py : Number(cfg && cfg.y);
  if (!Number.isFinite(rawX) || !Number.isFinite(rawY)) {
    return positionForNewWindow(width, height);
  }

  const saved = { x: Math.round(rawX), y: Math.round(rawY) };
  const displays = screen.getAllDisplays();
  const hasVisibleArea = displays.some(display => {
    const a = display.workArea;
    const visibleWidth = Math.max(0, Math.min(saved.x + width, a.x + a.width) - Math.max(saved.x, a.x));
    const visibleHeight = Math.max(0, Math.min(saved.y + height, a.y + a.height) - Math.max(saved.y, a.y));
    return visibleWidth >= Math.min(24, width) && visibleHeight >= Math.min(24, height);
  });
  if (hasVisibleArea) return saved;

  const nearest = screen.getDisplayNearestPoint({
    x: saved.x + Math.round(width / 2),
    y: saved.y + Math.round(height / 2)
  }).workArea;
  const maxX = Math.max(nearest.x, nearest.x + nearest.width - width);
  const maxY = Math.max(nearest.y, nearest.y + nearest.height - height);
  return {
    x: Math.round(Math.max(nearest.x, Math.min(saved.x, maxX))),
    y: Math.round(Math.max(nearest.y, Math.min(saved.y, maxY)))
  };
}

function messagingUnreadForWidget() {
  const raw = Array.isArray(messagingUnreadRaw) ? messagingUnreadRaw : [];
  const mapped = raw
    .map((item) => {
      const discordUserId = String(item && item.discordUserId || '').trim();
      const count = Math.max(0, Number(item && item.count) || 0);
      const senderKey = String(item && item.senderKey || '').trim();
      if (!discordUserId || count < 1 || !senderKey) return null;
      return {
        userId: discordUserId,
        count,
        senderKey,
        demo: false
      };
    })
    .filter(Boolean);

  if (mapped.length) return mapped;

  const demoEnabled = process.env.CENSOREDFLOW_MESSAGING_DEV_DEMO === '1';
  if (!demoEnabled || !raw.length) return [];

  const participants = globalVoicePayload().participants || [];
  const firstParticipant = participants.find((item) => String(item && item.userId || '').trim());
  if (!firstParticipant) return [];

  const total = raw.reduce(
    (sum, item) => sum + Math.max(0, Number(item && item.count) || 0),
    0
  );
  const firstUnread = raw.find((item) => String(item && item.senderKey || '').trim());

  if (!firstUnread || total < 1) return [];

  return [{
    userId: String(firstParticipant.userId),
    count: total,
    senderKey: String(firstUnread.senderKey),
    demo: true
  }];
}

function notifyMessagingUnreadRenderer() {
  if (!win || win.isDestroyed()) return;
  const url = win.webContents.getURL();
  if (!(url.startsWith('file://') && url.includes('/global.html'))) return;
  try {
    win.webContents.send('dw-messaging-unread', messagingUnreadForWidget());
  } catch {}
}

function anchorMessagingPanel() {
  if (
    !win || win.isDestroyed() ||
    !messagingPanelWin || messagingPanelWin.isDestroyed()
  ) return null;

  const widgetBounds = win.getBounds();
  const [panelWidth, panelHeight] = messagingPanelWin.getContentSize();
  const display = screen.getDisplayNearestPoint({
    x: widgetBounds.x + Math.round(widgetBounds.width / 2),
    y: widgetBounds.y + Math.round(widgetBounds.height / 2)
  });
  const area = display.workArea;
  const gap = 8;

  const areaRight = area.x + area.width;
  const areaBottom = area.y + area.height;
  const widgetCenterX = widgetBounds.x + (widgetBounds.width / 2);
  const areaCenterX = area.x + (area.width / 2);

  const belowY = widgetBounds.y + widgetBounds.height + gap;
  const aboveY = widgetBounds.y - panelHeight - gap;
  const y = belowY + panelHeight <= areaBottom
    ? belowY
    : Math.max(area.y, aboveY);

  let x = widgetCenterX >= areaCenterX
    ? widgetBounds.x + widgetBounds.width - panelWidth
    : widgetBounds.x;

  x = Math.max(area.x, Math.min(x, areaRight - panelWidth));
  const finalY = Math.max(area.y, Math.min(y, areaBottom - panelHeight));

  messagingPanelWin.setPosition(Math.round(x), Math.round(finalY), false);
  return { x: Math.round(x), y: Math.round(finalY) };
}

function createMessagingPanelWindow() {
  if (messagingPanelWin && !messagingPanelWin.isDestroyed()) {
    return messagingPanelWin;
  }

  messagingPanelWin = new BrowserWindow({
    width: 410,
    height: 360,
    minWidth: 360,
    minHeight: 260,
    maxWidth: 760,
    maxHeight: 650,
    useContentSize: true,
    frame: false,
    transparent: false,
    resizable: false,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#0f0d17',
    skipTaskbar: true,
    alwaysOnTop: true,
    webPreferences: {
      preload: path.join(__dirname, 'messaging-panel-preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true
    }
  });

  messagingPanelWin.setMenuBarVisibility(false);
  messagingPanelWin.setSkipTaskbar(true);
  messagingPanelWin.setAlwaysOnTop(true, 'floating');
  messagingPanelWin.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });

  messagingPanelWin.on('show', () => {
    messagingPanelWin.setSkipTaskbar(true);
    messagingPanelWin.setAlwaysOnTop(true, 'floating');
    anchorMessagingPanel();
    messagingPanelWin.moveTop();
  });

  messagingPanelWin.on('close', (event) => {
    if (messagingPanelAllowClose) return;
    event.preventDefault();
    messagingPanelWin.hide();
  });

  messagingPanelWin.on('closed', () => {
    messagingPanelWin = null;
  });

  return messagingPanelWin;
}

async function ensureMessagingPanelReady() {
  if (!messagingBridge) return false;
  const panel = createMessagingPanelWindow();
  const target = messagingBridge.panelUrl;

  if (panel.webContents.getURL() === target && !panel.webContents.isLoading()) {
    return true;
  }

  try {
    await panel.loadURL(target);
    return true;
  } catch {
    return false;
  }
}

function showMessagingPanel() {
  if (!messagingPanelWin || messagingPanelWin.isDestroyed()) return false;
  anchorMessagingPanel();
  if (messagingPanelWin.isMinimized()) messagingPanelWin.restore();
  messagingPanelWin.show();
  messagingPanelWin.moveTop();
  messagingPanelWin.focus();
  return true;
}

async function openMessagingConversationForParticipant(discordUserId, displayName = '') {
  const cleanId = String(discordUserId || '').trim();
  const safeName = String(displayName || 'Participante').trim().slice(0, 100) || 'Participante';

  if (!/^\d{5,30}$/.test(cleanId)) {
    await dialog.showMessageBox({
      type: 'info',
      title: 'CensoredFlow - Mensagens',
      message: 'Não foi possível identificar esse participante.',
      buttons: ['OK'],
      defaultId: 0,
      noLink: true
    });
    return false;
  }

  if (String(verifiedDiscordIdentity?.discordUserId || '') === cleanId) {
    await dialog.showMessageBox({
      type: 'info',
      title: 'CensoredFlow - Mensagens',
      message: 'Essa é a sua própria conta do Discord.',
      detail: 'Escolha outra pessoa da call para iniciar uma conversa.',
      buttons: ['OK'],
      defaultId: 0,
      noLink: true
    });
    return false;
  }

  if (!messagingBridge || !messagingBridgeOnline) {
    await dialog.showMessageBox({
      type: 'info',
      title: 'CensoredFlow - Mensagens',
      message: 'O Messaging ainda está conectando.',
      detail: 'Aguarde alguns segundos e tente novamente.',
      buttons: ['OK'],
      defaultId: 0,
      noLink: true
    });
    return false;
  }

  try {
    const availability = await messagingBridge.resolveRecipient(cleanId);
    if (!availability?.available) {
      await dialog.showMessageBox({
        type: 'info',
        title: 'CensoredFlow - Mensagens',
        message: safeName + ' ainda não está disponível no CensoredFlow Messaging.',
        detail: 'Para enviar mensagem, essa pessoa precisa ter o CensoredFlow com a identidade Discord vinculada.',
        buttons: ['OK'],
        defaultId: 0,
        noLink: true
      });
      return false;
    }

    const ready = await ensureMessagingPanelReady();
    if (!ready) throw new Error('Painel de mensagens indisponível.');

    const result = await messagingBridge.startConversation(cleanId);
    if (!result?.ok) throw new Error(result?.message || 'Falha ao iniciar conversa.');

    showMessagingPanel();
    return true;
  } catch (error) {
    await dialog.showMessageBox({
      type: 'warning',
      title: 'CensoredFlow - Mensagens',
      message: 'Não foi possível iniciar a conversa.',
      detail: String(error?.message || 'Falha inesperada.').slice(0, 300),
      buttons: ['OK'],
      defaultId: 0,
      noLink: true
    });
    return false;
  }
}

async function openMessagingConversation(senderKey) {
  if (!messagingBridge || !messagingBridgeOnline) return false;
  const cleanKey = String(senderKey || '').trim();
  if (!cleanKey || cleanKey.length > 200) return false;

  const ready = await ensureMessagingPanelReady();
  if (!ready) return false;

  try {
    const result = await messagingBridge.openConversation(cleanKey);
    if (!result || result.ok !== true) return false;
    showMessagingPanel();
    return true;
  } catch {
    return false;
  }
}

function writeVerifiedDiscordLinkDevStatus(value) {
  if (!process.env.CENSOREDFLOW_DEV_USER_DATA) return;
  try {
    const safe = {
      at: new Date().toISOString(),
      status: String(value?.status || 'unknown'),
      userId: value?.userId ? String(value.userId) : null,
      discordUserId: value?.discordUserId ? String(value.discordUserId) : null,
      restartRequired: value?.restartRequired === true,
      code: value?.code ? String(value.code) : null
    };
    const target = path.join(__dirname, 'DEV_TESTS', 'verified-discord-link-status.json');
    fs.writeFileSync(target, JSON.stringify(safe, null, 2) + '\n', 'utf8');
  } catch {}
}

async function reconcileVerifiedDiscordIdentity() {
  if (!messagingBridge || !messagingBridgeOnline || !verifiedDiscordIdentity) {
    return false;
  }

  try {
    const result = await messagingBridge.linkDiscordIdentity(verifiedDiscordIdentity);
    verifiedDiscordLinkState = {
      status: result?.status || 'linked',
      userId: result?.userId || null,
      discordUserId: result?.discordUserId || verifiedDiscordIdentity.discordUserId,
      restartRequired: result?.restartRequired === true,
      code: null
    };
    verifiedDiscordConflictShownKey = '';
    writeVerifiedDiscordLinkDevStatus(verifiedDiscordLinkState);
    return true;
  } catch (error) {
    verifiedDiscordLinkState = {
      status: error?.code === 'DISCORD_LINK_CONFLICT' ? 'conflict' : 'error',
      userId: null,
      discordUserId: verifiedDiscordIdentity.discordUserId,
      restartRequired: false,
      code: error?.code || 'DISCORD_LINK_FAILED'
    };
    writeVerifiedDiscordLinkDevStatus(verifiedDiscordLinkState);

    if (error?.code === 'DISCORD_LINK_CONFLICT') {
      const conflictKey = [
        String(error.existingDiscordUserId || ''),
        String(error.incomingDiscordUserId || verifiedDiscordIdentity.discordUserId || '')
      ].join('->');

      if (conflictKey && conflictKey !== verifiedDiscordConflictShownKey) {
        verifiedDiscordConflictShownKey = conflictKey;
        dialog.showMessageBox({
          type: 'warning',
          title: 'CensoredFlow - identidade Discord',
          message: 'A conta Discord autenticada não corresponde ao vínculo salvo.',
          detail: 'Nenhuma identidade foi alterada. O CensoredFlow continuará funcionando, mas o Messaging não trocará de conta silenciosamente.',
          buttons: ['OK'],
          defaultId: 0,
          noLink: true
        }).catch(() => {});
      }
    }

    return false;
  }
}

async function startMessagingDevIntegration() {
  if (messagingBridge || messagingRuntime) return;

  const dataDir = path.join(app.getPath('userData'), 'messaging');
  const defaultsPath = path.join(__dirname, 'messaging.defaults.json');

  const legacyProfilePath = String(
    process.env.CENSOREDFLOW_MESSAGING_LEGACY_PROFILE || ''
  ).trim();
  const legacyIdentityDir = String(
    process.env.CENSOREDFLOW_MESSAGING_LEGACY_IDENTITY_DIR || ''
  ).trim();

  try {
    messagingRuntime = new MessagingRuntime({
      dataDir,
      defaultsPath,
      uiPort: 0,
      reconnectMs: 5000,
      ackTimeoutMs: 4000,
      legacyProfilePath,
      legacyIdentityDir
    });

    const runtimeState = await messagingRuntime.start();
    if (!runtimeState?.uiPort) {
      throw new Error('Messaging runtime did not start its local UI.');
    }

    messagingBridge = new MessagingDevBridge({
      host: '127.0.0.1',
      port: runtimeState.uiPort,
      pollMs: 800
    });

    messagingBridge.on('online', (online) => {
      messagingBridgeOnline = Boolean(online);
      if (messagingBridgeOnline) {
        ensureMessagingPanelReady().catch(() => {});
        reconcileVerifiedDiscordIdentity().catch(() => {});
      }
    });

    messagingBridge.on('unread', (unread) => {
      messagingUnreadRaw = Array.isArray(unread) ? unread : [];
      notifyMessagingUnreadRenderer();
    });

    messagingRuntime.on('relay', (state) => {
      if (fs.existsSync(path.join(__dirname, 'DEV_TESTS'))) {
        try {
          fs.writeFileSync(
            path.join(__dirname, 'DEV_TESTS', 'messaging-runtime-status.json'),
            JSON.stringify({
              at: new Date().toISOString(),
              relayConnected: state?.connected === true,
              relayUrl: String(state?.relayUrl || ''),
              error: state?.error ? String(state.error).slice(0, 300) : null,
              uiPort: runtimeState.uiPort,
              userId: runtimeState.userId,
              deviceId: runtimeState.deviceId
            }, null, 2) + '\n',
            'utf8'
          );
        } catch {}
      }
    });

    messagingBridge.start();
  } catch (error) {
    messagingBridgeOnline = false;
    if (fs.existsSync(path.join(__dirname, 'DEV_TESTS'))) {
      try {
        fs.writeFileSync(
          path.join(__dirname, 'DEV_TESTS', 'messaging-runtime-status.json'),
          JSON.stringify({
            at: new Date().toISOString(),
            relayConnected: false,
            error: String(error?.message || error).slice(0, 300)
          }, null, 2) + '\n',
          'utf8'
        );
      } catch {}
    }
    try { await messagingRuntime?.stop(); } catch {}
    messagingRuntime = null;
  }
}

function setInternalBounds(bounds) {
  if (!win || win.isDestroyed()) return;
  suppressRememberUntil = Date.now() + 350;
  win.setBounds(bounds);
}

function preferredPositionFromConfig(cfg) {
  const px = Number(cfg && cfg.preferredX);
  const py = Number(cfg && cfg.preferredY);
  if (Number.isFinite(px) && Number.isFinite(py)) {
    return { x: Math.round(px), y: Math.round(py) };
  }
  const x = Number(cfg && cfg.x);
  const y = Number(cfg && cfg.y);
  if (Number.isFinite(x) && Number.isFinite(y)) {
    return { x: Math.round(x), y: Math.round(y) };
  }
  return null;
}

function persistPreferredPositionNow(bounds) {
  try {
    const current = bounds || (win && !win.isDestroyed() ? win.getBounds() : null);
    if (current && Number.isFinite(current.x) && Number.isFinite(current.y)) {
      preferredPosition = { x: Math.round(current.x), y: Math.round(current.y) };
    }
    if (!preferredPosition) return false;
    const patch = {
      preferredX: preferredPosition.x,
      preferredY: preferredPosition.y,
      x: preferredPosition.x,
      y: preferredPosition.y
    };
    if (current && Number.isFinite(current.width) && Number.isFinite(current.height)) {
      patch.width = Math.round(current.width);
      patch.height = Math.round(current.height);
    }
    writeConfig(patch);
    return true;
  } catch {
    return false;
  }
}

function queuePreferredPositionSave(bounds) {
  if (bounds && Number.isFinite(bounds.x) && Number.isFinite(bounds.y)) {
    preferredPosition = { x: Math.round(bounds.x), y: Math.round(bounds.y) };
  }
  clearTimeout(preferredSaveTimer);
  preferredSaveTimer = setTimeout(() => {
    preferredSaveTimer = null;
    persistPreferredPositionNow();
  }, 120);
}

function restorePreferredPositionForCurrentSize() {
  if (!win || win.isDestroyed()) return;
  const b = win.getBounds();
  const cfg = readConfig();
  const raw = preferredPosition || preferredPositionFromConfig(cfg);
  if (!raw) return;
  const pos = positionForSavedWindow({ ...cfg, preferredX: raw.x, preferredY: raw.y }, b.width, b.height);
  if (Math.abs(b.x - pos.x) > 1 || Math.abs(b.y - pos.y) > 1) {
    setInternalBounds({ x: pos.x, y: pos.y, width: b.width, height: b.height });
  }
}


const overlayCss = `
html, body {
  background: transparent !important;
  overflow: hidden !important;
  font-family: Inter, "Segoe UI", sans-serif !important;
}
body {
  margin: 0 !important;
  padding: 42px 10px 10px !important;
  box-sizing: border-box !important;
}
#dw-handle {
  position: fixed;
  z-index: 2147483647;
  left: 8px; right: 8px; top: 7px;
  height: 28px;
  border-radius: 11px;
  background: rgba(18, 20, 29, .88);
  border: 1px solid rgba(255,255,255,.10);
  box-shadow: 0 10px 30px rgba(0,0,0,.28);
  backdrop-filter: blur(16px);
  display: flex;
  align-items: center;
  padding: 0 10px;
  color: rgba(255,255,255,.82);
  font-size: 11px;
  font-weight: 700;
  letter-spacing: .45px;
  -webkit-app-region: drag;
  user-select: none;
}
#dw-handle .dot {
  width: 7px; height: 7px; border-radius: 50%;
  background: #23d18b;
  box-shadow: 0 0 12px rgba(35,209,139,.8);
  margin-right: 7px;
}
#dw-handle .hint {
  margin-left: auto;
  opacity: .48;
  font-weight: 600;
  letter-spacing: 0;
}
ul.voice_states, .voice_states {
  margin: 0 !important;
  padding: 0 !important;
  list-style: none !important;
  display: flex !important;
  flex-direction: column !important;
  gap: 7px !important;
}
li.voice_state, .voice_state {
  position: relative !important;
  min-height: 48px !important;
  box-sizing: border-box !important;
  padding: 7px 38px 7px 8px !important;
  border-radius: 15px !important;
  background: rgba(18,20,29,.88) !important;
  border: 1px solid rgba(255,255,255,.09) !important;
  box-shadow: 0 10px 28px rgba(0,0,0,.22) !important;
  backdrop-filter: blur(18px) !important;
  display: flex !important;
  align-items: center !important;
}
li.voice_state.wrapper_speaking,
li.voice_state[class*="speaking"],
.voice_state.wrapper_speaking,
.voice_state[class*="speaking"] {
  border-color: rgba(35,209,139,.78) !important;
  box-shadow: 0 0 0 1px rgba(35,209,139,.25), 0 0 24px rgba(35,209,139,.22) !important;
}
img.voice_avatar, .voice_avatar {
  width: 34px !important;
  height: 34px !important;
  border-radius: 50% !important;
  margin: 0 9px 0 0 !important;
  border: 2px solid rgba(255,255,255,.18) !important;
  opacity: 1 !important;
}
li.voice_state.wrapper_speaking img.voice_avatar,
li.voice_state[class*="speaking"] img.voice_avatar {
  border-color: #23d18b !important;
}
.voice_name, .name {
  color: #f7f8fb !important;
  font-size: 13px !important;
  font-weight: 650 !important;
  text-shadow: none !important;
  opacity: .96 !important;
}
li.voice_state.mute::after,
li.voice_state.self_mute::after,
li.voice_state[class~="mute"]::after,
li.voice_state[class~="self_mute"]::after {
  content: "MIC OFF" !important;
  position: absolute !important;
  right: 8px !important;
  top: 50% !important;
  transform: translateY(-50%) !important;
  padding: 4px 6px !important;
  border-radius: 8px !important;
  background: rgba(244,67,82,.18) !important;
  border: 1px solid rgba(244,67,82,.42) !important;
  color: #ff6b77 !important;
  font-size: 8px !important;
  font-weight: 800 !important;
  letter-spacing: .5px !important;
}
li.voice_state.deaf::after,
li.voice_state.self_deaf::after,
li.voice_state[class~="deaf"]::after,
li.voice_state[class~="self_deaf"]::after {
  content: "DEAF" !important;
  position: absolute !important;
  right: 8px !important;
  top: 50% !important;
  transform: translateY(-50%) !important;
  padding: 4px 6px !important;
  border-radius: 8px !important;
  background: rgba(255,176,32,.16) !important;
  border: 1px solid rgba(255,176,32,.38) !important;
  color: #ffc257 !important;
  font-size: 8px !important;
  font-weight: 800 !important;
}
`;

const miniCss = `
:root {
  --dw-avatar: var(--dw-scale-avatar, clamp(22px, calc(100vw - 16px), 54px));
  --dw-row: calc(var(--dw-avatar) + 4px);
}
html {
  background: transparent !important;
  width: 100% !important;
  height: 100% !important;
  overflow: visible !important;
}
body {
  background: transparent !important;
  width: 100% !important;
  height: 100% !important;
  min-height: 100% !important;
  overflow: visible !important;
  margin: 0 !important;
  padding: 10px !important;
  box-sizing: border-box !important;
  -webkit-app-region: drag !important;
}
html, body, .voice_container, .voice_states, [class*="Voice_voiceContainer"], [class*="Voice_voiceStates"] {
  scrollbar-width: none !important;
  -ms-overflow-style: none !important;
}
html::-webkit-scrollbar,
body::-webkit-scrollbar,
.voice_container::-webkit-scrollbar,
.voice_states::-webkit-scrollbar,
[class*="Voice_voiceContainer"]::-webkit-scrollbar,
[class*="Voice_voiceStates"]::-webkit-scrollbar,
*::-webkit-scrollbar {
  width: 0 !important;
  height: 0 !important;
  display: none !important;
  background: transparent !important;
}
#dw-handle { display: none !important; }
#dw-resize {
  position: fixed !important;
  right: 2px !important;
  bottom: 2px !important;
  width: 12px !important;
  height: 12px !important;
  z-index: 99999 !important;
  cursor: nwse-resize !important;
  -webkit-app-region: no-drag !important;
  opacity: .24 !important;
  background: transparent !important;
  border-right: 1px solid rgba(235,238,246,.48) !important;
  border-bottom: 1px solid rgba(235,238,246,.48) !important;
  border-bottom-right-radius: 3px !important;
  box-shadow: 1px 1px 1px rgba(0,0,0,.38), inset -1px -1px 0 rgba(255,255,255,.08) !important;
  transition: opacity .14s ease, filter .14s ease !important;
}
#dw-resize:hover { opacity: .52 !important; filter:brightness(1.14) !important; }
body[data-dw-resize-mode="slider"] #dw-resize,
body[data-dw-empty="1"] #dw-resize { display:none !important; }
body[data-dw-resize-mode="mouse"] #dw-resize,
body[data-dw-resize-mode="both"] #dw-resize { display:block !important; }

.dw-speaking-bars {
  position:absolute !important;
  z-index:36 !important;
  display:flex !important;
  align-items:center !important;
  gap:1.5px !important;
  pointer-events:none !important;
  filter:drop-shadow(0 0 4px rgba(46,234,152,.58)) !important;
}
.dw-speaking-bars i {
  display:block !important;
  width:2px !important;
  border-radius:3px !important;
  background:#2eea98 !important;
  animation:dw-audio-bar .62s ease-in-out infinite alternate !important;
}
.dw-speaking-bars i:nth-child(1){height:5px;animation-delay:-.12s !important}
.dw-speaking-bars i:nth-child(2){height:10px;animation-delay:-.35s !important}
.dw-speaking-bars i:nth-child(3){height:7px;animation-delay:-.21s !important}
.dw-speaking-bars i:nth-child(4){height:4px;animation-delay:-.44s !important}
body[data-dw-layout="vertical"] .dw-speaking-bars {
  left:calc(100% - 1px) !important; top:50% !important; transform:translateY(-50%) !important;
}
body[data-dw-layout="horizontal"] .dw-speaking-bars {
  left:50% !important; top:calc(100% - 1px) !important; transform:translateX(-50%) !important;
}
@keyframes dw-audio-bar { from { transform:scaleY(.55); opacity:.72 } to { transform:scaleY(1.15); opacity:1 } }

.dw-speaking-dot {
  position:absolute !important;
  z-index:36 !important;
  top:2px !important;
  right:2px !important;
  width:5px !important;
  height:5px !important;
  border-radius:50% !important;
  background:#2eea98 !important;
  border:1px solid rgba(255,255,255,.92) !important;
  box-shadow:0 0 0 1px rgba(46,234,152,.16),0 0 4px rgba(46,234,152,.62) !important;
  pointer-events:none !important;
  animation:dw-speaking-dot-pulse 1s ease-in-out infinite !important;
}
@keyframes dw-speaking-dot-pulse {
  0%,100% { transform:scale(.86); opacity:.76 }
  50% { transform:scale(1.18); opacity:1 }
}

#dw-move {
  position: fixed !important;
  top: 1px !important;
  left: 50% !important;
  transform: translateX(-50%) !important;
  width: 16px !important;
  height: 6px !important;
  z-index: 100000 !important;
  -webkit-app-region: drag !important;
  cursor: move !important;
  opacity: .10 !important;
  border-top: 2px solid rgba(255,255,255,.72) !important;
  border-radius: 999px !important;
  transition: opacity .12s ease !important;
}
#dw-move:hover { opacity: .72 !important; }

li.voice_state,
.voice_state,
img.voice_avatar,
.voice_avatar,
[class*="Voice_voiceState"],
[class*="Voice_avatar"] {
  -webkit-app-region: no-drag !important;
}
li.voice_state,
.voice_state,
[class*="Voice_voiceState"] {
  cursor: context-menu !important;
}

.voice_container,
[class*="Voice_voiceContainer"] {
  background: transparent !important;
  width: auto !important;
  min-width: 0 !important;
  overflow: visible !important;
  height: auto !important;
}

ul.voice_states,
.voice_states,
[class*="Voice_voiceStates"] {
  display: flex !important;
  flex-direction: column !important;
  align-items: flex-start !important;
  gap: 2px !important;
  margin: 0 !important;
  padding: 0 !important;
  list-style: none !important;
  background: transparent !important;
  height: auto !important;
  min-height: 0 !important;
}

body[data-dw-layout="horizontal"] {
  --dw-avatar: var(--dw-scale-avatar, clamp(22px, calc(100vh - 16px), 54px));
  --dw-row: calc(var(--dw-avatar) + 4px);
}

body[data-dw-layout="horizontal"] ul.voice_states,
body[data-dw-layout="horizontal"] .voice_states,
body[data-dw-layout="horizontal"] [class*="Voice_voiceStates"] {
  flex-direction: row !important;
  align-items: center !important;
  flex-wrap: nowrap !important;
  gap: 3px !important;
}

body[data-dw-layout="horizontal"] li.voice_state.self_mute::before,
body[data-dw-layout="horizontal"] li.voice_state.mute::before,
body[data-dw-layout="horizontal"] li.voice_state[class~="self_mute"]::before,
body[data-dw-layout="horizontal"] li.voice_state[class~="mute"]::before,
body[data-dw-layout="horizontal"] li.voice_state.self_deaf::before,
body[data-dw-layout="horizontal"] li.voice_state.deaf::before,
body[data-dw-layout="horizontal"] li.voice_state[class~="self_deaf"]::before,
body[data-dw-layout="horizontal"] li.voice_state[class~="deaf"]::before {
  left: 4.5px !important;
  top: 4.5px !important;
  width: calc(var(--dw-avatar) - 5px) !important;
  height: calc(var(--dw-avatar) - 5px) !important;
  transform: none !important;
  border-width: 1.5px !important;
  background: rgba(215, 0, 18, .24) !important;
  box-shadow: 0 0 5px rgba(235,0,20,.26) !important;
}

body[data-dw-layout="horizontal"] li.voice_state.self_mute::after,
body[data-dw-layout="horizontal"] li.voice_state.mute::after,
body[data-dw-layout="horizontal"] li.voice_state[class~="self_mute"]::after,
body[data-dw-layout="horizontal"] li.voice_state[class~="mute"]::after,
body[data-dw-layout="horizontal"] li.voice_state.self_deaf::after,
body[data-dw-layout="horizontal"] li.voice_state.deaf::after,
body[data-dw-layout="horizontal"] li.voice_state[class~="self_deaf"]::after,
body[data-dw-layout="horizontal"] li.voice_state[class~="deaf"]::after {
  left: 50% !important;
  right: auto !important;
  top: 49% !important;
  width: calc(var(--dw-avatar) - 5px) !important;
  padding: 1px 0 !important;
  border-width: 1px !important;
  font-size: clamp(4px, 10vh, 7px) !important;
  font-weight: 980 !important;
  letter-spacing: -.12px !important;
  white-space: nowrap !important;
  transform: translate(-50%, -50%) rotate(-14deg) !important;
  box-shadow: 0 1px 4px rgba(0,0,0,.30) !important;
}

li.voice_state,
.voice_state,
[class*="Voice_voiceState"] {
  position: relative !important;
  width: var(--dw-row) !important;
  min-width: var(--dw-row) !important;
  height: var(--dw-row) !important;
  min-height: var(--dw-row) !important;
  margin: 0 !important;
  padding: 0 !important;
  background: transparent !important;
  border: 0 !important;
  box-shadow: none !important;
  backdrop-filter: none !important;
  display: block !important;
  overflow: visible !important;
  opacity: 1 !important;
  visibility: visible !important;
}

li.voice_state *,
.voice_state *,
[class*="Voice_voiceState"] * {
  visibility: visible !important;
}

img.voice_avatar,
img[class*="Voice_avatar"] {
  width: var(--dw-avatar) !important;
  height: var(--dw-avatar) !important;
  min-width: var(--dw-avatar) !important;
  min-height: var(--dw-avatar) !important;
  margin: 2px !important;
  padding: 0 !important;
  float: none !important;
  display: block !important;
  visibility: visible !important;
  border-radius: 50% !important;
  box-sizing: border-box !important;
  border: 1px solid rgba(190,200,220,.16) !important;
  box-shadow: 0 1px 5px rgba(0,0,0,.10) !important;
  opacity: .37 !important;
  filter: grayscale(.10) brightness(.82) !important;
  transition: border-color .12s ease, box-shadow .12s ease, filter .12s ease, transform .12s ease, opacity .12s ease !important;
}

li.voice_state.wrapper_speaking img.voice_avatar,
li.voice_state[class*="speaking"] img.voice_avatar,
img.voice_avatar.speaking,
img[class*="Voice_avatarSpeaking"] {
  border-color: #2eea98 !important;
  box-shadow: 0 0 0 1.5px rgba(46,234,152,.26), 0 0 6px rgba(46,234,152,.28) !important;
  filter: brightness(1.10) saturate(1.05) !important;
  opacity: 1 !important;
  transform: scale(1.04) !important;
}

.voice_name,
.name,
[class*="Voice_name"] {
  display: none !important;
}

li.voice_state.self_mute img.voice_avatar,
li.voice_state.mute img.voice_avatar,
li.voice_state[class~="self_mute"] img.voice_avatar,
li.voice_state[class~="mute"] img.voice_avatar,
li.voice_state.self_deaf img.voice_avatar,
li.voice_state.deaf img.voice_avatar,
li.voice_state[class~="self_deaf"] img.voice_avatar,
li.voice_state[class~="deaf"] img.voice_avatar {
  filter: grayscale(.74) brightness(.44) !important;
  opacity: .62 !important;
  border-color: rgba(235,0,20,.78) !important;
  box-shadow: 0 0 0 1px rgba(235,0,20,.18), 0 2px 8px rgba(0,0,0,.24) !important;
}

li.voice_state.self_mute::before,
li.voice_state.mute::before,
li.voice_state[class~="self_mute"]::before,
li.voice_state[class~="mute"]::before,
li.voice_state.self_deaf::before,
li.voice_state.deaf::before,
li.voice_state[class~="self_deaf"]::before,
li.voice_state[class~="deaf"]::before {
  content: "" !important;
  position: absolute !important;
  left: 50% !important;
  top: 50% !important;
  width: calc(var(--dw-avatar) + 2px) !important;
  height: calc(var(--dw-avatar) + 2px) !important;
  transform: translate(-50%, -50%) !important;
  z-index: 20 !important;
  box-sizing: border-box !important;
  border-radius: 50% !important;
  border: 2px solid rgba(235, 0, 20, .98) !important;
  background: rgba(215, 0, 18, .28) !important;
  box-shadow:
    0 0 0 1px rgba(255,255,255,.14) inset,
    0 0 8px rgba(235,0,20,.32) !important;
  pointer-events: none !important;
}

li.voice_state.self_mute::after,
li.voice_state.mute::after,
li.voice_state[class~="self_mute"]::after,
li.voice_state[class~="mute"]::after,
li.voice_state.self_deaf::after,
li.voice_state.deaf::after,
li.voice_state[class~="self_deaf"]::after,
li.voice_state[class~="deaf"]::after {
  content: "" !important;
  position: absolute !important;
  left: 50% !important;
  right: auto !important;
  top: 50% !important;
  width: min(calc(var(--dw-avatar) - 4px), 78%) !important;
  height: clamp(3px, 16%, 7px) !important;
  min-height: 3px !important;
  transform: translate(-50%, -50%) rotate(-10deg) !important;
  z-index: 21 !important;
  padding: 0 !important;
  box-sizing: border-box !important;
  border-radius: 2px !important;
  border: 1px solid rgba(255,48,72,.92) !important;
  background: rgba(255,48,72,.78) !important;
  box-shadow: 0 1px 4px rgba(0,0,0,.24) !important;
  pointer-events: none !important;
}
/* V2.2.7 candidate - estado de voz: faixa suave no avatar + icones abaixo */
.dw-status-badge {
  position:absolute !important;
  left:50% !important;
  top:calc(100% - 1px) !important;
  z-index:40 !important;
  pointer-events:none !important;
  transform:translateX(-50%) !important;
  transform-origin:center !important;
  filter:none !important;
  overflow:visible !important;
  max-width:calc(100% - 4px) !important;
  box-sizing:border-box !important;
}
.dw-status-badge[data-state="mute"] {
  width:clamp(8px, 48%, 18px) !important;
  aspect-ratio:1 / 1 !important;
  opacity:.98 !important;
}
.dw-status-badge[data-state="deaf"] {
  width:clamp(16px, 96%, 36px) !important;
  aspect-ratio:2.25 / 1 !important;
  opacity:.98 !important;
}
.dw-status-badge svg {
  display:block !important;
  width:100% !important;
  height:100% !important;
  overflow:visible !important;
}
body[data-dw-layout="vertical"] li.voice_state:has(> .dw-status-badge),
body[data-dw-layout="vertical"] .voice_state:has(> .dw-status-badge),
body[data-dw-layout="vertical"] [class*="Voice_voiceState"]:has(> .dw-status-badge) {
  margin-bottom:clamp(8px, calc(var(--dw-avatar) * .48), 15px) !important;
}

li.voice_state.self_mute::before,
li.voice_state.mute::before,
li.voice_state[class~="self_mute"]::before,
li.voice_state[class~="mute"]::before,
li.voice_state.self_deaf::before,
li.voice_state.deaf::before,
li.voice_state[class~="self_deaf"]::before,
li.voice_state[class~="deaf"]::before {
  content: none !important;
  display: none !important;
  background: none !important;
  border: 0 !important;
  box-shadow: none !important;
}
`;

function currentWidgetLayout() {
  return readConfig().layout === 'horizontal' ? 'horizontal' : 'vertical';
}
const visibilityCss = `
li.voice_state, .voice_state, [class*="Voice_voiceState"] {
  opacity: var(--dw-inactive-opacity, .40) !important;
  transition: opacity .14s ease !important;
}
li.voice_state.wrapper_speaking,
li.voice_state[class*="speaking"],
.voice_state.wrapper_speaking,
.voice_state[class*="speaking"],
li.voice_state.mute,
li.voice_state.self_mute,
li.voice_state.deaf,
li.voice_state.self_deaf,
li.voice_state[class~="mute"],
li.voice_state[class~="self_mute"],
li.voice_state[class~="deaf"],
li.voice_state[class~="self_deaf"] {
  opacity: 1 !important;
}
img.voice_avatar, img[class*="Voice_avatar"] {
  opacity: 1 !important;
  border-color: rgba(235,241,250,.24) !important;
  box-shadow: 0 2px 8px rgba(0,0,0,.28) !important;
  filter: brightness(.88) saturate(.92) contrast(1.02) !important;
}
li.voice_state.wrapper_speaking img.voice_avatar,
li.voice_state[class*="speaking"] img.voice_avatar,
img.voice_avatar.speaking,
img[class*="Voice_avatarSpeaking"] {
  border-color: #2eea98 !important;
  box-shadow: 0 0 0 1.5px rgba(46,234,152,.30), 0 0 8px rgba(46,234,152,var(--dw-speaker-glow,.30)) !important;
  filter: brightness(var(--dw-speaker-brightness,1.10)) saturate(var(--dw-speaker-saturation,1.05)) !important;
  transform: scale(var(--dw-speaker-scale,1.04)) !important;
}
li.voice_state.mute img.voice_avatar,
li.voice_state.self_mute img.voice_avatar,
li.voice_state.deaf img.voice_avatar,
li.voice_state.self_deaf img.voice_avatar {
  opacity: 1 !important;
  filter: grayscale(.35) brightness(.74) !important;
}
`;

function currentAvatarVisibility() {
  const n = Number(readConfig().avatarOpacity);
  return Number.isFinite(n) ? Math.max(0.1, Math.min(1, n)) : 0.4;
}

function applyAvatarVisibility() {
  if (!win || win.isDestroyed() || win.webContents.isDestroyed()) return;
  const v = currentAvatarVisibility();
  win.webContents.executeJavaScript(
    "document.documentElement.style.setProperty('--dw-inactive-opacity', " + JSON.stringify(String(v)) + ");"
  ).catch(() => {});
}

function setAvatarVisibility(nextValue) {
  const n = Number(nextValue);
  if (!Number.isFinite(n) || n < 0.1 || n > 1) return false;
  const precise = Math.round(n * 100) / 100;
  writeConfig({ avatarOpacity: precise });
  applyAvatarVisibility();
  return true;
}

function currentSpeakerIntensityPct() {
  const n = Number(readConfig().speakerHighlightPct);
  return Number.isFinite(n) && n >= 60 && n <= 140 ? Math.round(n) : 100;
}

function applySpeakerIntensity() {
  if (!win || win.isDestroyed() || win.webContents.isDestroyed()) return;
  const ratio = currentSpeakerIntensityPct() / 100;
  const brightness = (1 + .10 * ratio).toFixed(3);
  const saturation = (1 + .07 * ratio).toFixed(3);
  const scale = (1 + .04 * ratio).toFixed(3);
  const glow = Math.min(.50, .20 + .12 * ratio).toFixed(3);
  win.webContents.executeJavaScript(
    "document.documentElement.style.setProperty('--dw-speaker-brightness'," + JSON.stringify(brightness) + ");" +
    "document.documentElement.style.setProperty('--dw-speaker-saturation'," + JSON.stringify(saturation) + ");" +
    "document.documentElement.style.setProperty('--dw-speaker-scale'," + JSON.stringify(scale) + ");" +
    "document.documentElement.style.setProperty('--dw-speaker-glow'," + JSON.stringify(glow) + ");"
  ).catch(() => {});
}

function setSpeakerIntensityPct(value) {
  const n = Math.round(Number(value));
  if (!Number.isInteger(n) || n < 60 || n > 140) return false;
  writeConfig({ speakerHighlightPct: n });
  applySpeakerIntensity();
  return true;
}

function currentSpeakingIndicator() {
  const value = String(readConfig().speakingIndicator || 'bars');
  return value === 'dot' ? 'dot' : 'bars';
}

function applySpeakingIndicatorToRenderer() {
  if (!win || win.isDestroyed() || win.webContents.isDestroyed()) return;
  const mode = currentSpeakingIndicator();
  win.webContents.executeJavaScript(
    "document.body.dataset.dwSpeakingIndicator=" + JSON.stringify(mode) + ";"
  ).catch(() => {});
}

function setSpeakingIndicator(value) {
  const mode = String(value || '');
  if (!['bars','dot'].includes(mode)) return false;
  writeConfig({ speakingIndicator: mode });
  applySpeakingIndicatorToRenderer();
  return true;
}

function currentResizeMode() {
  const value = String(readConfig().resizeMode || 'both');
  return ['slider','mouse','both'].includes(value) ? value : 'both';
}

function applyResizeModeToRenderer() {
  if (!win || win.isDestroyed() || win.webContents.isDestroyed()) return;
  const mode = currentResizeMode();
  win.webContents.executeJavaScript(
    "document.body.dataset.dwResizeMode=" + JSON.stringify(mode) + ";"
  ).catch(() => {});
}

function setResizeMode(value) {
  const mode = String(value || '');
  if (!['slider','mouse','both'].includes(mode)) return false;
  writeConfig({ resizeMode: mode });
  applyResizeModeToRenderer();
  return true;
}

function openVisibilitySlider() {
  if (visibilityWin && !visibilityWin.isDestroyed()) {
    visibilityWin.show();
    visibilityWin.focus();
    return;
  }
  const width=325;
  const height=166;
  const cursor=screen.getCursorScreenPoint();
  const display=screen.getDisplayNearestPoint(cursor);
  const area=display.workArea;
  const x=Math.max(area.x, Math.min(cursor.x+10, area.x+area.width-width));
  const y=Math.max(area.y, Math.min(cursor.y+10, area.y+area.height-height));
  const popup = new BrowserWindow({
    width, height, x, y,
    frame:false,
    resizable:false,
    minimizable:false,
    maximizable:false,
    fullscreenable:false,
    skipTaskbar:true,
    alwaysOnTop:true,
    show:false,
    backgroundColor:'#1e1f22',
    webPreferences:{
      preload:path.join(__dirname,'visibility-preload.js'),
      contextIsolation:true,
      nodeIntegration:false,
      sandbox:true
    }
  });
  visibilityWin = popup;
  popup.setAlwaysOnTop(true,'floating');
  popup.loadFile('visibility.html', {
    query: {percent:String(Math.round(currentAvatarVisibility()*100))}
  }).catch(() => { if(!popup.isDestroyed()) popup.close(); });
  popup.once('ready-to-show', () => {
    if (popup.isDestroyed()) return;
    popup.show();
    popup.focus();
  });
  popup.on('blur', () => {
    setTimeout(() => {
      if (!popup.isDestroyed() && !popup.isFocused()) popup.close();
    }, 200);
  });
  popup.on('closed', () => {
    if (visibilityWin === popup) visibilityWin = null;
  });
}

function openWidgetScaleSlider() {
  if (scaleWin && !scaleWin.isDestroyed()) {
    scaleWin.show();
    scaleWin.focus();
    return;
  }
  const width=325;
  const height=166;
  const cursor=screen.getCursorScreenPoint();
  const display=screen.getDisplayNearestPoint(cursor);
  const area=display.workArea;
  const x=Math.max(area.x, Math.min(cursor.x+10, area.x+area.width-width));
  const y=Math.max(area.y, Math.min(cursor.y+10, area.y+area.height-height));
  const popup = new BrowserWindow({
    width, height, x, y,
    frame:false,
    resizable:false,
    minimizable:false,
    maximizable:false,
    fullscreenable:false,
    skipTaskbar:true,
    alwaysOnTop:true,
    show:false,
    backgroundColor:'#1e1f22',
    webPreferences:{
      preload:path.join(__dirname,'scale-preload.js'),
      contextIsolation:true,
      nodeIntegration:false,
      sandbox:true
    }
  });
  scaleWin = popup;
  popup.setAlwaysOnTop(true,'floating');
  popup.loadFile('scale.html', {
    query: {percent:String(Math.round(currentWidgetScalePct()))}
  }).catch(() => { if(!popup.isDestroyed()) popup.close(); });
  popup.once('ready-to-show', () => {
    if (popup.isDestroyed()) return;
    popup.show();
    popup.focus();
  });
  popup.on('blur', () => {
    setTimeout(() => {
      if (!popup.isDestroyed() && !popup.isFocused()) popup.close();
    }, 200);
  });
  popup.on('closed', () => {
    if (scaleWin === popup) scaleWin = null;
  });
}

function quickSettingsSnapshot() {
  const voice = globalVoicePayload();
  const channel = voice && voice.channel ? voice.channel : null;
  return {
    inactiveOpacityPct: Math.round(currentAvatarVisibility() * 100),
    speakerHighlightPct: currentSpeakerIntensityPct(),
    scalePct: currentWidgetScalePct(),
    resizeMode: currentResizeMode(),
    layout: currentWidgetLayout(),
    speakingIndicator: currentSpeakingIndicator(),
    smartGameMode: currentSmartGameMode(),
    widgetPaused: currentWidgetPaused(),
    discordConnected: Boolean(voice && voice.connected),
    inCall: Boolean(channel && channel.id),
    voiceChannelName: channel ? String(channel.name || '').slice(0, 80) : '',
    gameModeActive,
    gameModeImmersive,
    gameModeWatcherHealthy,
    gameModeOverlaySource,
    gameModeForegroundProcess
  };
}

function openQuickSettings() {
  if (settingsWin && !settingsWin.isDestroyed()) {
    settingsWin.show();
    settingsWin.focus();
    return;
  }
  const width = 440;
  const height = 400;
  const cursor = screen.getCursorScreenPoint();
  const display = screen.getDisplayNearestPoint(cursor);
  const area = display.workArea;
  const x = Math.max(area.x, Math.min(cursor.x + 12, area.x + area.width - width));
  const y = Math.max(area.y, Math.min(cursor.y + 12, area.y + area.height - height));
  const popup = new BrowserWindow({
    width, height, x, y,
    frame: false,
    resizable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    show: false,
    backgroundColor: '#15131d',
    webPreferences: {
      preload: path.join(__dirname, 'quick-settings-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  settingsWin = popup;
  popup.setAlwaysOnTop(true, 'floating');
  popup.loadFile('quick-settings.html').catch(() => { if (!popup.isDestroyed()) popup.close(); });
  popup.once('ready-to-show', () => {
    if (popup.isDestroyed()) return;
    popup.show();
    popup.focus();
  });
  popup.on('closed', () => {
    if (settingsWin === popup) settingsWin = null;
  });
}

function resetVisualDefaults() {
  transientScalePct = null;
  writeConfig({
    avatarOpacity: 0.40,
    speakerHighlightPct: 100,
    widgetScalePct: 100,
    resizeMode: 'both',
    speakingIndicator: 'bars',
    manualSize: false
  });
  manualResize = false;
  applyAvatarVisibility();
  applySpeakerIntensity();
  applySpeakingIndicatorToRenderer();
  applyResizeModeToRenderer();
  fitMiniToPeople();
}

function currentWidgetScalePct() {
  if (Number.isFinite(transientScalePct)) return Math.max(60, Math.min(180, Math.round(transientScalePct)));
  const n = Number(readConfig().widgetScalePct);
  return Number.isFinite(n) && n >= 60 && n <= 180 ? Math.round(n) : 100;
}

function setWidgetScalePct(n) {
  const percent = Number(n);
  if (!Number.isInteger(percent) || percent < 60 || percent > 180) return false;
  transientScalePct = null;
  writeConfig({ widgetScalePct: percent, manualSize: false });
  manualResize = false;
  fitMiniToPeople();
  return true;
}

function fitMiniToPeople() {
  if (!win || win.isDestroyed() || fitBusy || win.webContents.isDestroyed()) return;
  fitBusy = true;
  const script = `(() => {
    const rows = [...document.querySelectorAll('li.voice_state, li[class*="Voice_voiceState"]')];
    return {
      count: rows.filter(row => row.querySelector('img.voice_avatar, img[class*="Voice_avatar"]')).length,
      statusCount: rows.filter(row => (
        row.classList.contains('self_mute') || row.classList.contains('mute') ||
        row.classList.contains('self_deaf') || row.classList.contains('deaf')
      )).length,
      empty: document.body.dataset.dwEmpty === '1'
    };
  })()`;
  win.webContents.executeJavaScript(script).then(measured => {
    if (!win || win.isDestroyed()) return;
    const count = Number(measured && measured.count) || 0;
    const layout = currentWidgetLayout();
    const bounds = win.getBounds();
    const area = screen.getDisplayMatching(bounds).workArea;
    if (measured && measured.empty) {
      const width = 240;
      const height = 84;
      const x = Math.round(Math.max(area.x, Math.min(bounds.x, area.x + area.width - width)));
      const y = Math.round(Math.max(area.y, Math.min(bounds.y, area.y + area.height - height)));
      if (bounds.width !== width || bounds.height !== height || bounds.x !== x || bounds.y !== y) {
        setInternalBounds({ x, y, width, height });
      }
      return;
    }
    const people = Math.min(150, Math.max(1, Math.round(count || 1)));
    const maxLength = Math.max(38, Math.min(890, (layout === 'horizontal' ? area.width : area.height) - 16));
    const preferredAvatar = Math.round(28 * currentWidgetScalePct() / 100);
    // The speaking ring is scaled and glows outside the avatar; keep a 10px outer inset.
    // Each participant row also has a CSS gap (2px vertical, 3px horizontal).
    const outerPadding = 20;
    const gap = layout === 'horizontal' ? 3 : 2;
    const gapsLength = Math.max(0, people - 1) * gap;
    const statusCount = Math.max(0, Math.min(people, Number(measured && measured.statusCount) || 0));
    let horizontalStatusGap = 0;
    let verticalStatusGap = 0;
    let statusBudget = 0;

    // First pass: size the avatar without status spacing.
    let effectiveAvatar = Math.max(14, Math.min(preferredAvatar, Math.floor((maxLength - outerPadding - gapsLength) / people) - 4));

    // Vertical mute/deaf badges hang below the avatar. Reserve only the space
    // they actually need: 8px on tiny avatars up to 15px on large ones.
    if (layout === 'vertical' && statusCount) {
      verticalStatusGap = Math.max(8, Math.min(15, Math.round(effectiveAvatar * 0.48)));
      statusBudget = statusCount * verticalStatusGap;
      effectiveAvatar = Math.max(14, Math.min(preferredAvatar, Math.floor((maxLength - outerPadding - gapsLength - statusBudget) / people) - 4));

      const refinedGap = Math.max(8, Math.min(15, Math.round(effectiveAvatar * 0.48)));
      if (refinedGap !== verticalStatusGap) {
        verticalStatusGap = refinedGap;
        statusBudget = statusCount * verticalStatusGap;
        effectiveAvatar = Math.max(14, Math.min(preferredAvatar, Math.floor((maxLength - outerPadding - gapsLength - statusBudget) / people) - 4));
      }
    }

    if (layout === 'horizontal' && statusCount) {
      horizontalStatusGap = Math.max(10, Math.min(20, Math.round(effectiveAvatar * 0.70)));
    }

    const avatarBand = effectiveAvatar <= 22 ? 'compact' : (effectiveAvatar <= 30 ? 'medium' : 'full');
    const row = effectiveAvatar + 4;
    const longSide = Math.min(maxLength, Math.max(38, people * row + gapsLength + outerPadding + statusBudget));
    const shortSide = Math.max(38, row + outerPadding + (layout === 'horizontal' && statusCount ? horizontalStatusGap : 0));
    const width = Math.round(layout === 'horizontal' ? longSide : shortSide);
    const height = Math.round(layout === 'horizontal' ? shortSide : longSide);
    const x = Math.round(Math.max(area.x, Math.min(bounds.x, area.x + area.width - width)));
    const y = Math.round(Math.max(area.y, Math.min(bounds.y, area.y + area.height - height)));

    win.webContents.executeJavaScript(
      "document.documentElement.style.setProperty('--dw-scale-avatar', " +
      JSON.stringify(effectiveAvatar + 'px') + ");" +
      "document.body.dataset.dwAvatarBand=" + JSON.stringify(avatarBand) + ";"
    ).catch(() => {});
    if (bounds.width !== width || bounds.height !== height || bounds.x !== x || bounds.y !== y) {
      setInternalBounds({ x, y, width, height });
    }
  }).catch(() => {}).finally(() => { fitBusy = false; });
}

function setWidgetLayout(layout) {
  const next = layout === 'horizontal' ? 'horizontal' : 'vertical';
  manualResize = false;
  writeConfig({ layout: next, manualSize: false });

  if (!win || win.isDestroyed()) return;

  win.webContents.executeJavaScript(`(() => {
    document.body.dataset.dwLayout = ${JSON.stringify(next)};
  })()`).catch(() => {});

  fitMiniToPeople();
}

function decorate() {
  if (!win || win.isDestroyed()) return;
  win.webContents.insertCSS(overlayCss).catch(() => {});
  win.webContents.insertCSS(miniCss).catch(() => {});
  win.webContents.insertCSS(visibilityCss).catch(() => {});
  applyAvatarVisibility();
  applySpeakerIntensity();
  applySpeakingIndicatorToRenderer();
  applyResizeModeToRenderer();
  win.webContents.executeJavaScript(`
    (() => {
      document.body.dataset.dwLayout = ${JSON.stringify(currentWidgetLayout())};
      document.body.dataset.dwResizeMode = ${JSON.stringify(currentResizeMode())};
      document.body.dataset.dwSpeakingIndicator = ${JSON.stringify(currentSpeakingIndicator())};
      if (!window.__dwStatusBadgeSystem) {
        window.__dwStatusBadgeSystem = true;
        const muteSvg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><circle cx="16" cy="16" r="15" fill="#030308" fill-opacity=".94" stroke="#ff3048" stroke-width="1.5"/><rect x="12" y="5" width="8" height="13" rx="4" fill="none" stroke="#ff3048" stroke-width="2.7"/><path d="M8 14v1.5C8 21 11.5 24 16 24s8-3 8-8.5V14M16 24v4M11.5 28h9" fill="none" stroke="#ff3048" stroke-width="2.6" stroke-linecap="round"/><path d="M7 6l18 21" stroke="#ff3048" stroke-width="3.2" stroke-linecap="round"/></svg>';
        const deafSvg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 72 32"><circle cx="16" cy="16" r="15" fill="#030308" fill-opacity=".94" stroke="#ff3048" stroke-width="1.5"/><circle cx="56" cy="16" r="15" fill="#030308" fill-opacity=".94" stroke="#ff3048" stroke-width="1.5"/><g transform="translate(4 0)"><rect x="8" y="5" width="8" height="13" rx="4" fill="none" stroke="#ff3048" stroke-width="2.6"/><path d="M4 14v1.5C4 21 7.5 24 12 24s8-3 8-8.5V14M12 24v4M7.5 28h9" fill="none" stroke="#ff3048" stroke-width="2.5" stroke-linecap="round"/><path d="M3 6l18 21" stroke="#ff3048" stroke-width="3.1" stroke-linecap="round"/></g><g transform="translate(40 1)"><path d="M3 17v-3C3 6.5 8 2 16 2s13 4.5 13 12v3" fill="none" stroke="#ff3048" stroke-width="3" stroke-linecap="round"/><rect x="0" y="14" width="7" height="12" rx="3.3" fill="#ff3048"/><rect x="25" y="14" width="7" height="12" rx="3.3" fill="#ff3048"/></g><path d="M43 5L69 27" fill="none" stroke="#ff3048" stroke-width="3.1" stroke-linecap="round"/></svg>';
        const deafSvgCompact = deafSvg;

        const syncBadges = () => {
          const rows = Array.from(document.querySelectorAll('li.voice_state, li[class*="Voice_voiceState"]'));
          for (const row of rows) {
            const isDeaf = row.classList.contains('self_deaf') || row.classList.contains('deaf');
            const isMute = row.classList.contains('self_mute') || row.classList.contains('mute');
            const state = isDeaf ? 'deaf' : (isMute ? 'mute' : '');
            let badge = Array.from(row.children).find((el) => el.classList?.contains('dw-status-badge'));

            if (!state) {
              if (badge) badge.remove();
            } else {
              if (!badge) {
                badge = document.createElement('div');
                badge.className = 'dw-status-badge';
                row.appendChild(badge);
              }
              const compact = ['compact','medium'].includes(document.body.dataset.dwAvatarBand || '');
              const visualKey = state + ':' + (compact ? 'compact' : 'full');
              if (badge.dataset.visualKey !== visualKey) {
                badge.dataset.state = state;
                badge.dataset.visualKey = visualKey;
                badge.innerHTML = state === 'deaf' ? (compact ? deafSvgCompact : deafSvg) : muteSvg;
                badge.title = state === 'deaf' ? 'Fone e microfone mutados' : 'Microfone mutado';
              }
            }

            const isSpeaking = !state && (
              row.classList.contains('wrapper_speaking') ||
              Array.from(row.classList).some((c) => String(c).toLowerCase().includes('speaking'))
            );
            const speakingIndicator = document.body.dataset.dwSpeakingIndicator === 'dot' ? 'dot' : 'bars';
            let bars = Array.from(row.children).find((el) => el.classList?.contains('dw-speaking-bars'));
            let dot = Array.from(row.children).find((el) => el.classList?.contains('dw-speaking-dot'));

            if (!isSpeaking) {
              if (bars) bars.remove();
              if (dot) dot.remove();
            } else if (speakingIndicator === 'dot') {
              if (bars) bars.remove();
              if (!dot) {
                dot = document.createElement('span');
                dot.className = 'dw-speaking-dot';
                row.appendChild(dot);
              }
            } else {
              if (dot) dot.remove();
              if (!bars) {
                bars = document.createElement('span');
                bars.className = 'dw-speaking-bars';
                bars.innerHTML = '<i></i><i></i><i></i><i></i>';
                row.appendChild(bars);
              }
            }
          }
        };

        syncBadges();
        const observer = new MutationObserver(syncBadges);
        observer.observe(document.body, {
          subtree: true,
          childList: true,
          attributes: true,
          attributeFilter: ['class', 'data-dw-avatar-band', 'data-dw-speaking-indicator']
        });
        window.__dwStatusBadgeObserver = observer;
      }


      if (!document.getElementById('dw-handle')) {
        const h = document.createElement('div');
        h.id = 'dw-handle';
        h.innerHTML = '<span class="dot"></span><span>DISCORD VOICE</span><span class="hint">Ctrl+Alt+F10 trava</span>';
        document.body.appendChild(h);
      }
      if (!document.getElementById('dw-move')) {
        const m = document.createElement('div');
        m.id = 'dw-move';
        m.title = 'Arrastar widget';
        document.body.appendChild(m);
      }
      if (!document.getElementById('dw-resize')) {
        const r = document.createElement('div');
        r.id = 'dw-resize';
        r.title = 'Redimensionar widget';
        let resizing = false;
        r.addEventListener('mousedown', (e) => {
          if (e.button !== 0) return;
          resizing = true;
          window.widgetApi?.beginResize(e.screenX, e.screenY);
          e.preventDefault();
          e.stopPropagation();
        });
        window.addEventListener('mousemove', (e) => {
          if (!resizing) return;
          window.widgetApi?.resizeTo(e.screenX, e.screenY);
          e.preventDefault();
        }, true);
        window.addEventListener('mouseup', (e) => {
          if (!resizing || e.button !== 0) return;
          resizing = false;
          window.widgetApi?.endResize();
          e.preventDefault();
        }, true);
        window.addEventListener('blur', () => {
          if (!resizing) return;
          resizing = false;
          window.widgetApi?.endResize();
        });
        document.body.appendChild(r);
      }

      if (!window.__dwUniversalDragBound) {
        window.__dwUniversalDragBound = true;
        let moving = false;

        document.addEventListener('dragstart', (e) => {
          if (e.target?.closest?.('img.voice_avatar, img[class*="Voice_avatar"], .voice_avatar')) {
            e.preventDefault();
          }
        }, true);

        document.addEventListener('mousedown', (e) => {
          if (e.button !== 0) return;
          if (e.target?.closest?.('#dw-resize')) return;
          const row = e.target?.closest?.('li.voice_state, .voice_state, [class*="Voice_voiceState"]');
          if (!row) return;

          moving = true;
          window.widgetApi?.beginMove(e.screenX, e.screenY);
          e.preventDefault();
          e.stopPropagation();
        }, true);

        window.addEventListener('mousemove', (e) => {
          if (!moving) return;
          window.widgetApi?.moveTo(e.screenX, e.screenY);
          e.preventDefault();
        }, true);

        window.addEventListener('mouseup', (e) => {
          if (!moving || e.button !== 0) return;
          moving = false;
          window.widgetApi?.endMove();
          e.preventDefault();
        }, true);

        window.addEventListener('blur', () => {
          if (!moving) return;
          moving = false;
          window.widgetApi?.endMove();
        });
      }

      if (!window.__dwParticipantMenuBound) {
        window.__dwParticipantMenuBound = true;
        document.addEventListener('contextmenu', (e) => {
          const row = e.target?.closest?.('li.voice_state, .voice_state, [class*="Voice_voiceState"]');
          if (!row) return;

          const avatar = row.querySelector('img.voice_avatar, img[class*="Voice_avatar"], .voice_avatar');
          const nameEl = row.querySelector('.voice_name, .name, [class*="Voice_name"]');
          const cleanRow = row.cloneNode(true);
          cleanRow.querySelectorAll?.('.dw-status-badge').forEach((el) => el.remove());
          const cleanRowText = String(cleanRow.textContent || '').trim().replace(/\s+/g, ' ');
          const participant = {
            name: String(nameEl?.textContent || cleanRowText || 'Participante').trim().replace(/\s+/g, ' ').slice(0, 120),
            avatarUrl: String(avatar?.src || ''),
            userId: String(row.dataset?.userId || ''),
            rowClass: String(row.className || ''),
            rowText: cleanRowText.slice(0, 240)
          };

          e.preventDefault();
          e.stopPropagation();
          window.widgetApi?.showParticipantMenu(participant);
        }, true);
      }
    })();
  `).catch(() => {});
  clearInterval(fitTimer);
  fitMiniToPeople();
  fitTimer = setInterval(fitMiniToPeople, 1000);
}

function loadContent() {
  const cfg = readConfig();
  const mode = cfg.mode === 'streamkit' ? 'streamkit' : 'global';
  if (mode === 'streamkit' && validOverlayUrl(cfg.overlayUrl || '')) {
    win.loadURL(cfg.overlayUrl);
  } else {
    win.loadFile(path.join(__dirname, 'global.html'));
  }
}

function getNativeWindowHwnd(browserWindow) {
  if (process.platform !== 'win32' || !browserWindow || browserWindow.isDestroyed()) return null;
  try {
    const handle = browserWindow.getNativeWindowHandle();
    if (!handle || handle.length < 4) return null;
    if (handle.length >= 8 && typeof handle.readBigUInt64LE === 'function') {
      const value = handle.readBigUInt64LE(0);
      if (value > BigInt(Number.MAX_SAFE_INTEGER)) return null;
      return Number(value);
    }
    return handle.readUInt32LE(0);
  } catch {
    return null;
  }
}

function pinWidgetAcrossVirtualDesktops() {
  if (process.platform !== 'win32' || !win || win.isDestroyed()) return;

  const helper = path.join(__dirname, 'PinWidgetAllDesktops.ps1');
  const dll = path.join(__dirname, 'VirtualDesktopAccessor.dll');
  if (!fs.existsSync(helper) || !fs.existsSync(dll)) return;

  const hwnd = getNativeWindowHwnd(win);
  if (!hwnd) return;
  const hwndKey = String(hwnd);
  if (pinnedWidgetHwnd === hwndKey || pinWidgetInFlightHwnd === hwndKey) return;

  pinWidgetInFlightHwnd = hwndKey;
  try {
    const child = spawn('powershell.exe', [
      '-NoProfile',
      '-ExecutionPolicy', 'Bypass',
      '-WindowStyle', 'Hidden',
      '-File', helper,
      '-Hwnd', hwndKey,
      '-Action', 'Pin'
    ], {
      windowsHide: true,
      stdio: 'ignore'
    });
    child.on('close', code => {
      if (pinWidgetInFlightHwnd === hwndKey) pinWidgetInFlightHwnd = null;
      if (code === 0) pinnedWidgetHwnd = hwndKey;
    });
    child.on('error', () => {
      if (pinWidgetInFlightHwnd === hwndKey) pinWidgetInFlightHwnd = null;
    });
    child.unref?.();
  } catch {
    if (pinWidgetInFlightHwnd === hwndKey) pinWidgetInFlightHwnd = null;
  }
}
let voiceWindowReady = false;

function currentSmartGameMode() {
  const cfg = readConfig();
  if (typeof cfg.smartGameMode === 'boolean') return cfg.smartGameMode;
  return cfg.gameModePubg !== false;
}

function currentWidgetPaused() {
  return Boolean(readConfig().widgetPaused);
}

function widgetVisibilitySuppressed() {
  return currentWidgetPaused() || (currentSmartGameMode() && gameModeActive);
}

function setSmartGameMode(value) {
  const next = Boolean(value);
  // Keep the legacy PUBG flag aligned so a rollback to 2.2.8 preserves intent.
  writeConfig({ smartGameMode: next, gameModePubg: next });
  if (!next) {
    gameModeCandidate = null;
    gameModeCandidateKey = '';
    gameModeActive = false;
    gameModeImmersive = false;
    gameModeOverlaySource = '';
    if (gameModeDebounceTimer) {
      clearTimeout(gameModeDebounceTimer);
      gameModeDebounceTimer = null;
    }
  }
  applyWidgetInteractionMode();
  applyWidgetPriorityMode();
  syncVoiceWindowVisibility(globalChannelSnapshot && globalChannelSnapshot.id);
  return true;
}

function setWidgetPaused(value) {
  writeConfig({ widgetPaused: Boolean(value) });
  syncVoiceWindowVisibility(globalChannelSnapshot && globalChannelSnapshot.id);
  return true;
}

function closeTransientWidgetPopups() {
  for (const popup of [visibilityWin, scaleWin, volumeWin, settingsWin]) {
    try {
      if (popup && !popup.isDestroyed()) popup.close();
    } catch {}
  }

  try {
    if (messagingPanelWin && !messagingPanelWin.isDestroyed()) {
      messagingPanelWin.hide();
    }
  } catch {}
}

function applyGameModeCandidate(state) {
  const next = {
    detectorHealthy: Boolean(state && state.detectorHealthy !== false),
    overlayReady: Boolean(state && state.discordOverlayReady),
    overlaySource: String(state && state.discordOverlaySource || '').slice(0, 24),
    immersive: Boolean(state && state.immersive),
    foregroundPid: Math.max(0, Number(state && state.foregroundPid) || 0),
    foregroundProcess: String(state && state.foregroundProcess || '').slice(0, 120)
  };
  const nextKey = [
    next.detectorHealthy ? '1' : '0',
    next.overlayReady ? '1' : '0',
    next.overlaySource,
    next.immersive ? '1' : '0',
    String(next.foregroundPid),
    next.foregroundProcess
  ].join('|');

  // Identical watcher samples must not restart the debounce clock.
  if (gameModeCandidateKey === nextKey) return;
  gameModeCandidate = next;
  gameModeCandidateKey = nextKey;
  if (gameModeDebounceTimer) clearTimeout(gameModeDebounceTimer);

  const wantsOverlaySuppression = Boolean(currentSmartGameMode() && next.overlayReady);
  const delayMs = wantsOverlaySuppression ? 150 : (gameModeActive ? 900 : 250);

  gameModeDebounceTimer = setTimeout(() => {
    gameModeDebounceTimer = null;
    if (gameModeCandidateKey !== nextKey) return;

    gameModeWatcherHealthy = next.detectorHealthy;
    gameModeForegroundPid = next.foregroundPid;
    gameModeForegroundProcess = next.foregroundProcess;
    gameModeImmersive = next.immersive;
    gameModeOverlaySource = next.overlaySource;

    const wasActive = gameModeActive;
    gameModeActive = Boolean(currentSmartGameMode() && next.overlayReady);

    if (!win || win.isDestroyed()) return;
    applyWidgetInteractionMode();
    applyWidgetPriorityMode();

    if (gameModeActive) {
      if (win.isVisible()) win.hide();
      closeTransientWidgetPopups();
      return;
    }

    // Returning from Discord Overlay waits for a stable off-state before show.
    if (wasActive || !win.isVisible()) {
      syncVoiceWindowVisibility(globalChannelSnapshot && globalChannelSnapshot.id);
    }
  }, delayMs);
}

function startGameModeWatcher() {
  if (process.platform !== 'win32' || gameModeWatcher || gameModeWatcherStopping) return;
  const helper = path.join(__dirname, 'GameModeWatcher.ps1');
  if (!fs.existsSync(helper)) return;

  try {
    const child = spawn('powershell.exe', [
      '-NoProfile',
      '-ExecutionPolicy', 'Bypass',
      '-WindowStyle', 'Hidden',
      '-File', helper,
      '-ParentPid', String(process.pid)
    ], {
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'ignore']
    });

    gameModeWatcher = child;
    let buffer = '';
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', chunk => {
      buffer += String(chunk || '');
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() || '';
      for (const line of lines) {
        const text = String(line || '').trim();
        if (!text) continue;
        try {
          applyGameModeCandidate(JSON.parse(text));
        } catch {}
      }
    });
    child.on('close', () => {
      if (gameModeWatcher === child) gameModeWatcher = null;
      gameModeWatcherHealthy = false;
      gameModeCandidate = null;
      gameModeCandidateKey = '';
      gameModeOverlaySource = '';
      gameModeImmersive = false;
      gameModeActive = false;
      applyWidgetInteractionMode();
      applyWidgetPriorityMode();
      syncVoiceWindowVisibility(globalChannelSnapshot && globalChannelSnapshot.id);
      if (!gameModeWatcherStopping) setTimeout(startGameModeWatcher, 1500);
    });
    child.on('error', () => {
      if (gameModeWatcher === child) gameModeWatcher = null;
      gameModeWatcherHealthy = false;
      gameModeCandidate = null;
      gameModeCandidateKey = '';
      gameModeOverlaySource = '';
      gameModeImmersive = false;
      gameModeActive = false;
      applyWidgetInteractionMode();
      applyWidgetPriorityMode();
      syncVoiceWindowVisibility(globalChannelSnapshot && globalChannelSnapshot.id);
    });
  } catch {}
}

function stopGameModeWatcher() {
  gameModeWatcherStopping = true;
  if (gameModeDebounceTimer) {
    clearTimeout(gameModeDebounceTimer);
    gameModeDebounceTimer = null;
  }
  try { gameModeWatcher?.kill(); } catch {}
  gameModeWatcher = null;
  gameModeCandidate = null;
  gameModeCandidateKey = '';
  gameModeOverlaySource = '';
  gameModeImmersive = false;
  gameModeActive = false;
  applyWidgetInteractionMode();
}

function applyWidgetPriorityMode() {
  if (!win || win.isDestroyed()) return;
  const desired = widgetVisibilitySuppressed() ? 'off' : 'floating';

  let actualTopmost = null;
  try { actualTopmost = Boolean(win.isAlwaysOnTop()); } catch {}

  if (desired === 'off') {
    if (actualTopmost === false && widgetPriorityState === 'off') return;
    try { win.setAlwaysOnTop(false); } catch {}
    widgetPriorityState = 'off';
    return;
  }

  // Reconcile the cached state with the real BrowserWindow state. Some
  // borderless apps can demote our window from the topmost band without
  // changing our internal cache. Only repair when Windows/Electron says the
  // widget is no longer always-on-top.
  if (actualTopmost === true) {
    widgetPriorityState = 'floating';
    return;
  }

  try { win.setAlwaysOnTop(true, 'floating'); } catch {}
  widgetPriorityState = 'floating';
}

function reinforceWidgetTopmost() {
  if (!win || win.isDestroyed() || !win.isVisible() || widgetVisibilitySuppressed()) return;
  applyWidgetPriorityMode();
}

function applyWidgetInteractionMode() {
  if (!win || win.isDestroyed()) return;

  // In an immersive app without Discord Overlay, keep the widget interactive
  // but prevent it from becoming the foreground window when clicked.
  const shouldBeFocusable = !(currentSmartGameMode() && gameModeImmersive && !gameModeActive);

  let actualFocusable = null;
  try { actualFocusable = Boolean(win.isFocusable()); } catch {}

  if (actualFocusable === shouldBeFocusable) {
    widgetFocusableState = shouldBeFocusable;
    return;
  }

  try { win.setFocusable(shouldBeFocusable); } catch {}
  widgetFocusableState = shouldBeFocusable;
}

function ensurePrimaryWidgetWindow() {
  if (messagingPanelAllowClose) return;

  if (!win || win.isDestroyed()) {
    voiceWindowReady = false;
    globalRenderedChannelId = null;
    try { createWindow(); } catch {}
    return;
  }

  syncVoiceWindowVisibility(globalChannelSnapshot && globalChannelSnapshot.id);
}

function startPrimaryWidgetWatchdog() {
  if (primaryWidgetWatchdogTimer) return;
  primaryWidgetWatchdogTimer = setInterval(() => {
    ensurePrimaryWidgetWindow();
  }, 1500);
  primaryWidgetWatchdogTimer.unref?.();
}

function stopPrimaryWidgetWatchdog() {
  if (!primaryWidgetWatchdogTimer) return;
  clearInterval(primaryWidgetWatchdogTimer);
  primaryWidgetWatchdogTimer = null;
}

function startWidgetPriorityWatchdog() {
  if (widgetPriorityWatchdogTimer) return;
  widgetPriorityWatchdogTimer = setInterval(() => {
    if (!win || win.isDestroyed() || !win.isVisible() || widgetVisibilitySuppressed()) return;

    let actualTopmost = null;
    try { actualTopmost = Boolean(win.isAlwaysOnTop()); } catch {}
    if (actualTopmost === false) {
      applyWidgetPriorityMode();
    }
  }, 500);
}

function stopWidgetPriorityWatchdog() {
  if (!widgetPriorityWatchdogTimer) return;
  clearInterval(widgetPriorityWatchdogTimer);
  widgetPriorityWatchdogTimer = null;
}

function clearGlobalRenderFallback() {
  if (globalRenderFallbackTimer) {
    clearTimeout(globalRenderFallbackTimer);
    globalRenderFallbackTimer = null;
  }
}

function armGlobalRenderFallback(channelId) {
  clearGlobalRenderFallback();
  const expectedId = channelId ? String(channelId) : null;
  if (!expectedId) return;

  globalRenderFallbackTimer = setTimeout(() => {
    globalRenderFallbackTimer = null;
    const currentId = globalChannelSnapshot && globalChannelSnapshot.id
      ? String(globalChannelSnapshot.id)
      : null;
    if (!currentId || currentId !== expectedId) return;

    const payload = globalVoicePayload();
    const hasParticipants = Array.isArray(payload.participants) && payload.participants.length > 0;
    if (!hasParticipants) return;

    globalRenderedChannelId = currentId;
    syncVoiceWindowVisibility(currentId);
  }, 350);
}

function writeWidgetVisibilityDiagnostic(state) {
  try {
    const safe = {
      at: new Date().toISOString(),
      currentId: state.currentId || null,
      participantCount: Number(state.participantCount) || 0,
      rendererReady: state.rendererReady === true,
      suppressed: state.suppressed === true,
      paused: state.paused === true,
      smartGameMode: state.smartGameMode === true,
      gameModeActive: state.gameModeActive === true,
      gameModeImmersive: state.gameModeImmersive === true,
      gameModeWatcherHealthy: state.gameModeWatcherHealthy === true,
      overlaySource: String(state.overlaySource || ''),
      foregroundProcess: String(state.foregroundProcess || '').slice(0, 120),
      shouldShow: state.shouldShow === true,
      windowVisible: state.windowVisible === true
    };
    const key = JSON.stringify(safe, (name, value) => name === 'at' ? undefined : value);
    if (key === widgetVisibilityDiagnosticKey) return;
    widgetVisibilityDiagnosticKey = key;
    fs.writeFileSync(
      path.join(__dirname, 'DEV_TESTS', 'widget-visibility-status.json'),
      JSON.stringify(safe, null, 2) + '\n',
      'utf8'
    );
  } catch {}
}

function syncVoiceWindowVisibility(channelId) {
  if (!win || win.isDestroyed() || !voiceWindowReady) return;
  const currentId = channelId ? String(channelId) : null;
  const payload = globalVoicePayload();
  const hasParticipants = Array.isArray(payload.participants) && payload.participants.length > 0;
  const rendererReady = Boolean(currentId && globalRenderedChannelId === currentId);
  const suppressed = widgetVisibilitySuppressed();
  const shouldShow = Boolean(currentId && hasParticipants && rendererReady && !suppressed);

  writeWidgetVisibilityDiagnostic({
    currentId,
    participantCount: Array.isArray(payload.participants) ? payload.participants.length : 0,
    rendererReady,
    suppressed,
    paused: currentWidgetPaused(),
    smartGameMode: currentSmartGameMode(),
    gameModeActive,
    gameModeImmersive,
    gameModeWatcherHealthy,
    overlaySource: gameModeOverlaySource,
    foregroundProcess: gameModeForegroundProcess,
    shouldShow,
    windowVisible: Boolean(win && !win.isDestroyed() && win.isVisible())
  });

  if (!shouldShow) {
    if (widgetVisibilitySuppressed()) applyWidgetPriorityMode();
    if (win.isVisible()) win.hide();
    return;
  }

  if (win.isMinimized()) win.restore();
  if (!win.isVisible()) {
    restorePreferredPositionForCurrentSize();
    win.showInactive();
  }
  reinforceWidgetTopmost();
  pinWidgetAcrossVirtualDesktops();
}

function createWindow() {
  const cfg = readConfig();
  manualResize = false;
  const width = Number(cfg.width) || 350;
  const height = Number(cfg.height) || 260;
  const pos = positionForSavedWindow(cfg, width, height);
  preferredPosition = preferredPositionFromConfig(cfg) || { x: pos.x, y: pos.y };
  if (!Number.isFinite(Number(cfg.preferredX)) || !Number.isFinite(Number(cfg.preferredY))) {
    try { writeConfig({ preferredX: preferredPosition.x, preferredY: preferredPosition.y }); } catch {}
  }

  win = new BrowserWindow({
    ...pos,
    width, height,
    minWidth: 38,
    minHeight: 38,
    maxWidth: 900,
    maxHeight: 900,
    frame: false,
    transparent: true,
    resizable: false,
    thickFrame: false,
    alwaysOnTop: false,
    skipTaskbar: true,
    show: false,
    backgroundColor: '#00000000',
    title: 'CensoredFlow 2.0 | Piloto',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });
  widgetPriorityState = null;
  widgetFocusableState = null;
  pinnedWidgetHwnd = null;
  pinWidgetInFlightHwnd = null;
  applyWidgetInteractionMode();
  applyWidgetPriorityMode();
  win.setSkipTaskbar(true);
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  win.once('ready-to-show', () => {
    voiceWindowReady = true;
    // Discord aberto fora de call: Electron/RPC ativos, janela invisivel.
    syncVoiceWindowVisibility(globalChannelSnapshot && globalChannelSnapshot.id);

    // O handle nativo existe mesmo com a janela oculta.
    pinWidgetAcrossVirtualDesktops();
    setTimeout(pinWidgetAcrossVirtualDesktops, 1200);
  });

  win.webContents.on('did-finish-load', () => {
    const u = win.webContents.getURL();
    const isStreamKit = u.startsWith('https://streamkit.discord.com/overlay/voice/');
    const isGlobal = u.startsWith('file://') && u.includes('/global.html');
    if (isStreamKit || isGlobal) {
      decorate();
      if (isGlobal) setTimeout(notifyGlobalVoiceRenderer, 0);
    }
  });

  loadContent();

  const remember = () => {
    if (Date.now() < suppressRememberUntil) return;
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      if (!win || win.isDestroyed() || Date.now() < suppressRememberUntil) return;
      const b = win.getBounds();
      writeConfig({ x:b.x, y:b.y, width:b.width, height:b.height });
    }, 250);
  };
  win.on('move', remember);
  win.on('resize', remember);
  win.on('move', () => {
    if (messagingPanelWin && !messagingPanelWin.isDestroyed() && messagingPanelWin.isVisible()) {
      anchorMessagingPanel();
    }
  });
  win.on('resize', () => {
    if (messagingPanelWin && !messagingPanelWin.isDestroyed() && messagingPanelWin.isVisible()) {
      anchorMessagingPanel();
    }
  });

  // Reafirma TOPMOST sem roubar foco se outro programa disputar a ordem Z.
  const primaryWindow = win;

  win.on('show', () => setTimeout(reinforceWidgetTopmost, 20));
  win.on('blur', () => {
    if (globalChannelSnapshot && globalChannelSnapshot.id) {
      setTimeout(reinforceWidgetTopmost, 80);
    }
  });
  win.on('closed', () => {
    if (win !== primaryWindow) return;
    win = null;
    voiceWindowReady = false;
    globalRenderedChannelId = null;
    widgetPriorityState = null;
    widgetFocusableState = null;
    pinnedWidgetHwnd = null;
    pinWidgetInFlightHwnd = null;
  });
}

function setClickThrough(next) {
  clickThrough = next;
  if (!win || win.isDestroyed()) return;
  win.setIgnoreMouseEvents(clickThrough, { forward: true });
  if (!clickThrough) {
    try {
      if (win.isFocusable()) win.focus();
    } catch {}
  }
}

const RPC_CONFIG = path.join(__dirname, 'rpc.config.json');

function readRpcConfig() {
  try { return JSON.parse(fs.readFileSync(RPC_CONFIG, 'utf8')); }
  catch { return {}; }
}

function discordAvatarUrl(user) {
  if (!user || !user.id || !user.avatar) return '';
  const id = encodeURIComponent(String(user.id));
  const hash = encodeURIComponent(String(user.avatar));
  return 'https://cdn.discordapp.com/avatars/' + id + '/' + hash + '.webp?size=128';
}

function globalVoicePayload() {
  const channel = globalChannelSnapshot;
  const states = channel && Array.isArray(channel.voice_states) ? channel.voice_states : [];
  const participants = states.map(state => {
    const user = state && state.user ? state.user : {};
    const userId = String(user.id || '');
    const voiceState = state && state.voice_state ? state.voice_state : {};
    return {
      userId,
      username: String(user.username || ''),
      displayName: String(state && state.nick || user.global_name || user.username || 'Participante'),
      avatarUrl: discordAvatarUrl(user),
      voiceState: {
        mute: Boolean(voiceState.mute),
        deaf: Boolean(voiceState.deaf),
        self_mute: Boolean(voiceState.self_mute),
        self_deaf: Boolean(voiceState.self_deaf),
        suppress: Boolean(voiceState.suppress)
      },
      volume: Number(state && state.volume),
      mute: Boolean(state && state.mute),
      pan: state && state.pan && typeof state.pan === 'object'
        ? { left: Number(state.pan.left), right: Number(state.pan.right) }
        : { left: 1, right: 1 },
      speaking: globalSpeaking.has(userId)
    };
  });

  const connection = rpcClient && typeof rpcClient.getVoiceConnectionStatus === 'function'
    ? rpcClient.getVoiceConnectionStatus()
    : null;

  return {
    mode: 'global',
    connected: Boolean(rpcClient && rpcClient.authenticated),
    channel: channel ? {
      id: String(channel.id || ''),
      guildId: String(channel.guild_id || ''),
      name: String(channel.name || ''),
      type: Number(channel.type),
      bitrate: Number(channel.bitrate) || 0
    } : null,
    participants,
    connection,
    updatedAt: Date.now()
  };
}

function notifyGlobalVoiceRenderer() {
  if (!win || win.isDestroyed()) return;
  const url = win.webContents.getURL();
  if (!(url.startsWith('file://') && url.includes('/global.html'))) return;
  try { win.webContents.send('dw-global-state', globalVoicePayload()); } catch {}
  notifyMessagingUnreadRenderer();
  setTimeout(fitMiniToPeople, 10);
}

async function setGlobalChannelSubscriptions(channelId) {
  const nextId = channelId ? String(channelId) : null;
  const serial = rpcClient && typeof rpcClient.getConnectionSerial === 'function'
    ? Number(rpcClient.getConnectionSerial()) || 0
    : 0;

  if (serial !== globalRpcSerial) {
    globalRpcSerial = serial;
    globalRootSubscribed = false;
    globalSubscribedChannel = null;
    globalSpeaking.clear();
  }

  if (!globalRootSubscribed) {
    await rpcClient.subscribeEvent('VOICE_CHANNEL_SELECT', {});
    globalRootSubscribed = true;
  }

  if (globalSubscribedChannel === nextId) return;

  const channelEvents = [
    'VOICE_STATE_CREATE',
    'VOICE_STATE_UPDATE',
    'VOICE_STATE_DELETE',
    'SPEAKING_START',
    'SPEAKING_STOP'
  ];

  if (globalSubscribedChannel) {
    const oldArgs = { channel_id: globalSubscribedChannel };
    for (const evt of channelEvents) {
      try { await rpcClient.unsubscribeEvent(evt, oldArgs); } catch {}
    }
  }

  globalSpeaking.clear();

  if (nextId) {
    const args = { channel_id: nextId };
    for (const evt of channelEvents) {
      await rpcClient.subscribeEvent(evt, args);
    }
  }
  // Do not suppress retries after a partial subscription failure.
  globalSubscribedChannel = nextId;
}

let globalEmptyPolls = 0;
let globalRpcFailures = 0;
let globalLastReopenAt = 0;
let lastRpcHealthState = '';
const RPC_HEALTH_FILE = path.join(__dirname, 'rpc-health.json');

function updateRpcHealthState(state) {
  // Status only: no tokens, user IDs, guild names or channel IDs are recorded.
  if (state === lastRpcHealthState) return;
  lastRpcHealthState = state;
  try {
    fs.writeFileSync(RPC_HEALTH_FILE, JSON.stringify({
      status: state,
      updatedAt: new Date().toISOString()
    }, null, 2), 'utf8');
  } catch {}
}

async function refreshGlobalVoiceState() {
  if (!rpcClient || globalRefreshBusy) return;
  globalRefreshBusy = true;
  try {
    await rpcClient.ensureAuthenticated({ interactive: false });
    const channel = await rpcClient.getSelectedVoiceChannel();
    const channelId = channel && channel.id ? String(channel.id) : null;
    const previousChannelId = globalChannelSnapshot && globalChannelSnapshot.id ? String(globalChannelSnapshot.id) : null;

    if (!channelId || channelId !== previousChannelId) {
      globalRenderedChannelId = null;
      clearGlobalRenderFallback();
    }
    globalChannelSnapshot = channel || null;
    globalRpcFailures = 0;
    globalEmptyPolls = channelId ? 0 : globalEmptyPolls + 1;

    if (channelId) {
      const validIds = new Set(
        Array.isArray(channel.voice_states)
          ? channel.voice_states.map(x => String(x && x.user && x.user.id || '')).filter(Boolean)
          : []
      );
      for (const id of Array.from(globalSpeaking)) {
        if (!validIds.has(id)) globalSpeaking.delete(id);
      }
    } else {
      globalSpeaking.clear();
    }

    // Render immediately. Subscriptions improve responsiveness but never block
    // the widget from appearing; polling remains the recovery source of truth.
    syncVoiceWindowVisibility(channelId);
    notifyGlobalVoiceRenderer();
    if (channelId) armGlobalRenderFallback(channelId);
    else clearGlobalRenderFallback();

    let subscriptionsOk = true;
    try {
      await setGlobalChannelSubscriptions(channelId);
    } catch {
      subscriptionsOk = false;
    }

    if (!channelId) {
      updateRpcHealthState('WAITING_FOR_VOICE_CHANNEL');
    } else if (subscriptionsOk) {
      updateRpcHealthState('VOICE_CHANNEL_DETECTED');
    } else {
      updateRpcHealthState('VOICE_CHANNEL_DETECTED_SUBSCRIPTION_RETRY');
    }
  } catch (error) {
    globalRpcFailures++;
    const authRequired = Boolean(error && error.authRequired);

    if (authRequired) {
      updateRpcHealthState('AUTHORIZATION_REQUIRED');
      globalBootstrapReady = false;
      globalBootstrapInteractive = true;
      try {
        const next = { ...readRpcConfig(), authorized: false };
        fs.writeFileSync(RPC_CONFIG, JSON.stringify(next, null, 2), 'utf8');
      } catch {}

      globalChannelSnapshot = null;
      globalRenderedChannelId = null;
      clearGlobalRenderFallback();
      globalSpeaking.clear();
      syncVoiceWindowVisibility(null);
      notifyGlobalVoiceRenderer();
    } else {
      // A pipe restart/timeout is not an authorization failure. Preserve the
      // last good frame briefly so the widget does not blink or disappear.
      updateRpcHealthState('RPC_REFRESH_RETRY');
      if (globalRpcFailures >= 3) {
        globalChannelSnapshot = null;
        globalRenderedChannelId = null;
        globalSpeaking.clear();
        syncVoiceWindowVisibility(null);
        notifyGlobalVoiceRenderer();
      }
    }
  } finally {
    const stale = globalRpcFailures >= 3 || globalEmptyPolls >= 10;
    const now = Date.now();
    if (stale && now - globalLastReopenAt >= 90000) {
      updateRpcHealthState('RPC_RECONNECTING');
      globalLastReopenAt = now;
      globalEmptyPolls = 0;
      globalRpcFailures = 0;
      try { rpcClient.close(); } catch {}
      globalRootSubscribed = false;
      globalSubscribedChannel = null;
    }
    globalRefreshBusy = false;
  }
}
function scheduleGlobalVoiceRefresh(delay = 80) {
  clearTimeout(globalVoiceRefreshTimer);
  globalVoiceRefreshTimer = setTimeout(() => {
    refreshGlobalVoiceState().catch(() => {});
  }, delay);
}

async function startGlobalVoiceMode() {
  if (!rpcClient) return;

  if (stopRpcDispatch) {
    try { stopRpcDispatch(); } catch {}
    stopRpcDispatch = null;
  }

  stopRpcDispatch = rpcClient.onDispatch((evt, data) => {
    if (evt === 'VOICE_CHANNEL_SELECT') {
      scheduleGlobalVoiceRefresh(20);
      return;
    }

    if (evt === 'VOICE_STATE_CREATE' || evt === 'VOICE_STATE_UPDATE' || evt === 'VOICE_STATE_DELETE') {
      scheduleGlobalVoiceRefresh(60);
      return;
    }

    if (evt === 'SPEAKING_START' || evt === 'SPEAKING_STOP') {
      const userId = String(data && data.user_id || '');
      if (userId) {
        if (evt === 'SPEAKING_START') globalSpeaking.add(userId);
        else globalSpeaking.delete(userId);
        notifyGlobalVoiceRenderer();
      }
      return;
    }

    if (evt === 'VOICE_CONNECTION_STATUS') {
      notifyGlobalVoiceRenderer();
    }
  });

  await refreshGlobalVoiceState();
  clearInterval(globalVoiceTimer);
  globalVoiceTimer = setInterval(() => {
    refreshGlobalVoiceState().catch(() => {});
  }, 3000);
}



function participantMenuPayload(raw) {
  const p = raw && typeof raw === 'object' ? raw : {};
  const name = String(p.name || p.rowText || 'Participante').replace(/\s+/g, ' ').trim().slice(0, 80) || 'Participante';
  return {
    name,
    avatarUrl: String(p.avatarUrl || '').slice(0, 1000),
    userId: String(p.userId || '').slice(0, 40)
  };
}

function normalizeParticipantName(value) {
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function clampVoiceVolume(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 100;
  return Math.max(0, Math.min(200, n));
}

// Curva perceptual em tres zonas.
// 0-50 = ambiente/baixo (RPC 0-15), 50-100 = normal progressivo (15-100),
// 100-200 = ganho alto linear. O RPC individual aceita inteiros de 0 a 200.
function uiVolumeToRpc(value) {
  const ui = clampVoiceVolume(value);

  if (ui <= 1) return 0;

  if (ui <= 50) {
    const t = (ui - 2) / 48;
    return Math.max(1, Math.min(15, Math.round(1 + 14 * Math.pow(Math.max(0, t), 1.35))));
  }

  if (ui <= 100) {
    const t = (ui - 50) / 50;
    return Math.round(15 + 85 * Math.pow(t, 1.45));
  }

  return Math.round(ui);
}

function rpcVolumeToUi(value) {
  const rpc = clampVoiceVolume(value);

  if (rpc <= 0) return 1;

  if (rpc <= 15) {
    const t = Math.max(0, Math.min(1, (rpc - 1) / 14));
    return Math.max(2, Math.min(50, Math.round(2 + 48 * Math.pow(t, 1 / 1.35))));
  }

  if (rpc <= 100) {
    return Math.round(50 + 50 * Math.pow((rpc - 15) / 85, 1 / 1.45));
  }

  return Math.round(rpc);
}

function voiceStateToUiVolume(state) {
  if (!state) return 100;
  return rpcVolumeToUi(state.volume);
}

async function applyPerceivedUserVolume(userId, uiVolume) {
  const ui = Math.max(0, Math.min(200, Math.round(Number(uiVolume))));
  return await rpcClient.setUserVoiceSettings(userId, { volume: uiVolumeToRpc(ui) });
}

function matchVoiceState(participant, channel) {
  const states = channel && Array.isArray(channel.voice_states) ? channel.voice_states : [];
  if (!states.length) return null;

  const wantedId = String(participant.userId || '');
  if (wantedId) {
    const byId = states.find(state => String(state && state.user && state.user.id || '') === wantedId);
    if (byId) return byId;
  }

  const avatarUrl = String(participant.avatarUrl || '');
  for (const state of states) {
    const hash = state && state.user && state.user.avatar ? String(state.user.avatar) : '';
    if (hash && avatarUrl.includes(hash)) return state;
  }

  const wanted = normalizeParticipantName(participant.name);
  if (!wanted) return null;
  for (const state of states) {
    const candidates = [
      state && state.nick,
      state && state.user && state.user.global_name,
      state && state.user && state.user.username
    ].map(normalizeParticipantName).filter(Boolean);
    if (candidates.includes(wanted)) return state;
  }
  return null;
}

function openVolumeSlider(participant, state) {
  if (!state || !state.user || !state.user.id) return;

  if (volumeWin && !volumeWin.isDestroyed()) {
    try { volumeWin.close(); } catch {}
  }

  const width = 300;
  const height = 126;
  const cursor = screen.getCursorScreenPoint();
  const display = screen.getDisplayNearestPoint(cursor);
  const area = display.workArea;
  const x = Math.max(area.x, Math.min(cursor.x + 10, area.x + area.width - width));
  const y = Math.max(area.y, Math.min(cursor.y + 10, area.y + area.height - height));

  volumeWin = new BrowserWindow({
    width,
    height,
    x,
    y,
    frame: false,
    resizable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    show: false,
    backgroundColor: '#1e1f22',
    webPreferences: {
      preload: path.join(__dirname, 'volume-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  volumeWin.setAlwaysOnTop(true, 'floating');
  volumeWin.loadFile('volume.html', {
    query: {
      userId: String(state.user.id),
      name: String(participant.name || state.nick || state.user.global_name || state.user.username || 'Participante').slice(0, 80),
      volume: String(Number.isFinite(Number(state.volume)) ? voiceStateToUiVolume(state) : 100)
    }
  });

  volumeWin.once('ready-to-show', () => {
    if (!volumeWin || volumeWin.isDestroyed()) return;
    volumeWin.show();
    volumeWin.focus();
  });

  volumeWin.on('blur', () => {
    setTimeout(() => {
      if (volumeWin && !volumeWin.isDestroyed() && !volumeWin.isFocused()) {
        try { volumeWin.close(); } catch {}
      }
    }, 120);
  });

  volumeWin.on('closed', () => {
    volumeWin = null;
  });
}

function updaterStatusLabel() {
  const st = updaterState || {};
  if (st.status === 'ready' && st.ready) return 'Pronta: ' + st.ready.version;
  if (st.status === 'checking') return 'Verificando...';
  if (st.status === 'downloading') return 'Baixando atualiza\u00e7\u00e3o...';
  if (st.status === 'up_to_date') return 'Vers\u00e3o atualizada';
  if (st.status === 'error') return 'Erro: ' + String(st.message || 'falha').slice(0, 80);
  if (st.status === 'unconfigured') return 'Fonte ainda n\u00e3o configurada';
  if (st.status === 'disabled') return 'Atualiza\u00e7\u00f5es desativadas';
  if (st.status === 'full_install_required') return 'Reinstala\u00e7\u00e3o completa necess\u00e1ria';
  return 'Atualizador pronto';
}

async function beginApplyUpdate() {
  if (!updateClient) return;
  try {
    const ready = updateClient.launchApply();
    updaterState = updateClient.getState();
    await dialog.showMessageBox(win, {
      type: 'info',
      title: 'CensoredFlow 2.0',
      message: 'A atualiza\u00e7\u00e3o ' + ready.version + ' ser\u00e1 aplicada agora.',
      detail: 'O widget vai fechar por alguns segundos e voltar sozinho se o Discord estiver aberto.',
      buttons: ['OK'],
      defaultId: 0
    });
    setTimeout(() => app.quit(), 250);
  } catch (error) {
    await dialog.showMessageBox(win, {
      type: 'error',
      title: 'Falha na atualiza\u00e7\u00e3o',
      message: 'N\u00e3o foi poss\u00edvel iniciar a atualiza\u00e7\u00e3o.',
      detail: error && error.message ? error.message : String(error),
      buttons: ['OK']
    });
  }
}

async function checkUpdatesInteractive() {
  if (!updateClient) return;
  try {
    const result = await updateClient.checkForUpdates({ download: true });
    updaterState = updateClient.getState();

    if (result.status === 'ready' && result.ready) {
      const response = await dialog.showMessageBox(win, {
        type: 'info',
        title: 'Atualiza\u00e7\u00e3o dispon\u00edvel',
        message: 'CensoredFlow 2.0 | Atualizacao tecnica ' + result.ready.version + ' est\u00e1 pronto.',
        detail: result.ready.notes || 'A atualiza\u00e7\u00e3o j\u00e1 foi baixada e validada.',
        buttons: ['Reiniciar e atualizar', 'Depois'],
        defaultId: 0,
        cancelId: 1
      });
      if (response.response === 0) await beginApplyUpdate();
      return;
    }

    if (result.status === 'up_to_date') {
      await dialog.showMessageBox(win, {
        type: 'info',
        title: 'CensoredFlow 2.0',
        message: 'Voc\u00ea j\u00e1 est\u00e1 na vers\u00e3o mais recente.',
        buttons: ['OK']
      });
      return;
    }

    if (result.status === 'unconfigured') {
      await dialog.showMessageBox(win, {
        type: 'info',
        title: 'Atualiza\u00e7\u00f5es',
        message: 'A fonte de atualiza\u00e7\u00f5es ainda n\u00e3o est\u00e1 configurada.',
        buttons: ['OK']
      });
      return;
    }

    if (result.status === 'disabled') {
      await dialog.showMessageBox(win, {
        type: 'info',
        title: 'Atualiza\u00e7\u00f5es',
        message: 'As atualiza\u00e7\u00f5es est\u00e3o desativadas.',
        buttons: ['OK']
      });
      return;
    }

    if (result.status === 'full_install_required') {
      await dialog.showMessageBox(win, {
        type: 'warning',
        title: 'Atualiza\u00e7\u00e3o',
        message: 'Esta vers\u00e3o exige instala\u00e7\u00e3o completa.',
        detail: String(result.message || ''),
        buttons: ['OK']
      });
      return;
    }

    await dialog.showMessageBox(win, {
      type: 'error',
      title: 'Atualiza\u00e7\u00e3o',
      message: 'N\u00e3o foi poss\u00edvel verificar atualiza\u00e7\u00f5es.',
      detail: String(result.message || updaterState.message || 'Erro desconhecido.'),
      buttons: ['OK']
    });
  } catch (error) {
    updaterState = updateClient ? updateClient.getState() : updaterState;
    await dialog.showMessageBox(win, {
      type: 'error',
      title: 'Atualiza\u00e7\u00e3o',
      message: 'N\u00e3o foi poss\u00edvel verificar atualiza\u00e7\u00f5es.',
      detail: error && error.message ? error.message : String(error),
      buttons: ['OK']
    });
  }
}

function startUpdaterSchedule() {
  updateClient = new WidgetUpdater(__dirname, {
    onState: (state) => { updaterState = state; }
  });
  updaterState = updateClient.getState();

  const cfg = updateClient.getConfig();
  const minutes = Math.max(5, Number(cfg.checkIntervalMinutes) || 360);

  const silentCheck = async () => {
    try {
      if (!cfg.manifestUrl || cfg.enabled === false) return;
      await updateClient.checkForUpdates({ download: cfg.autoDownload !== false });
      updaterState = updateClient.getState();
    } catch {}
  };

  setTimeout(silentCheck, 15000);
  updaterTimer = setInterval(silentCheck, minutes * 60 * 1000);
}

function formatVoiceConnectionState(value) {
  const map = {
    DISCONNECTED: 'Desconectado',
    AWAITING_ENDPOINT: 'Aguardando endpoint',
    AUTHENTICATING: 'Autenticando',
    CONNECTING: 'Conectando',
    CONNECTED: 'Conectado',
    VOICE_DISCONNECTED: 'Voz desconectada',
    VOICE_CONNECTING: 'Conectando voz',
    VOICE_CONNECTED: 'Voz conectada',
    NO_ROUTE: 'Sem rota',
    ICE_CHECKING: 'Verificando ICE'
  };
  return map[String(value || '')] || String(value || 'Aguardando dados');
}

async function showParticipantMenu(raw) {
  if (!win || win.isDestroyed()) return;
  const participant = participantMenuPayload(raw);

  let channel = null;
  let state = null;
  let rpcError = null;
  try {
    if (!rpcClient) throw new Error('RPC n\u00e3o iniciado.');
    channel = await rpcClient.getSelectedVoiceChannel();
    state = matchVoiceState(participant, channel);
  } catch (e) {
    rpcError = e && e.message ? e.message : 'RPC indispon\u00edvel.';
  }

  const userId = state && state.user && state.user.id ? String(state.user.id) : '';
  const currentVolume = Number.isFinite(Number(state && state.volume)) ? voiceStateToUiVolume(state) : null;
  const currentMute = Boolean(state && state.mute);
  const currentPan = state && state.pan && typeof state.pan === 'object'
    ? { left: Number(state.pan.left), right: Number(state.pan.right) }
    : { left: 1, right: 1 };
  const canControl = Boolean(userId && rpcClient && rpcClient.authenticated);
  const isBot = Boolean(state && state.user && state.user.bot);
  const displayName = state
    ? String(state.nick || state.user?.global_name || state.user?.username || participant.name || 'Participante')
    : participant.name;
  const layout = currentWidgetLayout();
  const readyUpdate = updateClient ? updateClient.getReadyUpdate() : null;
  const currentAppVersion = updateClient ? updateClient.getCurrentVersion() : '2.2.0';
  const connection = rpcClient && typeof rpcClient.getVoiceConnectionStatus === 'function'
    ? rpcClient.getVoiceConnectionStatus()
    : null;

  const setMute = (mute) => {
    if (!canControl) return;
    rpcClient.setUserVoiceSettings(userId, { mute }).catch(() => {});
  };

  const setPan = (left, right) => {
    if (!canControl) return;
    rpcClient.setUserVoiceSettings(userId, { pan: { left, right } }).catch(() => {});
  };

  const near = (x, y) => Math.abs(Number(x) - Number(y)) < 0.08;
  const panCenter = near(currentPan.left, 1) && near(currentPan.right, 1);
  const panLeft = currentPan.left > currentPan.right + 0.15;
  const panRight = currentPan.right > currentPan.left + 0.15;

  const channelName = channel && channel.name ? String(channel.name) : 'Indispon\u00edvel';
  const channelUsers = channel && Array.isArray(channel.voice_states) ? channel.voice_states.length : 0;
  const bitrate = Number(channel && channel.bitrate);
  const avgPing = Number(connection && connection.average_ping);
  const lastPing = Number(connection && connection.last_ping);
  const voiceState = state && state.voice_state ? state.voice_state : null;
  const participantVoiceLabel = voiceState
    ? (voiceState.self_deaf || voiceState.deaf
      ? 'Fone + microfone mutados'
      : (voiceState.self_mute || voiceState.mute ? 'Microfone mutado' : 'Voz ativa'))
    : 'Estado n\u00e3o informado';

  const template = [
    {
      label: displayName + ' \u2022 ' + (state ? participantVoiceLabel : (rpcError ? 'RPC indispon\u00edvel' : 'RPC n\u00e3o identificado')),
      enabled: false
    },
    { type: 'separator' },
    ...(isBot ? [] : [{
      label: 'Enviar mensagem',
      enabled: Boolean(userId),
      click: () => {
        openMessagingConversationForParticipant(userId, displayName).catch(() => {});
      }
    }]),
    {
      label: currentVolume === null ? 'Volume...' : ('Volume \u2022 ' + currentVolume + '%'),
      enabled: canControl,
      click: () => openVolumeSlider(participant, state)
    },
    {
      label: currentMute ? 'Desmutar somente para mim' : 'Mutar somente para mim',
      enabled: canControl,
      click: () => setMute(!currentMute)
    },
    {
      label: 'Pan de \u00e1udio',
      enabled: canControl,
      submenu: [
        { label: 'Centralizado', type: 'radio', checked: panCenter, click: () => setPan(1, 1) },
        { label: 'Mais \u00e0 esquerda', type: 'radio', checked: panLeft, click: () => setPan(1, 0.25) },
        { label: 'Mais \u00e0 direita', type: 'radio', checked: panRight, click: () => setPan(0.25, 1) }
      ]
    },
    {
      label: 'Central r\u00e1pida...',
      click: () => openQuickSettings()
    },
    { type: 'separator' },
    {
      label: 'Widget',
      submenu: [
        {
          label: 'Orienta\u00e7\u00e3o',
          submenu: [
            { label: 'Vertical', type: 'radio', checked: layout === 'vertical', click: () => setWidgetLayout('vertical') },
            { label: 'Horizontal', type: 'radio', checked: layout === 'horizontal', click: () => setWidgetLayout('horizontal') }
          ]
        },
        {
          label: 'Visibilidade das fotos...',
          click: () => openVisibilitySlider()
        },
        {
          label: 'Tamanho das fotos...',
          click: () => openWidgetScaleSlider()
        },
        { type: 'separator' },
        {
          label: 'Clique atrav\u00e9s (F10)',
          type: 'checkbox',
          checked: clickThrough,
          click: (item) => setClickThrough(Boolean(item.checked))
        },
        {
          label: 'Reajustar tamanho automaticamente',
          click: () => {
            manualResize = false;
            writeConfig({ manualSize: false });
            fitMiniToPeople();
          }
        },
        { type: 'separator' },
        { label: 'Todos os desktops do Windows \u2022 ativo', enabled: false },
        { label: 'Sempre no topo \u2022 ativo', enabled: false }
      ]
    },
    {
      label: 'Diagn\u00f3stico',
      submenu: [
        { label: 'Canal: ' + channelName, enabled: false },
        { label: 'Participantes: ' + channelUsers, enabled: false },
        { label: 'Bitrate: ' + (Number.isFinite(bitrate) && bitrate > 0 ? Math.round(bitrate / 1000) + ' kbps' : 'n/d'), enabled: false },
        { label: 'Estado: ' + participantVoiceLabel, enabled: false },
        { type: 'separator' },
        { label: 'Conex\u00e3o: ' + formatVoiceConnectionState(connection && connection.state), enabled: false },
        { label: 'Ping m\u00e9dio: ' + (Number.isFinite(avgPing) ? Math.round(avgPing) + ' ms' : 'aguardando'), enabled: false },
        { label: '\u00daltimo ping: ' + (Number.isFinite(lastPing) ? Math.round(lastPing) + ' ms' : 'aguardando'), enabled: false }
      ]
    },
    {
      label: 'Atualiza\u00e7\u00f5es',
      submenu: [
        { label: 'CensoredFlow 2.0 | Vers\u00e3o t\u00e9cnica ' + currentAppVersion, enabled: false },
        {
          label: 'Verificar atualiza\u00e7\u00f5es',
          enabled: !['checking','downloading','applying'].includes(updaterState.status),
          click: () => checkUpdatesInteractive()
        },
        {
          label: readyUpdate ? ('Reiniciar e atualizar para ' + readyUpdate.version) : 'Nenhuma atualiza\u00e7\u00e3o pronta',
          enabled: Boolean(readyUpdate),
          click: () => beginApplyUpdate()
        },
        { label: updaterStatusLabel(), enabled: false }
      ]
    },
    {
      label: 'Copiar',
      submenu: [
        {
          label: 'Copiar nome',
          click: () => clipboard.writeText(participant.name)
        },
        {
          label: 'Copiar ID do Discord',
          enabled: Boolean(userId),
          click: () => { if (userId) clipboard.writeText(userId); }
        },
        { type: 'separator' },
        {
          label: 'Minha identidade pública do Messaging',
          enabled: Boolean(messagingRuntime?.getPublicProfile?.()),
          click: () => copyMessagingPublicProfile()
        }
      ]
    },
    { type: 'separator' },
    {
      label: canControl
        ? ('CensoredFlow 2.0 | ' + currentAppVersion + ' \u2022 RPC conectado')
        : ('CensoredFlow 2.0 | ' + currentAppVersion + ' \u2022 controle RPC indispon\u00edvel'),
      enabled: false
    }
  ];
  Menu.buildFromTemplate(template).popup({ window: win });
}

function writeRpcBootstrapDevDiagnostic(error) {
  if (!process.env.CENSOREDFLOW_DEV_USER_DATA) return;
  try {
    const safe = {
      at: new Date().toISOString(),
      name: error?.name ? String(error.name).slice(0, 80) : null,
      code: error?.code ? String(error.code).slice(0, 120) : null,
      message: error?.message ? String(error.message).slice(0, 300) : null,
      authRequired: error?.authRequired === true,
      rpcAuthRejected: error?.rpcAuthRejected === true
    };
    fs.writeFileSync(
      path.join(__dirname, 'DEV_TESTS', 'rpc-bootstrap-diagnostic.json'),
      JSON.stringify(safe, null, 2) + '\n',
      'utf8'
    );
  } catch {}
}

let globalBootstrapBusy = false;
let globalBootstrapReady = false;
let globalBootstrapInteractive = true;

async function ensureGlobalVoiceStarted() {
  if (!rpcClient || globalBootstrapBusy || globalBootstrapReady) return;
  globalBootstrapBusy = true;
  try {
    // This is the only path allowed to open Discord authorization.
    await rpcClient.ensureAuthenticated({ interactive: globalBootstrapInteractive });
    verifiedDiscordIdentity = rpcClient.getAuthenticatedDiscordIdentity();
    if (verifiedDiscordIdentity) {
      await reconcileVerifiedDiscordIdentity();
    }
    updateRpcHealthState('RPC_AUTHORIZED');
    globalBootstrapInteractive = false;
    try {
      const next = { ...readRpcConfig(), authorized: true };
      fs.writeFileSync(RPC_CONFIG, JSON.stringify(next, null, 2), 'utf8');
    } catch {}
    await startGlobalVoiceMode();
    globalBootstrapReady = true;
  } catch (error) {
    writeRpcBootstrapDevDiagnostic(error);
    const authRequired = Boolean(error && error.authRequired);
    const recordedAuthorization = Boolean(readRpcConfig().authorized);

    if (authRequired) {
      globalBootstrapInteractive = true;
      updateRpcHealthState('AUTHORIZATION_REQUIRED');
      try {
        const next = { ...readRpcConfig(), authorized: false };
        fs.writeFileSync(RPC_CONFIG, JSON.stringify(next, null, 2), 'utf8');
      } catch {}
    } else {
      // Existing users never see consent again because Discord IPC restarted.
      // First-run users remain eligible for the normal consent flow.
      globalBootstrapInteractive = !recordedAuthorization;
      updateRpcHealthState('RPC_BOOTSTRAP_RETRY');
    }
  } finally {
    globalBootstrapBusy = false;
  }
}
if (isPrimaryWidgetInstance) app.whenReady().then(() => {
  createWindow();
  startMessagingDevIntegration();
  startGameModeWatcher();
  startPrimaryWidgetWatchdog();
  startWidgetPriorityWatchdog();
  startUpdaterSchedule();

  const rpcCfg = readRpcConfig();
  rpcClient = new DiscordRpcClient(__dirname, {
    clientId: rpcCfg.clientId,
    redirectUri: rpcCfg.redirectUri,
    scopes: rpcCfg.scopes
  });
  globalBootstrapInteractive = !Boolean(rpcCfg.authorized) || !rpcClient.hasStoredAuthorization();

  // Watchdog is armed independently from the first OAuth/RPC attempt.
  // Before FIX5, a failed startup meant no polling timer would ever run.
  ensureGlobalVoiceStarted().catch(() => {});
  setInterval(() => {
    if (!globalBootstrapReady) ensureGlobalVoiceStarted().catch(() => {});
  }, 5000);

  const toggleVisibility = () => {
    if (!win) return;
    const channelId = globalChannelSnapshot && globalChannelSnapshot.id;
    if (!channelId) {
      win.hide();
      return;
    }
    if (win.isVisible()) win.hide();
    else {
      win.showInactive();
      win.restore();
      reinforceWidgetTopmost();
    }
  };
  const toggleClickThrough = () => setClickThrough(!clickThrough);
  const toggleLayout = () => setWidgetLayout(currentWidgetLayout() === 'horizontal' ? 'vertical' : 'horizontal');
  const toggleWidgetPause = () => setWidgetPaused(!currentWidgetPaused());

  globalShortcut.register('CommandOrControl+Alt+F6', toggleWidgetPause);
  globalShortcut.register('CommandOrControl+Alt+F9', toggleVisibility);
  globalShortcut.register('CommandOrControl+Alt+F10', toggleClickThrough);
  globalShortcut.register('CommandOrControl+Alt+F11', toggleLayout);

  // Atalhos DEV antigos mantidos como reserva.
  globalShortcut.register('CommandOrControl+Alt+F7', toggleVisibility);
  globalShortcut.register('CommandOrControl+Alt+F8', toggleClickThrough);
});

ipcMain.handle('save-url', (event, url) => {
  if (!event.senderFrame.url.startsWith('file://')) return { ok:false, error:'Origem invalida' };
  const value = String(url || '').trim();
  if (!validOverlayUrl(value)) return { ok:false, error:'Cole o link do Voice Widget do StreamKit.' };
  writeConfig({ overlayUrl:value, mode:'streamkit' });
  loadContent();
  return { ok:true };
});
ipcMain.handle('get-clipboard', (event) => {
  if (!event.senderFrame.url.startsWith('file://')) return '';
  return clipboard.readText();
});
ipcMain.handle('open-streamkit', (event) => {
  if (!event.senderFrame.url.startsWith('file://')) return false;
  shell.openExternal('https://streamkit.discord.com/overlay');
  return true;
});

function voiceFrame(event) {
  const url = event.senderFrame && event.senderFrame.url ? event.senderFrame.url : '';
  return Boolean(
    url.startsWith('https://streamkit.discord.com/overlay/voice/') ||
    (url.startsWith('file://') && url.includes('/global.html'))
  );
}

function globalFrame(event) {
  const url = event.senderFrame && event.senderFrame.url ? event.senderFrame.url : '';
  return Boolean(url.startsWith('file://') && url.includes('/global.html'));
}

function messagingPanelFrame(event) {
  if (!messagingPanelWin || messagingPanelWin.isDestroyed()) return false;
  const frame = event && event.senderFrame;
  const url = frame && frame.url ? frame.url : '';
  return event.sender === messagingPanelWin.webContents &&
    url.startsWith('http://127.0.0.1:39767/');
}

ipcMain.handle('dw-messaging-get-unread', (event) => {
  if (!globalFrame(event)) return [];
  return messagingUnreadForWidget();
});

ipcMain.on('dw-messaging-open-conversation', (event, payload) => {
  if (!globalFrame(event)) return;
  const senderKey = String(payload && payload.senderKey || '').trim();
  if (!senderKey || senderKey.length > 200) return;
  openMessagingConversation(senderKey).catch(() => {});
});

ipcMain.on('dw-messaging-panel-layout', (event, payload) => {
  if (!messagingPanelFrame(event)) return;

  const expanded = payload && payload.expanded === true;
  const requestedHeight = Number(payload && payload.height);
  const width = expanded ? 760 : 410;
  const height = expanded
    ? 650
    : Math.min(610, Math.max(260, Number.isFinite(requestedHeight) ? Math.ceil(requestedHeight) : 360));

  messagingPanelWin.setContentSize(width, height);
  anchorMessagingPanel();
});

ipcMain.on('dw-messaging-panel-hide', (event) => {
  if (!messagingPanelFrame(event)) return;
  messagingPanelWin.hide();
});

ipcMain.handle('dw-global-get-state', (event) => {
  if (!globalFrame(event)) return { mode:'global', channel:null, participants:[], connected:false };
  return globalVoicePayload();
});
ipcMain.on('dw-global-render-ready', (event, payload) => {
  if (!globalFrame(event)) return;
  const currentId = globalChannelSnapshot && globalChannelSnapshot.id ? String(globalChannelSnapshot.id) : null;
  const renderedId = payload && payload.channelId ? String(payload.channelId) : null;
  const participantCount = Math.max(0, Number(payload && payload.participantCount) || 0);
  if (!currentId || !renderedId || renderedId !== currentId || participantCount < 1) {
    if (!currentId || renderedId !== currentId || participantCount < 1) globalRenderedChannelId = null;
    if (!currentId || renderedId !== currentId) clearGlobalRenderFallback();
    syncVoiceWindowVisibility(currentId);
    return;
  }
  globalRenderedChannelId = currentId;
  clearGlobalRenderFallback();
  syncVoiceWindowVisibility(currentId);
});
function volumeFrame(event) {
  const url = event.senderFrame && event.senderFrame.url ? event.senderFrame.url : '';
  return url.startsWith('file://') && url.includes('/volume.html');
}
function visibilityFrame(event) {
  if (!visibilityWin || visibilityWin.isDestroyed()) return false;
  const frame = event && event.senderFrame;
  const url = frame && frame.url ? frame.url : '';
  return event.sender === visibilityWin.webContents &&
    url.startsWith('file://') && url.includes('/visibility.html');
}
ipcMain.handle('dw-visibility-set', (event, value) => {
  if (!visibilityFrame(event)) return {ok:false, error:'Origem nao autorizada'};
  const percent = Number(value);
  if (!Number.isInteger(percent) || percent < 10 || percent > 100) {
    return {ok:false, error:'Valor invalido'};
  }
  setAvatarVisibility(percent / 100);
  return {ok:true, percent};
});
ipcMain.on('dw-visibility-close', (event) => {
  if (!visibilityFrame(event)) return;
  if (visibilityWin && !visibilityWin.isDestroyed()) visibilityWin.close();
});
function scaleFrame(event) {
  if (!scaleWin || scaleWin.isDestroyed()) return false;
  const frame = event && event.senderFrame;
  const url = frame && frame.url ? frame.url : '';
  return event.sender === scaleWin.webContents &&
    url.startsWith('file://') && url.includes('/scale.html');
}
ipcMain.handle('dw-scale-set', (event, value) => {
  if (!scaleFrame(event)) return { ok:false, error:'Origem nao autorizada' };
  const percent=Number(value);
  if (!Number.isInteger(percent) || percent < 60 || percent > 180) {
    return {ok:false, error:'Tamanho invalido'};
  }
  setWidgetScalePct(percent);
  return {ok:true, percent};
});
ipcMain.on('dw-scale-close', (event) => {
  if (scaleFrame(event) && scaleWin && !scaleWin.isDestroyed()) scaleWin.close();
});

function settingsFrame(event) {
  if (!settingsWin || settingsWin.isDestroyed()) return false;
  const frame = event && event.senderFrame;
  const url = frame && frame.url ? frame.url : '';
  return event.sender === settingsWin.webContents &&
    url.startsWith('file://') && url.includes('/quick-settings.html');
}

ipcMain.handle('dw-settings-get', (event) => {
  if (!settingsFrame(event)) return { ok:false, error:'Origem nao autorizada' };
  return { ok:true, ...quickSettingsSnapshot() };
});

ipcMain.handle('dw-settings-set', (event, payload) => {
  if (!settingsFrame(event)) return { ok:false, error:'Origem nao autorizada' };
  const key = String(payload && payload.key || '');
  const value = payload && payload.value;
  let ok = false;
  if (key === 'inactiveOpacityPct') {
    const n = Math.round(Number(value));
    ok = Number.isInteger(n) && n >= 10 && n <= 100 && setAvatarVisibility(n / 100);
  } else if (key === 'speakerHighlightPct') {
    ok = setSpeakerIntensityPct(value);
  } else if (key === 'scalePct') {
    ok = setWidgetScalePct(Math.round(Number(value)));
  } else if (key === 'resizeMode') {
    ok = setResizeMode(value);
  } else if (key === 'speakingIndicator') {
    ok = setSpeakingIndicator(value);
  } else if (key === 'layout') {
    if (value === 'horizontal' || value === 'vertical') {
      setWidgetLayout(value);
      ok = true;
    }
  } else if (key === 'smartGameMode') {
    ok = setSmartGameMode(Boolean(value));
  } else if (key === 'widgetPaused') {
    ok = setWidgetPaused(Boolean(value));
  }
  return ok ? { ok:true, ...quickSettingsSnapshot() } : { ok:false, error:'Valor invalido' };
});

ipcMain.handle('dw-settings-reset', (event) => {
  if (!settingsFrame(event)) return { ok:false, error:'Origem nao autorizada' };
  resetVisualDefaults();
  return { ok:true, ...quickSettingsSnapshot() };
});

ipcMain.on('dw-settings-close', (event) => {
  if (settingsFrame(event) && settingsWin && !settingsWin.isDestroyed()) settingsWin.close();
});

function copyMessagingPublicProfile() {
  const profile = messagingRuntime?.getPublicProfile?.();
  if (!profile) {
    dialog.showMessageBox({
      type: 'info',
      title: 'CensoredFlow - Messaging piloto',
      message: 'A identidade pública ainda não está pronta.',
      detail: 'Aguarde alguns segundos e tente novamente.',
      buttons: ['OK'],
      defaultId: 0,
      noLink: true
    }).catch(() => {});
    return false;
  }

  const serialized = JSON.stringify(profile, null, 2);
  if (/PRIVATE KEY|privateKeyPem/i.test(serialized)) {
    dialog.showMessageBox({
      type: 'error',
      title: 'CensoredFlow - Messaging piloto',
      message: 'A exportação pública foi bloqueada por segurança.',
      buttons: ['OK'],
      defaultId: 0,
      noLink: true
    }).catch(() => {});
    return false;
  }

  clipboard.writeText(serialized);
  dialog.showMessageBox({
    type: 'info',
    title: 'CensoredFlow - Messaging piloto',
    message: 'Identidade pública copiada.',
    detail: 'Envie esse código somente para o responsável pelo piloto. Ele contém CF-U, Discord vinculado e chaves públicas; não contém sua chave privada.',
    buttons: ['OK'],
    defaultId: 0,
    noLink: true
  }).catch(() => {});
  return true;
}

function showWidgetMenu() {
  const layout = currentWidgetLayout();
  const messagingState = messagingRuntime?.snapshot?.() || null;
  Menu.buildFromTemplate([
    { label:'Central rápida...', click:() => openQuickSettings() },
    {
      label:'Messaging piloto',
      submenu:[
        {
          label:'Copiar minha identidade pública',
          enabled:Boolean(messagingRuntime?.getPublicProfile?.()),
          click:() => copyMessagingPublicProfile()
        },
        {
          label: messagingState?.relayConnected
            ? 'Relay • conectado'
            : 'Relay • desconectado',
          enabled:false
        }
      ]
    },
    { type:'separator' },
    {
      label:'Orientação',
      submenu:[
        { label:'Vertical', type:'radio', checked:layout === 'vertical', click:() => setWidgetLayout('vertical') },
        { label:'Horizontal', type:'radio', checked:layout === 'horizontal', click:() => setWidgetLayout('horizontal') }
      ]
    },
    { label:'Restaurar padrão visual', click:() => resetVisualDefaults() }
  ]).popup({ window:win });
}

ipcMain.on('dw-widget-menu', (event) => {
  if (!voiceFrame(event)) return;
  showWidgetMenu();
});

ipcMain.on('dw-participant-menu', (event, participant) => {
  if (!voiceFrame(event)) return;
  showParticipantMenu(participant);
});

ipcMain.handle('dw-volume-set', async (event, payload) => {
  if (!volumeFrame(event)) return { ok: false, error: 'Origem invalida.' };
  if (!rpcClient) return { ok: false, error: 'RPC indisponivel.' };

  const userId = String(payload && payload.userId || '');
  const uiVolume = Math.round(Number(payload && payload.volume));
  if (!/^\d{10,24}$/.test(userId)) return { ok: false, error: 'Usuario invalido.' };
  if (!Number.isFinite(uiVolume) || uiVolume < 0 || uiVolume > 200) return { ok: false, error: 'Volume invalido.' };

  try {
    await applyPerceivedUserVolume(userId, uiVolume);
    return { ok: true, volume: uiVolume };
  } catch (e) {
    return { ok: false, error: e && e.message ? e.message : 'Falha ao alterar volume.' };
  }
});

ipcMain.on('dw-volume-close', (event) => {
  if (!volumeFrame(event)) return;
  if (volumeWin && !volumeWin.isDestroyed()) {
    try { volumeWin.close(); } catch {}
  }
});

ipcMain.on('dw-resize-begin', (event, point) => {
  if (!voiceFrame(event) || !win || win.isDestroyed()) return;
  if (!['mouse','both'].includes(currentResizeMode())) return;
  const x = Number(point && point.x);
  const y = Number(point && point.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return;
  const scale = currentWidgetScalePct();
  resizeOrigin = { x, y, scale, last: scale };
});

ipcMain.on('dw-resize-move', (event, point) => {
  if (!voiceFrame(event) || !resizeOrigin || !win || win.isDestroyed()) return;
  const x = Number(point && point.x);
  const y = Number(point && point.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return;
  const dx = x - resizeOrigin.x;
  const dy = y - resizeOrigin.y;
  const delta = Math.abs(dx) >= Math.abs(dy) ? dx : dy;
  const raw = resizeOrigin.scale + (delta * .85);
  const snapped = Math.max(60, Math.min(180, Math.round(raw / 10) * 10));
  if (snapped === resizeOrigin.last) return;
  resizeOrigin.last = snapped;
  transientScalePct = snapped;
  fitMiniToPeople();
});

ipcMain.on('dw-resize-end', (event) => {
  if (!voiceFrame(event) || !resizeOrigin) return;
  const finalScale = Number.isFinite(transientScalePct) ? Math.round(transientScalePct) : resizeOrigin.last;
  resizeOrigin = null;
  transientScalePct = null;
  if (Number.isInteger(finalScale) && finalScale >= 60 && finalScale <= 180) {
    writeConfig({ widgetScalePct: finalScale, manualSize: false });
  }
  fitMiniToPeople();
});

ipcMain.on('dw-move-begin', (event, point) => {
  if (!voiceFrame(event) || !win || win.isDestroyed()) return;
  const x = Number(point && point.x);
  const y = Number(point && point.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return;
  moveOrigin = { x, y, bounds: win.getBounds() };
});

ipcMain.on('dw-move-move', (event, point) => {
  if (!voiceFrame(event) || !moveOrigin || !win || win.isDestroyed()) return;
  const x = Number(point && point.x);
  const y = Number(point && point.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return;

  const nextBounds = {
    x: Math.round(moveOrigin.bounds.x + (x - moveOrigin.x)),
    y: Math.round(moveOrigin.bounds.y + (y - moveOrigin.y)),
    width: moveOrigin.bounds.width,
    height: moveOrigin.bounds.height
  };
  win.setBounds(nextBounds);
  queuePreferredPositionSave(nextBounds);
});

ipcMain.on('dw-move-end', (event) => {
  if (!voiceFrame(event)) return;
  moveOrigin = null;
  if (!win || win.isDestroyed()) return;
  const b = win.getBounds();
  persistPreferredPositionNow(b);
});

app.on('before-quit', () => {
  messagingPanelAllowClose = true;
  try {
    if (messagingPanelWin && !messagingPanelWin.isDestroyed()) {
      messagingPanelWin.destroy();
    }
  } catch {}
});

app.on('will-quit', () => {
  try { messagingBridge?.stop(); } catch {}
  try { messagingRuntime?.stop()?.catch?.(() => {}); } catch {}
  try { stopGameModeWatcher(); } catch {}
  try { stopPrimaryWidgetWatchdog(); } catch {}
  try { stopWidgetPriorityWatchdog(); } catch {}
  try { if (preferredSaveTimer) clearTimeout(preferredSaveTimer); } catch {}
  try { if (preferredPosition) persistPreferredPositionNow({ x:preferredPosition.x, y:preferredPosition.y }); } catch {}
  try { if (updaterTimer) clearInterval(updaterTimer); } catch {}
  try { rpcClient?.close(); } catch {}
  globalShortcut.unregisterAll();
});
app.on('window-all-closed', () => app.quit());
