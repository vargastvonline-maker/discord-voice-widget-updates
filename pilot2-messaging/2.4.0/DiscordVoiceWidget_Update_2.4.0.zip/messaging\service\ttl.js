const DEFAULT_TTL_MS = 30_000;
const MIN_TTL_MS = 1_000;
const MAX_TTL_MS = 5 * 60_000;
const MAX_CLOCK_SKEW_MS = 30_000;

function assertTimestamp(value, name) {
  if (!Number.isInteger(value) || value < 0) {
    throw new TypeError(`${name} must be a non-negative integer timestamp.`);
  }
}

function createExpiry(createdAt, ttlMs = DEFAULT_TTL_MS) {
  assertTimestamp(createdAt, 'createdAt');
  if (!Number.isInteger(ttlMs) || ttlMs < MIN_TTL_MS || ttlMs > MAX_TTL_MS) {
    throw new RangeError(`ttlMs must be between ${MIN_TTL_MS} and ${MAX_TTL_MS}.`);
  }
  return createdAt + ttlMs;
}

function isExpired(expiresAt, now = Date.now()) {
  assertTimestamp(expiresAt, 'expiresAt');
  assertTimestamp(now, 'now');
  return now >= expiresAt;
}

function validateTtlWindow({ createdAt, expiresAt, now = Date.now() }) {
  const errors = [];

  if (!Number.isInteger(createdAt) || createdAt < 0) {
    errors.push({ code: 'INVALID_CREATED_AT', message: 'createdAt must be a valid timestamp.' });
  }
  if (!Number.isInteger(expiresAt) || expiresAt < 0) {
    errors.push({ code: 'INVALID_EXPIRES_AT', message: 'expiresAt must be a valid timestamp.' });
  }
  if (errors.length) return errors;

  if (createdAt > now + MAX_CLOCK_SKEW_MS) {
    errors.push({ code: 'CLOCK_SKEW', message: 'createdAt is too far in the future.' });
  }

  const ttlMs = expiresAt - createdAt;
  if (ttlMs < MIN_TTL_MS || ttlMs > MAX_TTL_MS) {
    errors.push({ code: 'INVALID_TTL', message: 'Message TTL is outside the allowed window.' });
  }

  if (isExpired(expiresAt, now)) {
    errors.push({ code: 'EXPIRED', message: 'Message has expired.' });
  }

  return errors;
}

module.exports = {
  DEFAULT_TTL_MS,
  MIN_TTL_MS,
  MAX_TTL_MS,
  MAX_CLOCK_SKEW_MS,
  createExpiry,
  isExpired,
  validateTtlWindow
};
