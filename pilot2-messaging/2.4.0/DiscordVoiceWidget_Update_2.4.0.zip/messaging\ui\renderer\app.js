(() => {
  const limits = window.CensoredFlowLimits;
  if (!limits) throw new Error('CensoredFlowLimits not loaded.');

  const el = {
    panelSubtitle: document.querySelector('#panel-subtitle'),
    connectionDot: document.querySelector('#connection-dot'),
    hideWindow: document.querySelector('#hide-window'),
    peopleSection: document.querySelector('#people-section'),
    peopleList: document.querySelector('#people-list'),
    conversation: document.querySelector('#conversation'),
    emptyState: document.querySelector('#empty-state'),
    peerAvatar: document.querySelector('#peer-avatar'),
    peerName: document.querySelector('#peer-name'),
    peerMeta: document.querySelector('#peer-meta'),
    selectedUnread: document.querySelector('#selected-unread'),
    receivedCard: document.querySelector('#received-card'),
    receivedType: document.querySelector('#received-type'),
    receivedTime: document.querySelector('#received-time'),
    receivedPreview: document.querySelector('#received-preview'),
    copyButton: document.querySelector('#copy-button'),
    expandButton: document.querySelector('#expand-button'),
    composer: document.querySelector('#composer'),
    input: document.querySelector('#message-input'),
    usageLabel: document.querySelector('#usage-label'),
    usagePercent: document.querySelector('#usage-percent'),
    usageTrack: document.querySelector('#usage-track'),
    usageBar: document.querySelector('#usage-bar'),
    typeButton: document.querySelector('#type-button'),
    typeMenu: document.querySelector('#type-menu'),
    typeOptions: [...document.querySelectorAll('.type-option')],
    modeLabel: document.querySelector('#mode-label'),
    sendStatus: document.querySelector('#send-status'),
    sendButton: document.querySelector('#send-button'),
    overlay: document.querySelector('#expanded-overlay'),
    expandedTitle: document.querySelector('#expanded-title'),
    expandedBody: document.querySelector('#expanded-body'),
    closeExpanded: document.querySelector('#close-expanded'),
    copyExpanded: document.querySelector('#copy-expanded')
  };

  let mode = 'text';
  let connected = false;
  let expanded = false;
  let defaultTarget = null;
  let selectedSenderKey = '';
  let unreadSummary = [];
  const conversations = new Map();
  const expiryTimers = new Map();

  function reportLayout() {
    if (!window.censoredFlowWindow?.reportLayout) return;

    requestAnimationFrame(() => {
      const popup = document.querySelector('.popup');
      const popupHeight = popup
        ? Math.ceil(popup.getBoundingClientRect().height + 16)
        : 320;

      window.censoredFlowWindow.reportLayout({
        height: popupHeight,
        expanded
      });
    });
  }

  function scheduleLayout() {
    requestAnimationFrame(() => requestAnimationFrame(reportLayout));
  }

  function senderKey(sender) {
    const discordUserId = String(sender?.discordUserId || '').trim();
    if (discordUserId) return 'discord:' + discordUserId;
    const userId = String(sender?.userId || '').trim();
    return userId ? 'cf:' + userId : 'unknown';
  }

  function badgeLabel(count) {
    const n = Math.max(0, Number(count) || 0);
    if (n < 1) return '';
    return n >= 9 ? '9+' : String(n) + '+';
  }

  function formatBytes(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    const kb = bytes / 1024;
    return Number.isInteger(kb) ? `${kb} KB` : `${kb.toFixed(1)} KB`;
  }

  function initials(name) {
    return String(name || '?')
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map((part) => part[0] || '')
      .join('')
      .toUpperCase() || '?';
  }

  function applyAvatar(node, sender) {
    const name = sender?.displayName || sender?.userId || 'Participante';
    if (sender?.avatarUrl) {
      node.textContent = '';
      node.style.backgroundImage = `url("${sender.avatarUrl}")`;
      node.classList.add('has-image');
    } else {
      node.style.backgroundImage = '';
      node.classList.remove('has-image');
      node.textContent = initials(name);
    }
  }

  function unreadCountFor(key) {
    return Number(unreadSummary.find((item) => item.senderKey === key)?.count) || 0;
  }

  function ensureConversationForSender(sender) {
    const key = senderKey(sender);
    let entry = conversations.get(key);
    if (!entry) {
      entry = {
        senderKey: key,
        sender: sender || {},
        messages: []
      };
      conversations.set(key, entry);
    } else if (sender && typeof sender === 'object') {
      entry.sender = { ...entry.sender, ...sender };
    }
    return entry;
  }

  function ensureConversation(message) {
    const entry = ensureConversationForSender(message.sender);

    if (!entry.messages.some((item) => item.id === message.id)) {
      entry.messages.push(message);
      entry.messages.sort((a, b) => Number(a.createdAt) - Number(b.createdAt));
    }

    scheduleMessageExpiry(message);
    return entry;
  }

  function scheduleMessageExpiry(message) {
    if (!message?.id || !Number.isInteger(message.expiresAt)) return;
    if (expiryTimers.has(message.id)) clearTimeout(expiryTimers.get(message.id));

    const delay = Math.max(0, message.expiresAt - Date.now());
    const timer = setTimeout(() => {
      expiryTimers.delete(message.id);
      removeMessage(message.id);
    }, Math.min(delay + 10, 2_147_483_647));

    expiryTimers.set(message.id, timer);
  }

  function removeMessage(id) {
    let changed = false;
    for (const [key, entry] of conversations.entries()) {
      const next = entry.messages.filter((message) => message.id !== id);
      if (next.length !== entry.messages.length) {
        entry.messages = next;
        changed = true;
      }
      if (!entry.messages.length) conversations.delete(key);
    }

    if (expiryTimers.has(id)) {
      clearTimeout(expiryTimers.get(id));
      expiryTimers.delete(id);
    }

    if (changed) {
      if (selectedSenderKey && !conversations.has(selectedSenderKey)) {
        selectedSenderKey = conversations.keys().next().value || '';
      }
      renderAll();
    }
  }

  function latestFor(key) {
    const entry = conversations.get(key);
    if (!entry?.messages?.length) return null;
    return entry.messages[entry.messages.length - 1];
  }

  function renderPeople() {
    el.peopleList.replaceChildren();

    const entries = [...conversations.values()]
      .sort((a, b) => {
        const am = a.messages[a.messages.length - 1];
        const bm = b.messages[b.messages.length - 1];
        return Number(bm?.createdAt || 0) - Number(am?.createdAt || 0);
      });

    el.peopleSection.hidden = entries.length < 1;

    for (const entry of entries) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'person-row';
      button.classList.toggle('active', entry.senderKey === selectedSenderKey);
      button.dataset.senderKey = entry.senderKey;

      const avatar = document.createElement('span');
      avatar.className = 'person-avatar';
      applyAvatar(avatar, entry.sender);

      const copy = document.createElement('span');
      copy.className = 'person-copy';

      const name = document.createElement('strong');
      name.textContent = entry.sender?.displayName || entry.sender?.userId || 'Participante';

      const latest = entry.messages[entry.messages.length - 1];
      const preview = document.createElement('small');
      preview.textContent = String(latest?.payload || '').replace(/\s+/g, ' ').slice(0, 54) || 'Mensagem';

      copy.append(name, preview);

      const count = unreadCountFor(entry.senderKey);
      const badge = document.createElement('span');
      badge.className = 'person-unread';
      badge.hidden = count < 1;
      badge.textContent = badgeLabel(count);

      button.append(avatar, copy, badge);
      button.addEventListener('click', () => {
        selectedSenderKey = entry.senderKey;
        renderAll();
        el.input.focus();
      });

      el.peopleList.append(button);
    }
  }

  function renderSelected() {
    const entry = conversations.get(selectedSenderKey);
    const hasConversation = Boolean(entry);

    el.conversation.hidden = !hasConversation;
    el.emptyState.hidden = hasConversation;

    if (!entry) {
      el.panelSubtitle.textContent = connected
        ? 'CensoredFlow · conectado'
        : 'CensoredFlow · conectando';
      scheduleLayout();
      return;
    }

    const sender = entry.sender || {};
    const latest = latestFor(selectedSenderKey);
    const unread = unreadCountFor(selectedSenderKey);
    const name = sender.displayName || sender.userId || 'Participante';

    el.panelSubtitle.textContent = name;
    el.peerName.textContent = name;
    el.peerMeta.textContent = entry.messages.length === 1
      ? '1 mensagem nesta sessão'
      : `${entry.messages.length} mensagens nesta sessão`;
    applyAvatar(el.peerAvatar, sender);

    el.selectedUnread.hidden = unread < 1;
    el.selectedUnread.textContent = badgeLabel(unread);

    if (latest) {
      el.receivedCard.hidden = false;
      el.receivedType.textContent = latest.type === 'prompt' ? 'PROMPT' : 'RÁPIDA';
      el.receivedTime.textContent = new Date(latest.createdAt).toLocaleTimeString('pt-BR', {
        hour: '2-digit',
        minute: '2-digit'
      });
      el.receivedPreview.textContent = latest.payload;
    } else {
      el.receivedCard.hidden = true;
    }

    refreshComposer();
    scheduleLayout();
  }

  function renderAll() {
    if (!selectedSenderKey || !conversations.has(selectedSenderKey)) {
      selectedSenderKey = conversations.keys().next().value || '';
    }
    renderPeople();
    renderSelected();
  }

  function applyState(state) {
    connected = Boolean(state?.connected);
    defaultTarget = state?.target || null;
    el.connectionDot.classList.toggle('ok', connected);
    el.connectionDot.title = connected ? 'Relay conectado' : 'Relay desconectado';
    renderSelected();
  }

  function currentUsage() {
    return limits.payloadUsage(mode, el.input.value);
  }

  function refreshComposer() {
    const usage = currentUsage();
    const maxLabel = formatBytes(usage.maxBytes);
    const hasContent = el.input.value.trim().length > 0;
    const hasConversation = Boolean(selectedSenderKey && conversations.has(selectedSenderKey));

    el.usageLabel.textContent = `${formatBytes(usage.bytes)} / ${maxLabel}`;
    el.usagePercent.textContent = `${usage.percent}%`;
    el.usageBar.style.width = `${Math.min(100, usage.percent)}%`;
    el.usageTrack.setAttribute('aria-valuenow', String(Math.min(100, usage.percent)));
    el.usageTrack.classList.toggle('warning', usage.percent >= 80 && !usage.overLimit);
    el.usageTrack.classList.toggle('over', usage.overLimit);

    if (usage.overLimit) {
      el.sendStatus.textContent = `Limite: ${maxLabel}`;
    } else if (!connected) {
      el.sendStatus.textContent = 'Conectando...';
    } else if (!hasConversation) {
      el.sendStatus.textContent = 'Selecione uma conversa.';
    } else if (!hasContent) {
      el.sendStatus.textContent = mode === 'prompt' ? 'Cole seu prompt.' : 'Pronto.';
    } else if (usage.percent >= 80) {
      el.sendStatus.textContent = 'Perto do limite.';
    } else {
      el.sendStatus.textContent = 'Pronto.';
    }

    el.sendButton.disabled = !connected || !hasConversation || !hasContent || usage.overLimit;
  }

  function closeTypeMenu() {
    el.typeMenu.hidden = true;
    el.typeButton.setAttribute('aria-expanded', 'false');
  }

  function setMode(nextMode) {
    if (!limits.MESSAGE_LIMITS[nextMode]) return;
    mode = nextMode;

    for (const option of el.typeOptions) {
      option.classList.toggle('active', option.dataset.mode === mode);
    }

    const prompt = mode === 'prompt';
    el.composer.classList.toggle('prompt-mode', prompt);
    el.input.rows = prompt ? 6 : 3;
    el.input.placeholder = prompt
      ? 'Cole seu prompt, código ou texto longo...'
      : 'Digite uma mensagem...';
    el.modeLabel.textContent = prompt ? 'Prompt · 32 KB' : 'Rápida · 2 KB';

    closeTypeMenu();
    refreshComposer();
    scheduleLayout();
    el.input.focus();
  }

  async function sendCurrent() {
    const payload = el.input.value;
    const usage = currentUsage();

    if (
      !payload.trim() ||
      usage.overLimit ||
      !connected ||
      !selectedSenderKey ||
      el.sendButton.dataset.busy === '1'
    ) return;

    el.sendButton.dataset.busy = '1';
    el.sendButton.disabled = true;
    el.sendButton.textContent = '...';
    el.sendStatus.textContent = 'Enviando...';

    try {
      const response = await fetch('/api/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode, payload })
      });
      const result = await response.json();

      if (!response.ok || !result.ok) {
        throw new Error(result.message || result.code || 'Falha ao enviar.');
      }

      el.input.value = '';
      el.sendStatus.textContent = result.deliveredDevices > 0
        ? 'Entregue.'
        : 'Offline · nada armazenado.';
    } catch (error) {
      el.sendStatus.textContent = error.message || 'Falha ao enviar.';
    } finally {
      delete el.sendButton.dataset.busy;
      el.sendButton.textContent = 'Enviar';
      refreshComposer();
      el.input.focus();
    }
  }

  async function copyText(text, button) {
    const original = button.textContent;
    try {
      await navigator.clipboard.writeText(text);
      button.textContent = 'Copiado';
    } catch {
      button.textContent = 'Falhou';
    }
    setTimeout(() => { button.textContent = original; }, 1200);
  }

  function markSenderSelected(key) {
    if (!key || !conversations.has(key)) return;
    selectedSenderKey = key;
    renderAll();
  }

  function markSenderReadLocally(key) {
    const entry = conversations.get(key);
    if (!entry) return;
    unreadSummary = unreadSummary.filter((item) => item.senderKey !== key);
    renderAll();
  }

  function openExpanded() {
    const latest = latestFor(selectedSenderKey);
    if (!latest) return;

    expanded = true;
    const sender = conversations.get(selectedSenderKey)?.sender || {};
    el.expandedTitle.textContent =
      `${sender.displayName || 'CensoredFlow'} · ${latest.type === 'prompt' ? 'Prompt' : 'Mensagem'}`;
    el.expandedBody.textContent = latest.payload;
    el.overlay.hidden = false;
    reportLayout();
    el.closeExpanded.focus();
  }

  function closeExpanded() {
    expanded = false;
    el.overlay.hidden = true;
    scheduleLayout();
    el.expandButton.focus();
  }

  async function loadState() {
    const response = await fetch('/api/state', { cache: 'no-store' });
    if (!response.ok) throw new Error('Falha ao obter estado.');
    applyState(await response.json());
  }

  function connectEvents() {
    const events = new EventSource('/events');

    events.addEventListener('status', (event) => {
      try { applyState(JSON.parse(event.data)); } catch {}
    });

    events.addEventListener('message', (event) => {
      try {
        const message = JSON.parse(event.data);
        const entry = ensureConversation(message);
        if (!selectedSenderKey) selectedSenderKey = entry.senderKey;
        renderAll();
      } catch {}
    });

    events.addEventListener('unread', (event) => {
      try {
        unreadSummary = JSON.parse(event.data);
        renderAll();
      } catch {}
    });

    events.addEventListener('conversation-open', (event) => {
      try {
        const value = JSON.parse(event.data);
        markSenderReadLocally(value.senderKey);
        markSenderSelected(value.senderKey);
      } catch {}
    });

    events.addEventListener('conversation-start', (event) => {
      try {
        const value = JSON.parse(event.data);
        const entry = ensureConversationForSender(value.sender || {});
        selectedSenderKey = value.senderKey || entry.senderKey;
        renderAll();
        el.input.focus();
      } catch {}
    });

    events.addEventListener('notification-open', (event) => {
      try {
        const value = JSON.parse(event.data);
        if (value.senderKey) {
          selectedSenderKey = value.senderKey;
          renderAll();
        }
      } catch {}
    });

    events.addEventListener('notification-dismiss', (event) => {
      try {
        const value = JSON.parse(event.data);
        if (value.id) removeMessage(value.id);
      } catch {}
    });

    events.addEventListener('message-expired', (event) => {
      try {
        const value = JSON.parse(event.data);
        if (value.id) removeMessage(value.id);
      } catch {}
    });

    events.addEventListener('relay-error', () => {
      connected = false;
      el.connectionDot.classList.remove('ok');
      refreshComposer();
    });

    events.onerror = () => {
      connected = false;
      el.connectionDot.classList.remove('ok');
      refreshComposer();
    };
  }

  el.input.addEventListener('input', refreshComposer);
  el.input.addEventListener('keydown', (event) => {
    if (event.isComposing) return;
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      sendCurrent();
    }
  });

  el.sendButton.addEventListener('click', sendCurrent);
  el.hideWindow.addEventListener('click', () => {
    window.censoredFlowWindow?.hide?.();
  });

  el.typeButton.addEventListener('click', (event) => {
    event.stopPropagation();
    const nextHidden = !el.typeMenu.hidden;
    el.typeMenu.hidden = nextHidden;
    el.typeButton.setAttribute('aria-expanded', String(!nextHidden));
  });

  for (const option of el.typeOptions) {
    option.addEventListener('click', () => setMode(option.dataset.mode));
  }

  document.addEventListener('click', (event) => {
    if (!event.target.closest('.type-menu-wrap')) closeTypeMenu();
  });

  el.copyButton.addEventListener('click', () => {
    const latest = latestFor(selectedSenderKey);
    if (latest) copyText(latest.payload, el.copyButton);
  });

  el.expandButton.addEventListener('click', openExpanded);
  el.closeExpanded.addEventListener('click', closeExpanded);
  el.copyExpanded.addEventListener('click', () => {
    const latest = latestFor(selectedSenderKey);
    if (latest) copyText(latest.payload, el.copyExpanded);
  });

  el.overlay.addEventListener('click', (event) => {
    if (event.target === el.overlay) closeExpanded();
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !el.overlay.hidden) {
      closeExpanded();
    } else if (event.key === 'Escape' && !el.typeMenu.hidden) {
      closeTypeMenu();
    }
  });

  const popup = document.querySelector('.popup');
  if (popup && typeof ResizeObserver === 'function') {
    const observer = new ResizeObserver(() => {
      if (!expanded) scheduleLayout();
    });
    observer.observe(popup);
  }

  setMode('text');
  loadState()
    .then(scheduleLayout)
    .catch(() => {
      refreshComposer();
      scheduleLayout();
    });
  connectEvents();
})();
