param(
  [string]$PendingFile = '',
  [string]$Root = '',
  [string]$Package = '',
  [string]$FromVersion = '',
  [string]$ToVersion = '',
  [string]$ExpectedSha256 = '',
  [string]$RunNpmCi = '0'
)

$ErrorActionPreference = 'Stop'

if ($PendingFile) {
  if (-not (Test-Path $PendingFile)) { throw 'Arquivo pending-apply.json ausente.' }
  $pending = Get-Content $PendingFile -Raw | ConvertFrom-Json
  $Root = [string]$pending.root
  $Package = [string]$pending.package
  $FromVersion = [string]$pending.fromVersion
  $ToVersion = [string]$pending.toVersion
  $ExpectedSha256 = [string]$pending.expectedSha256
  $RunNpmCi = [string]$pending.runNpmCi
}

foreach ($pair in @(
  @{ Name='Root'; Value=$Root },
  @{ Name='Package'; Value=$Package },
  @{ Name='FromVersion'; Value=$FromVersion },
  @{ Name='ToVersion'; Value=$ToVersion },
  @{ Name='ExpectedSha256'; Value=$ExpectedSha256 }
)) {
  if ([string]::IsNullOrWhiteSpace([string]$pair.Value)) {
    throw ('Parametro obrigatorio ausente: ' + $pair.Name)
  }
}
$lockPath = Join-Path $Root 'update.lock'
$logPath = Join-Path $Root 'updater.log'
$backupBase = Join-Path $Root 'update-backups'
$updatesDir = Join-Path $Root '.updates'
$extractDir = Join-Path $env:TEMP ('DiscordVoiceWidget-Update-' + $ToVersion + '-' + $PID)
$electron = Join-Path $Root 'node_modules\electron\dist\electron.exe'
$backupDir = Join-Path $backupBase ($FromVersion + '-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
function Invoke-NodeRuntime {
  param([string[]]$NodeArgs)

  $bundled = Join-Path $Root 'runtime-node.exe'
  if (Test-Path $bundled) {
    & $bundled @NodeArgs
    return [int]$LASTEXITCODE
  }

  $node = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($node) {
    & $node.Source @NodeArgs
    return [int]$LASTEXITCODE
  }

  throw 'Runtime de validacao ausente. Reinstale o Discord Voice Widget.'
}

$managedFiles = @()

function Normalize-ManagedFileName {
  param([string]$Name)

  if ([string]::IsNullOrWhiteSpace($Name)) {
    throw 'Nome vazio em update-files.json.'
  }

  $normalized = ([string]$Name).Trim().Replace('/', '\')
  if ([IO.Path]::IsPathRooted($normalized)) {
    throw ('Caminho absoluto proibido no update: ' + $Name)
  }

  $segments = @($normalized -split '\\')
  if ($segments.Count -lt 1) {
    throw ('Nome de arquivo invalido no update: ' + $Name)
  }

  foreach ($segment in $segments) {
    if (
      [string]::IsNullOrWhiteSpace($segment) -or
      $segment -eq '.' -or
      $segment -eq '..' -or
      $segment.IndexOfAny([char[]]':*?"<>|') -ge 0
    ) {
      throw ('Segmento de caminho invalido no update: ' + $Name)
    }
  }

  if ($segments.Count -gt 1 -and $segments[0] -ne 'messaging') {
    throw ('Subpasta nao autorizada no update: ' + $Name)
  }

  $extractRoot = [IO.Path]::GetFullPath($extractDir).TrimEnd('\') + '\'
  $full = [IO.Path]::GetFullPath((Join-Path $extractDir $normalized))
  if (-not $full.StartsWith($extractRoot, [StringComparison]::OrdinalIgnoreCase)) {
    throw ('Path traversal bloqueado no update: ' + $Name)
  }

  if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
    throw ('Arquivo listado no update esta ausente: ' + $Name)
  }

  return $normalized
}

function Ensure-ParentDirectory {
  param([string]$FilePath)
  $parent = Split-Path -Parent $FilePath
  if ($parent -and -not (Test-Path -LiteralPath $parent)) {
    New-Item -ItemType Directory -Path $parent -Force | Out-Null
  }
}


function Get-ManagedFilesFromPackage {
  $manifestPath = Join-Path $extractDir 'update-files.json'

  if (Test-Path $manifestPath) {
    try {
      $doc = Get-Content $manifestPath -Raw | ConvertFrom-Json
      $files = @($doc.files | ForEach-Object { [string]$_ })
    } catch {
      throw 'update-files.json invalido.'
    }

    if ($files.Count -lt 1) {
      throw 'update-files.json nao contem arquivos.'
    }

    $clean = New-Object System.Collections.Generic.List[string]
    $seen = @{}

    foreach ($name in $files) {
      $normalized = Normalize-ManagedFileName -Name $name

      if (-not $seen.ContainsKey($normalized)) {
        $seen[$normalized] = $true
        $clean.Add($normalized)
      }
    }

    return $clean.ToArray()
  }

  # Compatibilidade com pacotes antigos que nao tinham update-files.json.
  return @(
    'main.js','preload.js','rpc-client.js','volume.html','volume-preload.js',
    'setup.html','global.html','package.json','package-lock.json','updater-client.js',
    'updater-public-key.pem','updater.defaults.json','ApplyUpdateV21.ps1',
    'WatchDiscordWidgetV21.ps1','EnsureDiscordWidgetV21.ps1',
    'StartDiscordWidgetV21Watcher.vbs','RunGuardianV21.vbs','RunApplyUpdateV21.vbs'
  )
}

function Log([string]$Message) {
  try {
    Add-Content -Path $logPath -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $Message) -Encoding UTF8
  } catch {}
}

function Stop-Widget {
  try {
    Get-Process electron -ErrorAction SilentlyContinue |
      Where-Object { $_.Path -eq $electron } |
      Stop-Process -Force -ErrorAction SilentlyContinue
  } catch {}

  $until = (Get-Date).AddSeconds(8)
  while ((Get-Date) -lt $until) {
    $left = @(Get-Process electron -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $electron })
    if ($left.Count -eq 0) { return }
    Start-Sleep -Milliseconds 250
  }
  throw 'Nao foi possivel encerrar completamente a V2.1 para atualizar.'
}

function Backup-ManagedFiles {
  New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
  foreach ($name in $managedFiles) {
    $src = Join-Path $Root $name
    if (Test-Path -LiteralPath $src -PathType Leaf) {
      $dst = Join-Path $backupDir $name
      Ensure-ParentDirectory -FilePath $dst
      Copy-Item -LiteralPath $src -Destination $dst -Force
    }
  }
  $userState = @('config.json','rpc.auth.bin','rpc.config.json','updater.local.json')
  foreach ($name in $userState) {
    $src = Join-Path $Root $name
    if (Test-Path $src) {
      Copy-Item $src (Join-Path $backupDir ('USERSTATE-' + $name)) -Force
    }
  }
}

function Restore-Backup {
  Log ('ROLLBACK iniciado para ' + $FromVersion)
  foreach ($name in $managedFiles) {
    $old = Join-Path $backupDir $name
    $dst = Join-Path $Root $name
    if (Test-Path -LiteralPath $old -PathType Leaf) {
      Ensure-ParentDirectory -FilePath $dst
      Copy-Item -LiteralPath $old -Destination $dst -Force
    } elseif (Test-Path -LiteralPath $dst -PathType Leaf) {
      Remove-Item -LiteralPath $dst -Force -ErrorAction SilentlyContinue
    }
  }
  Log 'ROLLBACK de arquivos concluido.'
}

function Validate-Extracted {
  $required = @(
    'main.js','preload.js','rpc-client.js','volume.html','volume-preload.js',
    'setup.html','global.html','package.json','package-lock.json','updater-client.js',
    'updater-public-key.pem','updater.defaults.json',
    'ApplyUpdateV21.ps1','WatchDiscordWidgetV21.ps1','EnsureDiscordWidgetV21.ps1',
    'VirtualDesktopAccessor.dll','VirtualDesktopAccessor-LICENSE.txt','PinWidgetAllDesktops.ps1','GameModeWatcher.ps1',
    'StartDiscordWidgetV21Watcher.vbs','RunGuardianV21.vbs',
    'RunApplyUpdateV21.vbs'
  )
  foreach ($name in $required) {
    if (-not (Test-Path (Join-Path $extractDir $name))) {
      throw ('Pacote de atualizacao incompleto: ' + $name)
    }
  }

  foreach ($name in @($managedFiles | Where-Object { $_.ToLowerInvariant().EndsWith('.js') })) {
    $nodeCode = Invoke-NodeRuntime -NodeArgs @('--check', (Join-Path $extractDir $name))
    if ($nodeCode -ne 0) {
      throw ('Falha de sintaxe no pacote: ' + $name)
    }
  }

  $jsonFiles = @($managedFiles | Where-Object { $_.ToLowerInvariant().EndsWith('.json') })
  if ($jsonFiles.Count -gt 0) {
    $jsonArgs = @(
      '-e',
      "const fs=require('fs'); for(const f of process.argv.slice(1)){JSON.parse(fs.readFileSync(f,'utf8'));}"
    ) + @($jsonFiles | ForEach-Object { Join-Path $extractDir $_ })

    $jsonCode = Invoke-NodeRuntime -NodeArgs $jsonArgs
    if ($jsonCode -ne 0) {
      throw 'JSON invalido no pacote de atualizacao.'
    }
  }
}

function Copy-NewFiles {
  $rootFull = [IO.Path]::GetFullPath($Root).TrimEnd('\') + '\'

  foreach ($name in $managedFiles) {
    $src = Join-Path $extractDir $name
    $dst = Join-Path $Root $name
    $dstFull = [IO.Path]::GetFullPath($dst)

    if (-not $dstFull.StartsWith($rootFull, [StringComparison]::OrdinalIgnoreCase)) {
      throw ('Destino fora da raiz bloqueado: ' + $name)
    }

    Ensure-ParentDirectory -FilePath $dst
    Copy-Item -LiteralPath $src -Destination $dst -Force
  }
}

function Prune-Backups {
  try {
    $dirs = @(Get-ChildItem $backupBase -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    if ($dirs.Count -gt 3) {
      $dirs | Select-Object -Skip 3 | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    }
  } catch {}
}

try {
  New-Item -ItemType Directory -Path $backupBase -Force | Out-Null
  New-Item -ItemType Directory -Path $updatesDir -Force | Out-Null
  New-Item -ItemType Directory -Path $extractDir -Force | Out-Null

  Set-Content -Path $lockPath -Value ('Updating ' + $FromVersion + ' -> ' + $ToVersion) -Encoding ASCII
  Log ('Atualizacao iniciada: ' + $FromVersion + ' -> ' + $ToVersion)

  if (-not (Test-Path $Package)) { throw 'Arquivo ZIP da atualizacao nao encontrado.' }

  $actualHash = (Get-FileHash $Package -Algorithm SHA256).Hash.ToUpperInvariant()
  if ($actualHash -ne $ExpectedSha256.ToUpperInvariant()) {
    throw 'SHA256 do ZIP nao confere no aplicador.'
  }

  Expand-Archive -Path $Package -DestinationPath $extractDir -Force
  $script:managedFiles = @(Get-ManagedFilesFromPackage)
  Validate-Extracted
  Stop-Widget
  Backup-ManagedFiles
  Copy-NewFiles

  if ($RunNpmCi -eq '1') {
    Log 'Dependencias alteradas; executando npm ci.'
    Push-Location $Root
    try {
      & npm.cmd ci
      if ($LASTEXITCODE -ne 0) {
        throw ('npm ci falhou com codigo ' + $LASTEXITCODE)
      }
    }
    finally {
      Pop-Location
    }
  }

  foreach ($name in @($managedFiles | Where-Object { $_.ToLowerInvariant().EndsWith('.js') })) {
    $finalNodeCode = Invoke-NodeRuntime -NodeArgs @('--check', (Join-Path $Root $name))
    if ($finalNodeCode -ne 0) {
      throw ('Arquivo JS instalado falhou na validacao final: ' + $name)
    }
  }

  $finalJsonFiles = @($managedFiles | Where-Object { $_.ToLowerInvariant().EndsWith('.json') })
  if ($finalJsonFiles.Count -gt 0) {
    $jsonArgs = @('-e', "const fs=require('fs'); for(const f of process.argv.slice(1)){JSON.parse(fs.readFileSync(f,'utf8'));}") +
      @($finalJsonFiles | ForEach-Object { Join-Path $Root $_ })
    $finalJsonCode = Invoke-NodeRuntime -NodeArgs $jsonArgs
    if ($finalJsonCode -ne 0) {
      throw 'Arquivo JSON instalado falhou na validacao final.'
    }
  }

  Set-Content -Path (Join-Path $Root 'last-update.json') -Value (
    @{
      ok = $true
      fromVersion = $FromVersion
      toVersion = $ToVersion
      completedAt = (Get-Date).ToString('o')
      backup = $backupDir
    } | ConvertTo-Json -Depth 4
  ) -Encoding UTF8

  Remove-Item (Join-Path $updatesDir 'ready.json') -Force -ErrorAction SilentlyContinue
  Remove-Item $Package -Force -ErrorAction SilentlyContinue
  Prune-Backups
  Log ('Atualizacao concluida com sucesso: ' + $ToVersion)
}
catch {
  $message = $_.Exception.Message
  Log ('ERRO na atualizacao: ' + $message)
  try {
    if (Test-Path $backupDir) {
      Restore-Backup
      if ($RunNpmCi -eq '1') {
        Push-Location $Root
        try { & npm.cmd ci | Out-Null } catch {}
        finally { Pop-Location }
      }
    }
  } catch {
    Log ('ERRO adicional no rollback: ' + $_.Exception.Message)
  }

  try {
    Set-Content -Path (Join-Path $Root 'last-update.json') -Value (
      @{
        ok = $false
        fromVersion = $FromVersion
        toVersion = $ToVersion
        failedAt = (Get-Date).ToString('o')
        error = $message
        backup = $backupDir
      } | ConvertTo-Json -Depth 4
    ) -Encoding UTF8
  } catch {}
}
finally {
  Remove-Item $extractDir -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item (Join-Path $updatesDir 'pending-apply.json') -Force -ErrorAction SilentlyContinue
  Remove-Item $lockPath -Force -ErrorAction SilentlyContinue

  Start-Sleep -Milliseconds 500
  try {
    $discordRunning = @(Get-Process Discord -ErrorAction SilentlyContinue).Count -gt 0
    $widgetRunning = @(Get-Process electron -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $electron }).Count -gt 0
    if ($discordRunning -and -not $widgetRunning -and (Test-Path $electron)) {
      Start-Process -FilePath $electron -ArgumentList ('"' + $Root + '"')
    }
  } catch {}
}
