const { EventEmitter } = require('events');
const {
  resolveDisplayIdentity,
  validateUserProfile
} = require('../service/user-profile');
const {
  MESSAGE_LIMITS,
  payloadUsage
} = require('../protocol/limits');
const { MAX_TTL_MS } = require('../service/ttl');

class MessagingBridge extends EventEmitter {
  constructor({
    messagingService,
    selfProfile,
    targetProfile
  }) {
    super();
    this.messagingService = messagingService;
    this.selfProfile = selfProfile;
    this.targetProfile = targetProfile || null;
    this.connected = false;

    messagingService.on('message', (message, senderProfile) => {
      this.emit('message', this._presentMessage(message, senderProfile));
    });
    messagingService.on('rejected', (event) => this.emit('rejected', event));
    messagingService.on('relayError', (event) => this.emit('relayError', event));
    messagingService.on('close', () => {
      this.connected = false;
      this.emit('status', this.snapshot());
    });
  }

  async start() {
    await this.messagingService.start();
    this.connected = true;
    this.emit('status', this.snapshot());
    return this;
  }

  snapshot() {
    return {
      connected: this.connected,
      self: resolveDisplayIdentity(this.selfProfile),
      target: this.targetProfile ? resolveDisplayIdentity(this.targetProfile) : null,
      limits: MESSAGE_LIMITS
    };
  }

  async resolveRecipientProfileByDiscordUserId(discordUserId) {
    const clean = String(discordUserId || '').trim();
    if (!/^\d{5,30}$/.test(clean)) return null;

    if (
      this.targetProfile &&
      String(this.targetProfile?.discord?.discordUserId || '').trim() === clean
    ) {
      return this.targetProfile;
    }

    const transport = this.messagingService?.transport;
    if (!transport || typeof transport.resolveDiscordUser !== 'function') {
      return null;
    }

    const profile = await transport.resolveDiscordUser(clean);
    if (!profile) return null;
    validateUserProfile(profile);
    return profile;
  }

  async resolveRecipientByDiscordUserId(discordUserId) {
    const profile = await this.resolveRecipientProfileByDiscordUserId(discordUserId);
    return profile ? resolveDisplayIdentity(profile) : null;
  }

  async startConversationByDiscordUserId(discordUserId) {
    const profile = await this.resolveRecipientProfileByDiscordUserId(discordUserId);
    if (!profile) return null;

    this.targetProfile = profile;
    const recipient = resolveDisplayIdentity(profile);
    this.emit('status', this.snapshot());
    return recipient;
  }

  async send({ mode, payload }) {
    if (!this.connected) {
      throw new Error('Messaging bridge is not connected.');
    }

    const type = mode === 'prompt' ? 'prompt' : 'text';
    const usage = payloadUsage(type, payload);
    if (usage.overLimit) {
      const error = new RangeError(
        `Payload exceeds ${usage.maxBytes} UTF-8 bytes for ${type}.`
      );
      error.code = 'PAYLOAD_TOO_LARGE';
      throw error;
    }

    if (!this.targetProfile) {
      const error = new Error('No Messaging recipient is selected.');
      error.code = 'NO_RECIPIENT_SELECTED';
      throw error;
    }

    const result = await this.messagingService.send({
      toUser: this.targetProfile.userId,
      type,
      payload,
      ttlMs: MAX_TTL_MS
    });

    return {
      messageId: result.message.id,
      deliveredDevices: result.ack.deliveredDevices,
      bytes: usage.bytes,
      maxBytes: usage.maxBytes
    };
  }

  _presentMessage(message, senderProfile = null) {
    let profile = senderProfile;

    if (!profile && this.targetProfile && message.fromUser === this.targetProfile.userId) {
      profile = this.targetProfile;
    }
    if (!profile && message.fromUser === this.selfProfile.userId) {
      profile = this.selfProfile;
    }
    if (!profile) {
      profile = this.messagingService?.transport?.getCachedProfile?.(message.fromUser) || null;
    }
    if (!profile) {
      profile = {
        userId: message.fromUser,
        displayName: message.fromUser,
        discord: null,
        devices: []
      };
    }

    return {
      id: message.id,
      type: message.type,
      payload: message.payload,
      createdAt: message.createdAt,
      expiresAt: message.expiresAt,
      sender: resolveDisplayIdentity(profile)
    };
  }

  close() {
    this.messagingService.close();
    this.connected = false;
  }
}

module.exports = {
  MessagingBridge
};
