const crypto = require('crypto');
const fs = require('fs');
const { deviceIdFromPublicKey, isValidDeviceId } = require('./identity');

const USER_ID_BYTES = 10;

function generateUserId() {
  const compact = crypto.randomBytes(USER_ID_BYTES).toString('hex').toUpperCase();
  const groups = compact.match(/.{1,4}/g) || [];
  return 'CF-U-' + groups.join('-');
}

function isValidUserId(value) {
  return /^CF-U-[A-F0-9]{4}(?:-[A-F0-9]{4}){4}$/.test(String(value || ''));
}

function cloneProfile(profile) {
  return JSON.parse(JSON.stringify(profile));
}

function createUserProfile({
  userId = generateUserId(),
  displayName = '',
  discord = null,
  devices = []
} = {}) {
  if (!isValidUserId(userId)) {
    throw new TypeError('userId must be a valid CensoredFlow User ID.');
  }

  const cleanName = String(displayName || '').trim();
  if (cleanName.length > 100) {
    throw new RangeError('displayName exceeds 100 characters.');
  }

  let profile = {
    schemaVersion: 1,
    userId,
    displayName: cleanName,
    discord: null,
    devices: []
  };

  if (discord) profile = linkDiscord(profile, discord);
  for (const device of devices) profile = authorizeDevice(profile, device);

  return Object.freeze(profile);
}

function validateDiscordLink(link) {
  if (!link || typeof link !== 'object') {
    throw new TypeError('discord link must be an object.');
  }

  const discordUserId = String(link.discordUserId || '').trim();
  if (!/^\d{5,30}$/.test(discordUserId)) {
    throw new TypeError('discordUserId must be a numeric Discord user id.');
  }

  const displayName = String(link.displayName || '').trim();
  if (!displayName || displayName.length > 100) {
    throw new TypeError('Discord displayName is required and must be <= 100 characters.');
  }

  let avatarUrl = null;
  if (link.avatarUrl !== null && link.avatarUrl !== undefined && String(link.avatarUrl).trim()) {
    const raw = String(link.avatarUrl).trim();
    let parsed;
    try {
      parsed = new URL(raw);
    } catch {
      throw new TypeError('Discord avatarUrl must be a valid URL.');
    }
    if (parsed.protocol !== 'https:') {
      throw new TypeError('Discord avatarUrl must use https.');
    }
    avatarUrl = parsed.toString();
  }

  return {
    discordUserId,
    displayName,
    avatarUrl
  };
}

function linkDiscord(profile, link) {
  const next = cloneProfile(profile);
  next.discord = validateDiscordLink(link);
  return Object.freeze(next);
}

function unlinkDiscord(profile) {
  const next = cloneProfile(profile);
  next.discord = null;
  return Object.freeze(next);
}

function authorizeDevice(profile, { deviceId, publicKeyPem, label = '' }) {
  if (!isValidDeviceId(deviceId)) {
    throw new TypeError('deviceId must be a valid CensoredFlow Device ID.');
  }

  const derived = deviceIdFromPublicKey(publicKeyPem);
  if (derived !== deviceId) {
    throw new Error('Device ID does not match the supplied public key.');
  }

  const cleanLabel = String(label || '').trim();
  if (cleanLabel.length > 80) {
    throw new RangeError('device label exceeds 80 characters.');
  }

  const next = cloneProfile(profile);
  const entry = {
    deviceId,
    label: cleanLabel,
    publicKeyPem: String(publicKeyPem),
    authorized: true
  };

  const index = next.devices.findIndex((item) => item.deviceId === deviceId);
  if (index >= 0) next.devices[index] = entry;
  else next.devices.push(entry);

  return Object.freeze(next);
}

function revokeDevice(profile, deviceId) {
  const next = cloneProfile(profile);
  const device = next.devices.find((item) => item.deviceId === deviceId);
  if (!device) return Object.freeze(next);
  device.authorized = false;
  return Object.freeze(next);
}

function isDeviceAuthorized(profile, deviceId, publicKeyPem = null) {
  if (!profile || !Array.isArray(profile.devices)) return false;
  const device = profile.devices.find((item) => item.deviceId === deviceId && item.authorized === true);
  if (!device) return false;

  if (publicKeyPem !== null) {
    try {
      if (deviceIdFromPublicKey(publicKeyPem) !== deviceId) return false;
      if (String(device.publicKeyPem) !== String(publicKeyPem)) return false;
    } catch {
      return false;
    }
  }

  return true;
}

function resolveDisplayIdentity(profile) {
  if (profile && profile.discord) {
    return {
      source: 'discord',
      userId: profile.userId,
      displayName: profile.discord.displayName,
      avatarUrl: profile.discord.avatarUrl,
      discordUserId: profile.discord.discordUserId
    };
  }

  return {
    source: 'censoredflow',
    userId: profile.userId,
    displayName: profile.displayName || profile.userId,
    avatarUrl: null,
    discordUserId: null
  };
}

function validateUserProfile(profile) {
  if (!profile || typeof profile !== 'object') {
    throw new TypeError('profile must be an object.');
  }
  if (!isValidUserId(profile.userId)) {
    throw new TypeError('Invalid CensoredFlow User ID.');
  }
  if (!Array.isArray(profile.devices)) {
    throw new TypeError('profile.devices must be an array.');
  }

  if (profile.discord !== null && profile.discord !== undefined) {
    validateDiscordLink(profile.discord);
  }

  const seen = new Set();
  for (const device of profile.devices) {
    if (seen.has(device.deviceId)) throw new Error('Duplicate device in user profile.');
    seen.add(device.deviceId);

    if (!isValidDeviceId(device.deviceId)) throw new TypeError('Invalid device id in profile.');
    if (deviceIdFromPublicKey(device.publicKeyPem) !== device.deviceId) {
      throw new Error('Profile contains a device/public-key mismatch.');
    }
    if (typeof device.authorized !== 'boolean') {
      throw new TypeError('Device authorization state must be boolean.');
    }
  }

  return true;
}

function writeUserProfile(filePath, profile) {
  validateUserProfile(profile);
  fs.writeFileSync(filePath, JSON.stringify(profile, null, 2) + '\n', 'utf8');
  return filePath;
}

function loadUserProfile(filePath) {
  const profile = JSON.parse(fs.readFileSync(filePath, 'utf8'));
  validateUserProfile(profile);
  return Object.freeze(profile);
}

function linkDiscordProfileFile(filePath, link) {
  const current = loadUserProfile(filePath);
  const normalized = validateDiscordLink(link);

  const existingDiscordUserId = current.discord
    ? String(current.discord.discordUserId || '').trim()
    : '';

  if (existingDiscordUserId && existingDiscordUserId !== normalized.discordUserId) {
    const error = new Error('Discord account differs from the existing CensoredFlow link.');
    error.code = 'DISCORD_LINK_CONFLICT';
    error.existingDiscordUserId = existingDiscordUserId;
    error.incomingDiscordUserId = normalized.discordUserId;
    throw error;
  }

  const next = linkDiscord(current, normalized);
  writeUserProfile(filePath, next);

  return Object.freeze({
    status: existingDiscordUserId ? 'refreshed' : 'linked',
    profile: next
  });
}

module.exports = {
  generateUserId,
  isValidUserId,
  createUserProfile,
  validateDiscordLink,
  linkDiscord,
  unlinkDiscord,
  authorizeDevice,
  revokeDevice,
  isDeviceAuthorized,
  resolveDisplayIdentity,
  validateUserProfile,
  writeUserProfile,
  loadUserProfile,
  linkDiscordProfileFile
};
