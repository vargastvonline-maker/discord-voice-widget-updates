const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const IDENTITY_ALGORITHM = 'Ed25519';
const ID_FINGERPRINT_HEX_LENGTH = 16;

function toPublicKeyObject(publicKey) {
  return crypto.createPublicKey(publicKey);
}

function publicKeyFingerprint(publicKey) {
  const key = toPublicKeyObject(publicKey);
  const der = key.export({ type: 'spki', format: 'der' });
  return crypto.createHash('sha256').update(der).digest('hex').toUpperCase();
}

function fingerprintGroups(publicKey) {
  const compact = publicKeyFingerprint(publicKey).slice(0, ID_FINGERPRINT_HEX_LENGTH);
  return compact.match(/.{1,4}/g) || [];
}

function legacyIdFromPublicKey(publicKey) {
  return 'CF-' + fingerprintGroups(publicKey).join('-');
}

function deviceIdFromPublicKey(publicKey) {
  return 'CF-D-' + fingerprintGroups(publicKey).join('-');
}

function isValidDeviceId(value) {
  return /^CF-D-[A-F0-9]{4}(?:-[A-F0-9]{4}){3}$/.test(String(value || ''));
}

function generateIdentity() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');

  const publicKeyPem = publicKey.export({
    type: 'spki',
    format: 'pem'
  });

  const privateKeyPem = privateKey.export({
    type: 'pkcs8',
    format: 'pem'
  });

  const deviceId = deviceIdFromPublicKey(publicKeyPem);

  return Object.freeze({
    deviceId,
    id: deviceId,
    algorithm: IDENTITY_ALGORITHM,
    publicKeyPem,
    privateKeyPem
  });
}

function validateIdentity(identity) {
  if (!identity || typeof identity !== 'object') {
    throw new TypeError('identity must be an object.');
  }
  if (identity.algorithm !== IDENTITY_ALGORITHM) {
    throw new TypeError('Unsupported identity algorithm.');
  }

  const suppliedId = identity.deviceId || identity.id;
  const derivedId = deviceIdFromPublicKey(identity.publicKeyPem);
  if (derivedId !== suppliedId) {
    throw new Error('Device ID does not match the public key.');
  }

  const challenge = crypto.randomBytes(32);
  const signature = crypto.sign(null, challenge, identity.privateKeyPem);
  const verified = crypto.verify(null, challenge, identity.publicKeyPem, signature);

  if (!verified) {
    throw new Error('Private key does not match the public key.');
  }

  return true;
}

function identityMetadata(identity, createdAt = new Date().toISOString()) {
  return {
    schemaVersion: 2,
    deviceId: identity.deviceId || identity.id,
    algorithm: identity.algorithm,
    createdAt,
    publicKeyFile: 'public-key.pem',
    privateKeyFile: 'private-key.pem'
  };
}

function writeIdentityDirectory(directory, identity = generateIdentity(), options = {}) {
  validateIdentity(identity);
  fs.mkdirSync(directory, { recursive: true });

  const metadata = identityMetadata(identity, options.createdAt);

  fs.writeFileSync(
    path.join(directory, 'identity.json'),
    JSON.stringify(metadata, null, 2) + '\n',
    'utf8'
  );
  fs.writeFileSync(
    path.join(directory, metadata.publicKeyFile),
    identity.publicKeyPem,
    'utf8'
  );
  fs.writeFileSync(
    path.join(directory, metadata.privateKeyFile),
    identity.privateKeyPem,
    { encoding: 'utf8', mode: 0o600 }
  );

  return { ...metadata, directory };
}

function readIdentityFiles(directory) {
  const metadataPath = path.join(directory, 'identity.json');
  const metadata = JSON.parse(fs.readFileSync(metadataPath, 'utf8'));
  const publicKeyFile = metadata.publicKeyFile || 'public-key.pem';
  const privateKeyFile = metadata.privateKeyFile || 'private-key.pem';

  return {
    metadata,
    publicKeyPem: fs.readFileSync(path.join(directory, publicKeyFile), 'utf8'),
    privateKeyPem: fs.readFileSync(path.join(directory, privateKeyFile), 'utf8')
  };
}

function loadIdentityDirectory(directory) {
  const { metadata, publicKeyPem, privateKeyPem } = readIdentityFiles(directory);
  const derivedDeviceId = deviceIdFromPublicKey(publicKeyPem);
  const storedId = metadata.deviceId || metadata.id;

  if (
    storedId !== derivedDeviceId &&
    storedId !== legacyIdFromPublicKey(publicKeyPem)
  ) {
    throw new Error('Stored identity does not match the public key.');
  }

  const identity = {
    deviceId: derivedDeviceId,
    id: derivedDeviceId,
    algorithm: metadata.algorithm,
    publicKeyPem,
    privateKeyPem
  };

  validateIdentity(identity);
  return Object.freeze(identity);
}

function migrateIdentityDirectory(directory) {
  const { metadata, publicKeyPem, privateKeyPem } = readIdentityFiles(directory);
  const identity = {
    deviceId: deviceIdFromPublicKey(publicKeyPem),
    id: deviceIdFromPublicKey(publicKeyPem),
    algorithm: metadata.algorithm,
    publicKeyPem,
    privateKeyPem
  };

  validateIdentity(identity);
  const next = identityMetadata(identity, metadata.createdAt || new Date().toISOString());
  fs.writeFileSync(
    path.join(directory, 'identity.json'),
    JSON.stringify(next, null, 2) + '\n',
    'utf8'
  );

  return Object.freeze(identity);
}

module.exports = {
  IDENTITY_ALGORITHM,
  publicKeyFingerprint,
  legacyIdFromPublicKey,
  deviceIdFromPublicKey,
  isValidDeviceId,
  generateIdentity,
  validateIdentity,
  writeIdentityDirectory,
  loadIdentityDirectory,
  migrateIdentityDirectory
};
