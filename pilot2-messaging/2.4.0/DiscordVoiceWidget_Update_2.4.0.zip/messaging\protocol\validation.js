const {
  SCHEMA_VERSION,
  MESSAGE_TYPES,
  verifyMessageSignature
} = require('./message');
const {
  payloadLimitForType,
  utf8ByteLength
} = require('./limits');
const { validateTtlWindow } = require('../service/ttl');
const { deviceIdFromPublicKey, isValidDeviceId } = require('../service/identity');
const { isValidUserId, isDeviceAuthorized } = require('../service/user-profile');

const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const BASE64_SIGNATURE = /^[A-Za-z0-9+/]+={0,2}$/;
const ALLOWED_FIELDS = new Set([
  'schemaVersion',
  'id',
  'fromUser',
  'fromDevice',
  'toUser',
  'type',
  'createdAt',
  'expiresAt',
  'payload',
  'signature'
]);

function validateLinkPayload(payload) {
  try {
    const url = new URL(payload);
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch {
    return false;
  }
}

function validateMessageEnvelope(message, options = {}) {
  const now = Number.isInteger(options.now) ? options.now : Date.now();
  const replayGuard = options.replayGuard || null;
  const senderPublicKey = options.senderPublicKey || null;
  const senderProfile = options.senderProfile || null;
  const requireSignature = options.requireSignature === true || Boolean(senderPublicKey) || Boolean(senderProfile);
  const errors = [];

  if (!message || typeof message !== 'object' || Array.isArray(message)) {
    return { ok: false, errors: [{ code: 'INVALID_MESSAGE', message: 'Message must be an object.' }] };
  }

  for (const field of Object.keys(message)) {
    if (!ALLOWED_FIELDS.has(field)) {
      errors.push({ code: 'UNKNOWN_FIELD', message: `Unknown field: ${field}` });
    }
  }

  if (message.schemaVersion !== SCHEMA_VERSION) {
    errors.push({ code: 'SCHEMA_VERSION', message: 'Unsupported schemaVersion.' });
  }
  if (typeof message.id !== 'string' || !UUID_V4.test(message.id)) {
    errors.push({ code: 'INVALID_ID', message: 'id must be a UUID v4 string.' });
  }
  if (!isValidUserId(message.fromUser)) {
    errors.push({ code: 'INVALID_FROM_USER', message: 'fromUser is invalid.' });
  }
  if (!isValidDeviceId(message.fromDevice)) {
    errors.push({ code: 'INVALID_FROM_DEVICE', message: 'fromDevice is invalid.' });
  }
  if (!isValidUserId(message.toUser)) {
    errors.push({ code: 'INVALID_TO_USER', message: 'toUser is invalid.' });
  }
  if (message.fromUser === message.toUser) {
    errors.push({ code: 'SAME_USER', message: 'fromUser and toUser must be different.' });
  }

  if (!MESSAGE_TYPES.includes(message.type)) {
    errors.push({ code: 'INVALID_TYPE', message: 'Unsupported message type.' });
  }

  if (typeof message.payload !== 'string' || message.payload.trim().length === 0) {
    errors.push({ code: 'INVALID_PAYLOAD', message: 'payload must be a non-empty string.' });
  } else {
    const maxBytes = payloadLimitForType(message.type);
    if (maxBytes && utf8ByteLength(message.payload) > maxBytes) {
      errors.push({
        code: 'PAYLOAD_TOO_LARGE',
        message: `payload exceeds ${maxBytes} UTF-8 bytes for message type ${message.type}.`
      });
    }
    if (message.type === 'link' && !validateLinkPayload(message.payload)) {
      errors.push({ code: 'INVALID_LINK', message: 'link must be a valid http/https URL.' });
    }
  }

  errors.push(...validateTtlWindow({
    createdAt: message.createdAt,
    expiresAt: message.expiresAt,
    now
  }));

  if (requireSignature && !message.signature) {
    errors.push({ code: 'SIGNATURE_REQUIRED', message: 'A cryptographic signature is required.' });
  } else if (message.signature !== null && message.signature !== undefined) {
    if (
      typeof message.signature !== 'string' ||
      message.signature.length > 256 ||
      !BASE64_SIGNATURE.test(message.signature)
    ) {
      errors.push({ code: 'INVALID_SIGNATURE_FORMAT', message: 'signature must be compact base64.' });
    }
  }

  if (senderProfile) {
    if (senderProfile.userId !== message.fromUser) {
      errors.push({ code: 'USER_PROFILE_MISMATCH', message: 'Sender profile does not match fromUser.' });
    }
  }

  let keyToVerify = senderPublicKey;
  if (!keyToVerify && senderProfile && Array.isArray(senderProfile.devices)) {
    const device = senderProfile.devices.find((item) => item.deviceId === message.fromDevice);
    if (device) keyToVerify = device.publicKeyPem;
  }

  if (keyToVerify && !errors.some((error) => error.code === 'SIGNATURE_REQUIRED' || error.code === 'INVALID_SIGNATURE_FORMAT')) {
    let derivedDeviceId = null;
    try {
      derivedDeviceId = deviceIdFromPublicKey(keyToVerify);
    } catch {
      errors.push({ code: 'INVALID_PUBLIC_KEY', message: 'The supplied public key is invalid.' });
    }

    if (derivedDeviceId && message.fromDevice !== derivedDeviceId) {
      errors.push({ code: 'DEVICE_KEY_MISMATCH', message: 'fromDevice does not match the supplied public key.' });
    }

    if (senderProfile && derivedDeviceId && !isDeviceAuthorized(senderProfile, message.fromDevice, keyToVerify)) {
      errors.push({ code: 'DEVICE_NOT_AUTHORIZED', message: 'Device is not authorized for this user.' });
    }

    if (derivedDeviceId && !verifyMessageSignature(message, keyToVerify)) {
      errors.push({ code: 'INVALID_SIGNATURE', message: 'Cryptographic signature verification failed.' });
    }
  } else if (senderProfile && !keyToVerify) {
    errors.push({ code: 'DEVICE_NOT_FOUND', message: 'Sender device is not present in the user profile.' });
  }

  if (!errors.length && replayGuard) {
    if (!replayGuard.accept(message.id, message.expiresAt, now)) {
      errors.push({ code: 'DUPLICATE_ID', message: 'Message id was already accepted.' });
    }
  }

  return { ok: errors.length === 0, errors };
}

function createReplayGuard() {
  const accepted = new Map();

  function purge(now = Date.now()) {
    for (const [id, expiresAt] of accepted.entries()) {
      if (expiresAt <= now) accepted.delete(id);
    }
  }

  return {
    accept(id, expiresAt, now = Date.now()) {
      purge(now);
      if (accepted.has(id)) return false;
      accepted.set(id, expiresAt);
      return true;
    },
    has(id, now = Date.now()) {
      purge(now);
      return accepted.has(id);
    },
    size(now = Date.now()) {
      purge(now);
      return accepted.size;
    },
    clear() {
      accepted.clear();
    }
  };
}

module.exports = {
  validateMessageEnvelope,
  createReplayGuard
};
