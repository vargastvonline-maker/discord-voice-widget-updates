const { EventEmitter } = require('events');
const { createMessage, signMessage } = require('../protocol/message');

class MessagingService extends EventEmitter {
  constructor({
    userProfile,
    deviceIdentity,
    transport
  }) {
    super();
    this.userProfile = userProfile;
    this.deviceIdentity = deviceIdentity;
    this.transport = transport;

    transport.on('message', (message, senderProfile) =>
      this.emit('message', message, senderProfile)
    );
    transport.on('rejected', (event) => this.emit('rejected', event));
    transport.on('relayError', (event) => this.emit('relayError', event));
    transport.on('close', () => this.emit('close'));
  }

  async start() {
    await this.transport.connect();
    return this;
  }

  async send({ toUser, type, payload, ttlMs }) {
    const unsigned = createMessage({
      fromUser: this.userProfile.userId,
      fromDevice: this.deviceIdentity.deviceId,
      toUser,
      type,
      payload,
      ttlMs
    });

    const signed = signMessage(unsigned, this.deviceIdentity.privateKeyPem);
    const ack = await this.transport.sendMessage(signed);
    return { message: signed, ack };
  }

  close() {
    this.transport.close();
  }
}

module.exports = {
  MessagingService
};
