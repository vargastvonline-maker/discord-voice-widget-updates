const net = require('net');
const https = require('https');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { safeStorage } = require('electron');

function extractAuthenticatedDiscordIdentity(authData) {
  const source = authData && typeof authData === 'object'
    ? (authData.user && typeof authData.user === 'object'
      ? authData.user
      : authData)
    : null;

  if (!source) return null;

  const discordUserId = String(source.id || source.user_id || '').trim();
  if (!/^\d{5,30}$/.test(discordUserId)) return null;

  const displayName = String(
    source.global_name ||
    source.display_name ||
    source.username ||
    discordUserId
  ).trim().slice(0, 100);

  let avatarUrl = null;
  const avatarHash = String(source.avatar || '').trim();
  if (avatarHash) {
    const ext = avatarHash.startsWith('a_') ? 'gif' : 'png';
    avatarUrl = `https://cdn.discordapp.com/avatars/${discordUserId}/${avatarHash}.${ext}?size=128`;
  }

  return Object.freeze({
    discordUserId,
    displayName: displayName || discordUserId,
    avatarUrl
  });
}

class DiscordRpcClient {
  constructor(root, options = {}) {
    this.root = root;
    this.clientId = String(options.clientId || '');
    this.redirectUri = String(options.redirectUri || 'http://127.0.0.1/callback');
    this.scopes = Array.isArray(options.scopes) ? options.scopes : ['rpc','identify','rpc.voice.read','rpc.voice.write'];
    this.tokenFile = path.join(root, 'rpc.auth.bin');
    this.sock = null;
    this.buf = Buffer.alloc(0);
    this.waiters = new Map();
    this.connected = false;
    this.authenticated = false;
    this.authData = null;
    this.lastVoiceConnectionStatus = null;
    this._voiceDiagnosticsSubscribed = false;
    this._dispatchListeners = new Set();
    this.connectionSerial = 0;
  }

  _frame(op, obj) {
    const body = Buffer.from(JSON.stringify(obj), 'utf8');
    const out = Buffer.alloc(8 + body.length);
    out.writeUInt32LE(op, 0);
    out.writeUInt32LE(body.length, 4);
    body.copy(out, 8);
    return out;
  }

  _connectPipe(index) {
    return new Promise((resolve, reject) => {
      const pipe = '\\\\?\\pipe\\discord-ipc-' + index;
      const sock = net.createConnection(pipe);
      const fail = (e) => { cleanup(); try { sock.destroy(); } catch {} reject(e); };
      const ok = () => { cleanup(); resolve(sock); };
      const cleanup = () => { sock.off('error', fail); sock.off('connect', ok); };
      sock.once('error', fail);
      sock.once('connect', ok);
    });
  }

  async _connectRaw() {
    for (let i = 0; i < 10; i++) {
      try { return await this._connectPipe(i); } catch {}
    }
    throw new Error('Discord IPC não encontrado. Abra o Discord Desktop.');
  }

  _installReader(sock) {
    this.buf = Buffer.alloc(0);
    sock.on('data', (chunk) => {
      this.buf = Buffer.concat([this.buf, chunk]);
      while (this.buf.length >= 8) {
        const op = this.buf.readUInt32LE(0);
        const len = this.buf.readUInt32LE(4);
        if (this.buf.length < 8 + len) return;

        const raw = this.buf.subarray(8, 8 + len).toString('utf8');
        this.buf = this.buf.subarray(8 + len);

        let msg;
        try { msg = JSON.parse(raw); } catch { continue; }

        if (msg && msg.cmd === 'DISPATCH' && msg.evt === 'VOICE_CONNECTION_STATUS') {
          this.lastVoiceConnectionStatus = msg.data || null;
        }

        if (msg && msg.cmd === 'DISPATCH' && msg.evt) {
          for (const listener of this._dispatchListeners) {
            try { listener(msg.evt, msg.data || null, msg); } catch {}
          }
        }

        if (op === 2) {
          for (const [, w] of this.waiters) {
            clearTimeout(w.timer);
            w.reject(new Error('Discord encerrou a conexão RPC.'));
          }
          this.waiters.clear();
          this.connected = false;
          this.authenticated = false;
          this._voiceDiagnosticsSubscribed = false;
          this.lastVoiceConnectionStatus = null;
          continue;
        }

        const key = msg && msg.nonce ? msg.nonce : (msg && msg.evt === 'READY' ? '__READY__' : null);
        if (key && this.waiters.has(key)) {
          const w = this.waiters.get(key);
          this.waiters.delete(key);
          clearTimeout(w.timer);
          w.resolve(msg);
        }
      }
    });

    sock.on('close', () => {
      // A late close from a previous pipe cannot wipe a newer connection.
      if (this.sock !== sock) return;
      this.connected = false;
      this.authenticated = false;
      this._voiceDiagnosticsSubscribed = false;
      this.lastVoiceConnectionStatus = null;
      this.sock = null;
    });
    sock.on('error', () => {
      if (this.sock !== sock) return;
      this.connected = false;
      this.authenticated = false;
      this._voiceDiagnosticsSubscribed = false;
      this.lastVoiceConnectionStatus = null;
    });
  }

  _wait(key, timeout = 15000) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.waiters.delete(key);
        reject(new Error('Timeout RPC: ' + key));
      }, timeout);
      this.waiters.set(key, { resolve, reject, timer });
    });
  }

  _request(cmd, args = {}, timeout = 15000) {
    if (!this.sock || this.sock.destroyed) return Promise.reject(new Error('RPC desconectado.'));
    const nonce = crypto.randomUUID();
    const p = this._wait(nonce, timeout);
    this.sock.write(this._frame(1, { cmd, args, nonce }));
    return p;
  }

  _requestEvent(cmd, evt, args = {}, timeout = 15000) {
    if (!this.sock || this.sock.destroyed) return Promise.reject(new Error('RPC desconectado.'));
    const nonce = crypto.randomUUID();
    const p = this._wait(nonce, timeout);
    this.sock.write(this._frame(1, { cmd, evt, args, nonce }));
    return p;
  }

  async _handshake() {
    if (this.sock && !this.sock.destroyed && this.connected) return;
    if (this._handshakePromise) return this._handshakePromise;

    this._handshakePromise = (async () => {
      const sock = await this._connectRaw();
      this.sock = sock;
      this._installReader(sock);
      try {
        const ready = this._wait('__READY__', 7000);
        sock.write(this._frame(0, { v: 1, client_id: this.clientId }));
        await ready;
        if (this.sock !== sock) throw new Error('RPC connection superseded.');
        this.connected = true;
        this.connectionSerial += 1;
      } catch (error) {
        if (this.sock === sock) this.sock = null;
        try { sock.destroy(); } catch {}
        throw error;
      }
    })();
    try { return await this._handshakePromise; }
    finally { this._handshakePromise = null; }
  }

  _saveToken(data, previous = null) {
    try {
      if (!safeStorage.isEncryptionAvailable() || !data || !data.access_token) return false;
      const previousRefresh = previous && previous.refresh_token ? String(previous.refresh_token) : '';
      const payload = {
        access_token: String(data.access_token),
        expires_at: Date.now() + Math.max(60, Number(data.expires_in || 0)) * 1000
      };
      const refreshToken = data.refresh_token ? String(data.refresh_token) : previousRefresh;
      if (refreshToken) payload.refresh_token = refreshToken;
      if (data.token_type) payload.token_type = String(data.token_type);
      if (data.scope) payload.scope = String(data.scope);
      const encrypted = safeStorage.encryptString(JSON.stringify(payload));
      fs.writeFileSync(this.tokenFile, encrypted);
      return true;
    } catch {
      return false;
    }
  }

  _loadToken() {
    try {
      if (!fs.existsSync(this.tokenFile) || !safeStorage.isEncryptionAvailable()) return null;
      const encrypted = fs.readFileSync(this.tokenFile);
      const payload = JSON.parse(safeStorage.decryptString(encrypted));
      if (!payload || !payload.access_token || !payload.expires_at) return null;
      return payload;
    } catch {
      return null;
    }
  }

  _tokenIsFresh(payload) {
    return Boolean(payload && payload.access_token && Number(payload.expires_at) > Date.now() + 60000);
  }

  _deleteToken() {
    try { fs.rmSync(this.tokenFile, { force: true }); } catch {}
  }

  _oauthTokenRequest(params) {
    return new Promise((resolve, reject) => {
      const body = new URLSearchParams(params).toString();
      const req = https.request({
        hostname: 'discord.com',
        path: '/api/oauth2/token',
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(body)
        }
      }, (res) => {
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          let obj = {};
          try { obj = JSON.parse(data); } catch {}
          if (res.statusCode >= 200 && res.statusCode < 300 && obj.access_token) {
            resolve(obj);
            return;
          }
          const error = new Error(obj.error_description || obj.message || obj.error || ('OAuth HTTP ' + res.statusCode));
          error.oauthStatus = Number(res.statusCode || 0);
          error.oauthCode = String(obj.error || '');
          error.oauthPermanent = error.oauthStatus >= 400 && error.oauthStatus < 500;
          reject(error);
        });
      });
      req.on('error', reject);
      req.end(body);
    });
  }

  _exchangeCode(code, codeVerifier) {
    return this._oauthTokenRequest({
      client_id: this.clientId,
      grant_type: 'authorization_code',
      code,
      redirect_uri: this.redirectUri,
      code_verifier: codeVerifier
    });
  }

  _refreshAccessToken(refreshToken) {
    return this._oauthTokenRequest({
      client_id: this.clientId,
      grant_type: 'refresh_token',
      refresh_token: String(refreshToken || '')
    });
  }

  _authRequiredError(message) {
    const error = new Error(message || 'Autorizacao RPC precisa ser renovada.');
    error.authRequired = true;
    return error;
  }

  async _authorizeInteractive() {
    const codeVerifier = crypto.randomBytes(48).toString('base64url');
    const codeChallenge = crypto.createHash('sha256').update(codeVerifier).digest('base64url');

    const auth = await this._request('AUTHORIZE', {
      client_id: this.clientId,
      scopes: this.scopes,
      code_challenge: codeChallenge,
      code_challenge_method: 'S256'
    }, 90000);

    if (auth.evt === 'ERROR' || !auth.data || typeof auth.data.code !== 'string') {
      throw this._authRequiredError(auth.data && (auth.data.message || auth.data.code) || 'Autorizacao RPC recusada.');
    }

    const token = await this._exchangeCode(auth.data.code, codeVerifier);
    this._saveToken(token);
    return token.access_token;
  }

  async _authenticate(accessToken) {
    const msg = await this._request('AUTHENTICATE', { access_token: accessToken }, 15000);
    if (msg.evt === 'ERROR') {
      const error = new Error(msg.data && (msg.data.message || msg.data.code) || 'Falha ao autenticar RPC.');
      error.rpcAuthRejected = true;
      throw error;
    }
    this.authenticated = true;
    this.authData = msg.data || null;
    this.subscribeVoiceDiagnostics().catch(() => {});
    return this.authData;
  }

  async _tryRefreshSavedToken(saved) {
    if (!saved || !saved.refresh_token) {
      throw this._authRequiredError('Token RPC expirou e precisa de nova autorizacao.');
    }
    try {
      const refreshed = await this._refreshAccessToken(saved.refresh_token);
      this._saveToken(refreshed, saved);
      return refreshed.access_token;
    } catch (error) {
      if (!error || !error.oauthPermanent) throw error;
      this._deleteToken();
      throw this._authRequiredError('Autorizacao RPC expirada ou revogada.');
    }
  }

  async ensureAuthenticated({ interactive = false } = {}) {
    await this._handshake();
    if (this.authenticated) return this.authData;

    const saved = this._loadToken();
    if (saved && saved.access_token) {
      if (this._tokenIsFresh(saved)) {
        try {
          return await this._authenticate(saved.access_token);
        } catch (error) {
          if (!error || !error.rpcAuthRejected) throw error;
        }
      }

      try {
        const refreshedAccessToken = await this._tryRefreshSavedToken(saved);
        return await this._authenticate(refreshedAccessToken);
      } catch (error) {
        if (!error || !error.authRequired) throw error;
        if (!interactive) throw error;
      }
    }

    if (!interactive) throw this._authRequiredError('RPC ainda nao autorizado.');
    const accessToken = await this._authorizeInteractive();
    return await this._authenticate(accessToken);
  }

  hasStoredAuthorization() {
    return Boolean(this._loadToken());
  }

  getAuthenticatedDiscordIdentity() {
    if (!this.authenticated || !this.authData) return null;
    return extractAuthenticatedDiscordIdentity(this.authData);
  }

  getConnectionSerial() {
    return this.connectionSerial;
  }

  onDispatch(listener) {
    if (typeof listener !== 'function') return () => {};
    this._dispatchListeners.add(listener);
    return () => this._dispatchListeners.delete(listener);
  }

  async subscribeEvent(evt, args = {}) {
    await this.ensureAuthenticated();
    const msg = await this._requestEvent('SUBSCRIBE', String(evt || ''), args || {}, 15000);
    if (msg && msg.evt === 'ERROR') {
      throw new Error(msg.data && (msg.data.message || msg.data.code) || ('Falha ao assinar evento ' + evt));
    }
    return msg && msg.data ? msg.data : null;
  }

  async unsubscribeEvent(evt, args = {}) {
    await this.ensureAuthenticated({ interactive: false });
    const msg = await this._requestEvent('UNSUBSCRIBE', String(evt || ''), args || {}, 15000);
    if (msg && msg.evt === 'ERROR') {
      throw new Error(msg.data && (msg.data.message || msg.data.code) || ('Falha ao remover evento ' + evt));
    }
    return msg && msg.data ? msg.data : null;
  }

  async subscribeVoiceDiagnostics() {
    await this.ensureAuthenticated();
    if (this._voiceDiagnosticsSubscribed) return true;
    const msg = await this._requestEvent('SUBSCRIBE', 'VOICE_CONNECTION_STATUS', {}, 15000);
    if (msg && msg.evt === 'ERROR') {
      throw new Error(msg.data && (msg.data.message || msg.data.code) || 'Falha ao assinar diagnostico de voz.');
    }
    this._voiceDiagnosticsSubscribed = true;
    return true;
  }

  getVoiceConnectionStatus() {
    return this.lastVoiceConnectionStatus || null;
  }

  async getSelectedVoiceChannel() {
    await this.ensureAuthenticated();
    const msg = await this._request('GET_SELECTED_VOICE_CHANNEL', {}, 15000);
    if (msg.evt === 'ERROR') {
      throw new Error(msg.data && (msg.data.message || msg.data.code) || 'Não foi possível ler a call.');
    }
    return msg.data || null;
  }

  _logAction(entry) {
    try {
      const line = JSON.stringify({ at: new Date().toISOString(), ...entry }) + '\n';
      fs.appendFileSync(path.join(this.root, 'rpc-actions.log'), line, 'utf8');
    } catch {}
  }

  async setUserVoiceSettings(userId, patch) {
    await this.ensureAuthenticated();
    const args = { user_id: String(userId || '') };
    if (Object.prototype.hasOwnProperty.call(patch, 'volume')) args.volume = Math.max(0, Math.min(200, Math.round(Number(patch.volume))));
    if (Object.prototype.hasOwnProperty.call(patch, 'mute')) args.mute = Boolean(patch.mute);
    if (patch && patch.pan && typeof patch.pan === 'object') {
      const left = Math.max(0, Math.min(1, Number(patch.pan.left)));
      const right = Math.max(0, Math.min(1, Number(patch.pan.right)));
      if (Number.isFinite(left) && Number.isFinite(right)) args.pan = { left, right };
    }

    const msg = await this._request('SET_USER_VOICE_SETTINGS', args, 15000);
    if (msg.evt === 'ERROR') {
      const error = msg.data && (msg.data.message || msg.data.code) || 'Falha ao alterar voz.';
      this._logAction({ action: 'SET_USER_VOICE_SETTINGS', ok: false, user_id: args.user_id, volume: args.volume, mute: args.mute, pan: args.pan, error: String(error) });
      throw new Error(error);
    }
    this._logAction({ action: 'SET_USER_VOICE_SETTINGS', ok: true, user_id: args.user_id, volume: args.volume, mute: args.mute, pan: args.pan });
    return msg.data || null;
  }

  close() {
    const previousSocket = this.sock;
    this.sock = null;
    this.connected = false;
    this.authenticated = false;
    this._voiceDiagnosticsSubscribed = false;
    this.lastVoiceConnectionStatus = null;
    for (const [, waiter] of this.waiters) {
      clearTimeout(waiter.timer);
      waiter.reject(new Error('RPC restarted.'));
    }
    this.waiters.clear();
    try { previousSocket?.destroy(); } catch {}
  }
}

module.exports = {
  DiscordRpcClient,
  extractAuthenticatedDiscordIdentity
};
