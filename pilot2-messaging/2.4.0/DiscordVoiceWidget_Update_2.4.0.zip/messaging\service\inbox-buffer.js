const { EventEmitter } = require('events');

class EphemeralInbox extends EventEmitter {
  constructor({
    maxItems = 20,
    now = () => Date.now()
  } = {}) {
    super();
    if (!Number.isInteger(maxItems) || maxItems < 1 || maxItems > 100) {
      throw new RangeError('maxItems must be between 1 and 100.');
    }

    this.maxItems = maxItems;
    this.now = now;
    this.items = [];
  }

  _isExpired(item) {
    return !item || !Number.isInteger(item.expiresAt) || this.now() >= item.expiresAt;
  }

  purgeExpired() {
    const before = this.items.length;
    this.items = this.items.filter((item) => !this._isExpired(item));
    if (this.items.length !== before) this.emit('change', this.snapshot());
    return before - this.items.length;
  }

  push(item) {
    if (!item || typeof item.id !== 'string' || !item.id) {
      throw new TypeError('Inbox item must have an id.');
    }
    if (!Number.isInteger(item.expiresAt)) {
      throw new TypeError('Inbox item must have expiresAt.');
    }
    if (this._isExpired(item)) return false;

    this.purgeExpired();
    if (this.items.some((entry) => entry.id === item.id)) return false;

    this.items.push(Object.freeze({ ...item }));
    while (this.items.length > this.maxItems) this.items.shift();
    this.emit('change', this.snapshot());
    return true;
  }

  peek() {
    this.purgeExpired();
    return this.items[0] || null;
  }

  remove(id) {
    this.purgeExpired();
    const index = this.items.findIndex((item) => item.id === id);
    if (index < 0) return null;
    const [removed] = this.items.splice(index, 1);
    this.emit('change', this.snapshot());
    return removed;
  }

  removeWhere(predicate) {
    if (typeof predicate !== 'function') {
      throw new TypeError('predicate must be a function.');
    }

    this.purgeExpired();

    const removed = [];
    const kept = [];

    for (const item of this.items) {
      if (predicate(item)) removed.push(item);
      else kept.push(item);
    }

    if (!removed.length) return [];

    this.items = kept;
    this.emit('change', this.snapshot());
    return removed;
  }

  snapshot() {
    return this.items.map((item) => ({ ...item }));
  }

  clear() {
    if (!this.items.length) return;
    this.items = [];
    this.emit('change', []);
  }
}

module.exports = {
  EphemeralInbox
};
