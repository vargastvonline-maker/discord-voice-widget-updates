const crypto = require('crypto');
const { EventEmitter } = require('events');
const { validateMessageEnvelope, createReplayGuard } = require('../protocol/validation');
const {
  isDeviceAuthorized,
  validateUserProfile
} = require('./user-profile');

const REGISTER_MAX_AGE_MS = 30_000;
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function registrationPayload(value) {
  return Buffer.from(JSON.stringify({
    kind: 'register',
    userId: value.userId,
    deviceId: value.deviceId,
    timestamp: value.timestamp,
    nonce: value.nonce
  }), 'utf8');
}

function createRegistrationProof({
  userId,
  deviceId,
  privateKeyPem,
  timestamp = Date.now(),
  nonce = crypto.randomUUID()
}) {
  const base = {
    kind: 'register',
    userId,
    deviceId,
    timestamp,
    nonce
  };
  const signature = crypto.sign(null, registrationPayload(base), privateKeyPem).toString('base64');
  return { ...base, signature };
}

function verifyRegistrationProof(proof, profile, {
  now = Date.now(),
  maxAgeMs = REGISTER_MAX_AGE_MS
} = {}) {
  if (!proof || proof.kind !== 'register') return { ok: false, code: 'INVALID_REGISTER' };
  if (!profile || profile.userId !== proof.userId) return { ok: false, code: 'UNKNOWN_USER' };
  if (!Number.isInteger(proof.timestamp) || Math.abs(now - proof.timestamp) > maxAgeMs) {
    return { ok: false, code: 'REGISTER_EXPIRED' };
  }
  if (typeof proof.nonce !== 'string' || !UUID_V4.test(proof.nonce)) {
    return { ok: false, code: 'INVALID_NONCE' };
  }

  const device = profile.devices?.find((item) => item.deviceId === proof.deviceId);
  if (!device || !isDeviceAuthorized(profile, proof.deviceId, device.publicKeyPem)) {
    return { ok: false, code: 'DEVICE_NOT_AUTHORIZED' };
  }
  if (typeof proof.signature !== 'string' || !proof.signature) {
    return { ok: false, code: 'SIGNATURE_REQUIRED' };
  }

  try {
    const valid = crypto.verify(
      null,
      registrationPayload(proof),
      device.publicKeyPem,
      Buffer.from(proof.signature, 'base64')
    );
    return valid
      ? { ok: true, publicKeyPem: device.publicKeyPem }
      : { ok: false, code: 'INVALID_REGISTER_SIGNATURE' };
  } catch {
    return { ok: false, code: 'INVALID_REGISTER_SIGNATURE' };
  }
}

class MessagingTransport extends EventEmitter {
  constructor({
    url,
    userProfile,
    deviceIdentity,
    resolveUserProfile,
    ackTimeoutMs = 2_000
  }) {
    super();
    this.url = url;
    this.userProfile = userProfile;
    this.deviceIdentity = deviceIdentity;
    this.resolveUserProfile = resolveUserProfile;
    this.ackTimeoutMs = ackTimeoutMs;
    this.socket = null;
    this.connected = false;
    this.pending = new Map();
    this.pendingResolvers = new Map();
    this.profileCache = new Map();
    this.profileCache.set(userProfile.userId, userProfile);
    this.replayGuard = createReplayGuard();
  }

  async connect() {
    if (this.connected) return;
    const WebSocketImpl = globalThis.WebSocket;
    if (typeof WebSocketImpl !== 'function') {
      throw new Error('This Node runtime has no WebSocket client.');
    }

    await new Promise((resolve, reject) => {
      let settled = false;
      const socket = new WebSocketImpl(this.url);
      this.socket = socket;

      const fail = (error) => {
        if (settled) return;
        settled = true;
        reject(error instanceof Error ? error : new Error(String(error)));
      };

      const timer = setTimeout(() => {
        fail(new Error('Relay registration timeout.'));
        try { socket.close(); } catch {}
      }, this.ackTimeoutMs);

      socket.addEventListener('open', () => {
        const proof = createRegistrationProof({
          userId: this.userProfile.userId,
          deviceId: this.deviceIdentity.deviceId,
          privateKeyPem: this.deviceIdentity.privateKeyPem
        });
        socket.send(JSON.stringify(proof));
      });

      socket.addEventListener('message', (event) => {
        this._handleRawMessage(event.data, (packet) => {
          if (!settled && packet.kind === 'registered') {
            settled = true;
            clearTimeout(timer);
            this.connected = true;
            resolve();
          } else if (!settled && packet.kind === 'error') {
            clearTimeout(timer);
            fail(new Error(packet.code || 'Relay registration failed.'));
          }
        });
      });

      socket.addEventListener('error', () => {
        clearTimeout(timer);
        fail(new Error('WebSocket transport error.'));
      });

      socket.addEventListener('close', () => {
        this.connected = false;
        clearTimeout(timer);
        if (!settled) fail(new Error('Relay closed before registration.'));
        for (const pending of this.pending.values()) {
          clearTimeout(pending.timer);
          pending.reject(new Error('Relay connection closed.'));
        }
        this.pending.clear();

        for (const pending of this.pendingResolvers.values()) {
          clearTimeout(pending.timer);
          pending.reject(new Error('Relay connection closed.'));
        }
        this.pendingResolvers.clear();

        this.emit('close');
      });
    });
  }

  _parsePacket(raw) {
    if (typeof raw !== 'string') return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  _handleRawMessage(raw, duringConnect = null) {
    const packet = this._parsePacket(raw);
    if (!packet || typeof packet.kind !== 'string') return;

    if (typeof duringConnect === 'function') duringConnect(packet);

    if (packet.kind === 'delivery' && packet.message) {
      let profile = null;

      if (packet.senderProfile) {
        try {
          validateUserProfile(packet.senderProfile);
          if (packet.senderProfile.userId === packet.message.fromUser) {
            profile = Object.freeze(JSON.parse(JSON.stringify(packet.senderProfile)));
            this.profileCache.set(profile.userId, profile);
          }
        } catch {}
      }

      if (!profile) {
        profile = this.profileCache.get(packet.message.fromUser) || null;
      }

      if (!profile && typeof this.resolveUserProfile === 'function') {
        profile = this.resolveUserProfile(packet.message.fromUser);
      }

      const validation = validateMessageEnvelope(packet.message, {
        senderProfile: profile,
        replayGuard: this.replayGuard
      });

      if (validation.ok) {
        this.emit('message', packet.message, profile);
      } else {
        this.emit('rejected', {
          message: packet.message,
          errors: validation.errors
        });
      }
      return;
    }

    if (packet.kind === 'resolved' && packet.requestId) {
      const pending = this.pendingResolvers.get(packet.requestId);
      if (!pending) return;

      clearTimeout(pending.timer);
      this.pendingResolvers.delete(packet.requestId);

      if (packet.code) {
        pending.reject(Object.assign(
          new Error(packet.code),
          { code: packet.code }
        ));
        return;
      }

      if (!packet.profile) {
        pending.resolve(null);
        return;
      }

      try {
        validateUserProfile(packet.profile);
        const discordUserId = String(packet.profile?.discord?.discordUserId || '').trim();
        if (discordUserId !== pending.discordUserId) {
          throw new Error('Resolved Discord identity mismatch.');
        }
        const profile = Object.freeze(JSON.parse(JSON.stringify(packet.profile)));
        this.profileCache.set(profile.userId, profile);
        pending.resolve(profile);
      } catch (error) {
        pending.reject(error);
      }
      return;
    }

    if ((packet.kind === 'ack' || packet.kind === 'rejected') && packet.messageId) {
      const pending = this.pending.get(packet.messageId);
      if (!pending) return;

      clearTimeout(pending.timer);
      this.pending.delete(packet.messageId);

      if (packet.kind === 'ack') pending.resolve(packet);
      else pending.reject(Object.assign(
        new Error(packet.code || 'Message rejected by relay.'),
        { packet }
      ));
      return;
    }

    if (packet.kind === 'error') {
      this.emit('relayError', packet);
    }
  }


  resolveDiscordUser(discordUserId) {
    const clean = String(discordUserId || '').trim();
    if (!/^\d{5,30}$/.test(clean)) {
      return Promise.reject(Object.assign(
        new Error('Invalid Discord user id.'),
        { code: 'INVALID_DISCORD_USER_ID' }
      ));
    }
    if (!this.connected || !this.socket || this.socket.readyState !== 1) {
      return Promise.reject(new Error('Messaging transport is not connected.'));
    }

    for (const profile of this.profileCache.values()) {
      if (String(profile?.discord?.discordUserId || '').trim() === clean) {
        return Promise.resolve(profile);
      }
    }

    return new Promise((resolve, reject) => {
      const requestId = crypto.randomUUID();
      const timer = setTimeout(() => {
        this.pendingResolvers.delete(requestId);
        reject(new Error('Relay recipient lookup timeout.'));
      }, this.ackTimeoutMs);

      this.pendingResolvers.set(requestId, {
        resolve,
        reject,
        timer,
        discordUserId: clean
      });

      this.socket.send(JSON.stringify({
        kind: 'resolve',
        requestId,
        discordUserId: clean
      }));
    });
  }

  getCachedProfile(userId) {
    return this.profileCache.get(String(userId || '')) || null;
  }

  sendMessage(message) {
    if (!this.connected || !this.socket || this.socket.readyState !== 1) {
      return Promise.reject(new Error('Messaging transport is not connected.'));
    }

    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(message.id);
        reject(new Error('Relay acknowledgement timeout.'));
      }, this.ackTimeoutMs);

      this.pending.set(message.id, { resolve, reject, timer });
      this.socket.send(JSON.stringify({
        kind: 'message',
        message
      }));
    });
  }

  close() {
    if (this.socket) {
      try { this.socket.close(); } catch {}
    }
    this.connected = false;
  }
}

module.exports = {
  REGISTER_MAX_AGE_MS,
  registrationPayload,
  createRegistrationProof,
  verifyRegistrationProof,
  MessagingTransport
};
