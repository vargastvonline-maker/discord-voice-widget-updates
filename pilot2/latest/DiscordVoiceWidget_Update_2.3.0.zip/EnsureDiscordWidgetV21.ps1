$ErrorActionPreference = 'SilentlyContinue'
$widgetRoot = $PSScriptRoot
$electron = Join-Path $widgetRoot 'node_modules\electron\dist\electron.exe'
$watcherScript = Join-Path $widgetRoot 'WatchDiscordWidgetV21.ps1'
$watcherVbs = Join-Path $widgetRoot 'StartDiscordWidgetV21Watcher.vbs'
$pidFile = Join-Path $widgetRoot 'watcher-v21.pid'
$modeMarker = Join-Path $widgetRoot 'watcher-v21.on-demand'
$log = Join-Path $widgetRoot 'guardian-v21.log'
$updateLock = Join-Path $widgetRoot 'update.lock'

function Test-DiscordRunning {
  return @(Get-Process -Name Discord,DiscordPTB,DiscordCanary -ErrorAction SilentlyContinue).Count -gt 0
}

function Log([string]$msg) {
  try {
    Add-Content -Path $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $msg) -Encoding UTF8
    if ((Get-Item $log -ErrorAction SilentlyContinue).Length -gt 1048576) {
      Get-Content $log -Tail 500 | Set-Content $log -Encoding UTF8
    }
  } catch {}
}

function Read-VerifiedWatcherPid {
  if (-not (Test-Path $pidFile)) { return 0 }
  try {
    $raw = (Get-Content $pidFile -Raw).Trim()
    $watchedPid = 0
    if (-not [int]::TryParse($raw,[ref]$watchedPid)) { return 0 }
    $process = Get-Process -Id $watchedPid -ErrorAction Stop
    if ($process.ProcessName -notin @('powershell','pwsh')) { return 0 }
    $cim = Get-CimInstance Win32_Process -Filter "ProcessId=$watchedPid" -ErrorAction Stop
    if ($cim.CommandLine -and $cim.CommandLine -like ('*' + $watcherScript + '*')) { return $watchedPid }
  } catch {}
  return 0
}

function Stop-VerifiedWatcher {
  $watcherPid = Read-VerifiedWatcherPid
  if ($watcherPid -gt 0) {
    Stop-Process -Id $watcherPid -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 350
  }
  Remove-Item $pidFile,$modeMarker -Force -ErrorAction SilentlyContinue
}

function Remove-LegacyStartupLink {
  # Only migrate a shortcut that demonstrably starts THIS installed widget.
  $startup = [Environment]::GetFolderPath('Startup')
  if (-not $startup) { return }
  foreach ($name in @('Discord Voice Widget V2.1 Watcher.lnk','Discord Voice Widget Watcher.lnk')) {
    $link = Join-Path $startup $name
    if (-not (Test-Path -LiteralPath $link -PathType Leaf)) { continue }
    try {
      $shell = New-Object -ComObject WScript.Shell
      $shortcut = $shell.CreateShortcut($link)
      $expectedVbs = Join-Path $widgetRoot 'StartDiscordWidgetV21Watcher.vbs'
      $target = [string]$shortcut.TargetPath
      $args = [string]$shortcut.Arguments
      if (-not $target.EndsWith('\wscript.exe',[StringComparison]::OrdinalIgnoreCase)) { continue }
      if ($args.IndexOf($expectedVbs,[StringComparison]::OrdinalIgnoreCase) -lt 0) { continue }
      $backupFolder = Join-Path $widgetRoot 'migration-backups'
      New-Item -ItemType Directory -Path $backupFolder -Force | Out-Null
      $destination = Join-Path $backupFolder $name
      if (Test-Path $destination) { $destination = Join-Path $backupFolder ((Get-Date -Format 'yyyyMMddHHmmss') + '-' + $name) }
      Move-Item -LiteralPath $link -Destination $destination -ErrorAction Stop
      Log ('Atalho automatico antigo arquivado; agora o widget inicia apenas com Discord.')
    } catch { Log ('Nao foi possivel migrar atalho Startup: ' + $_.Exception.GetType().Name) }
  }
}

if (Test-Path $updateLock) { exit }
if (-not (Test-Path $electron) -or -not (Test-Path $watcherScript)) { exit }
Remove-LegacyStartupLink

$discordRunning = Test-DiscordRunning
$widgetProcs = @(Get-Process electron -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $electron })
$watcherPid = Read-VerifiedWatcherPid

if (-not $discordRunning) {
  if ($watcherPid -gt 0) { Stop-VerifiedWatcher; Log 'Discord fechado; watcher desligado.' }
  if ($widgetProcs.Count -gt 0) { $widgetProcs | Stop-Process -Force; Log 'Discord fechado; widget encerrado.' }
  exit
}

# One-time migration: replace the resident 2.2.4 watcher with the new on-demand watcher.
if ($watcherPid -gt 0 -and -not (Test-Path $modeMarker)) {
  Stop-VerifiedWatcher
  Log 'Watcher antigo substituido pelo modo sob demanda.'
  $watcherPid = 0
}
if ($watcherPid -eq 0) {
  Remove-Item $pidFile,$modeMarker -Force -ErrorAction SilentlyContinue
  if (Test-Path $watcherVbs) {
    Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('//B //NoLogo "' + $watcherVbs + '"')
    Log 'Discord detectado; watcher iniciado.'
  } else {
    Start-Process powershell.exe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $watcherScript + '"') -WindowStyle Hidden
    Log 'Discord detectado; watcher iniciado via PowerShell.'
  }
}
# Guardian does not start Electron. The mutex-protected watcher exclusively owns it.