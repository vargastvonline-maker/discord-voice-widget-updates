const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('quickSettingsApi', {
  get: () => ipcRenderer.invoke('dw-settings-get'),
  set: (key, value) => ipcRenderer.invoke('dw-settings-set', { key, value }),
  reset: () => ipcRenderer.invoke('dw-settings-reset'),
  close: () => ipcRenderer.send('dw-settings-close')
});