param(
  [string]$LogPath = '',
  [int]$PollMs = 500,
  [int]$ParentPid = 0,
  [switch]$Once
)

$ErrorActionPreference = 'SilentlyContinue'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8

Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;

public static class CensoredFlowSmartWindow {
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    public struct MONITORINFO {
        public int cbSize;
        public RECT rcMonitor;
        public RECT rcWork;
        public int dwFlags;
    }

    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

    [DllImport("user32.dll")]
    public static extern IntPtr MonitorFromWindow(IntPtr hWnd, uint flags);

    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern bool EnumWindows(EnumWindowsProc callback, IntPtr lParam);

    [DllImport("user32.dll")]
    public static extern bool IsWindowVisible(IntPtr hWnd);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int maxCount);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern int GetClassName(IntPtr hWnd, StringBuilder text, int maxCount);

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    public static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFO info);
}
"@

if ([string]::IsNullOrWhiteSpace($LogPath)) {
    $LogPath = Join-Path $env:APPDATA 'discord\logs\discord_hook.log'
}

$rendererToGame = @{}
$overlayReady = @{}
$logPosition = [int64]0

function Parse-DiscordTimestamp([string]$line) {
    try {
        if ($line -match '^\[(?<ts>\d{4}-[A-Za-z]{3}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3} [+-]\d{2}:\d{2})\]') {
            return [DateTimeOffset]::ParseExact(
                $Matches.ts,
                'yyyy-MMM-dd HH:mm:ss.fff zzz',
                [Globalization.CultureInfo]::InvariantCulture
            )
        }
    } catch {}
    return [DateTimeOffset]::MinValue
}

function Remove-GameOverlay([int]$gamePid) {
    if ($gamePid -le 0) { return }
    [void]$overlayReady.Remove($gamePid)
    foreach ($key in @($rendererToGame.Keys)) {
        if ([int]$rendererToGame[$key].GamePid -eq $gamePid) {
            [void]$rendererToGame.Remove($key)
        }
    }
}

function Parse-DiscordHookLine([string]$line) {
    if ([string]::IsNullOrWhiteSpace($line)) { return }

    $eventTime = Parse-DiscordTimestamp $line

    if ($line -match '\[PID(?<renderer>\d+)\].*Overlay2: Overlay renderer for (?<game>\d+) started successfully\.') {
        $rendererPid = [int]$Matches.renderer
        $gamePid = [int]$Matches.game
        $rendererToGame[$rendererPid] = @{
            GamePid = $gamePid
            At = $eventTime
        }
        return
    }

    if ($line -match '\[PID(?<renderer>\d+)\].*Overlay2: Overlay is ready to show') {
        $rendererPid = [int]$Matches.renderer
        if ($rendererToGame.ContainsKey($rendererPid)) {
            $gamePid = [int]$rendererToGame[$rendererPid].GamePid
            $overlayReady[$gamePid] = @{
                At = $eventTime
                RendererPid = $rendererPid
            }
        }
        return
    }

    if ($line -match 'Overlay2: (?:Requesting destruction of overlay renderer for|Destroying overlay renderer for) (?<game>\d+)') {
        Remove-GameOverlay ([int]$Matches.game)
        return
    }

    if ($line -match 'Overlay2: Disconnecting all overlays') {
        $overlayReady.Clear()
        $rendererToGame.Clear()
    }
}

function Rebuild-OverlayState {
    $rendererToGame.Clear()
    $overlayReady.Clear()
    $script:logPosition = [int64]0

    if (-not (Test-Path $LogPath)) { return }

    try {
        $stream = [IO.File]::Open($LogPath, 'Open', 'Read', 'ReadWrite')
        try {
            $reader = New-Object IO.StreamReader($stream, [Text.Encoding]::UTF8, $true, 4096, $true)
            try {
                while (-not $reader.EndOfStream) {
                    Parse-DiscordHookLine ($reader.ReadLine())
                }
                $script:logPosition = $stream.Position
            } finally {
                $reader.Dispose()
            }
        } finally {
            $stream.Dispose()
        }
    } catch {}
}

function Read-NewOverlayEvents {
    if (-not (Test-Path $LogPath)) {
        $script:logPosition = [int64]0
        return
    }

    try {
        $length = (Get-Item $LogPath).Length
        if ($length -lt $script:logPosition) {
            Rebuild-OverlayState
            return
        }
        if ($length -eq $script:logPosition) { return }

        $stream = [IO.File]::Open($LogPath, 'Open', 'Read', 'ReadWrite')
        try {
            [void]$stream.Seek($script:logPosition, [IO.SeekOrigin]::Begin)
            $reader = New-Object IO.StreamReader($stream, [Text.Encoding]::UTF8, $true, 4096, $true)
            try {
                while (-not $reader.EndOfStream) {
                    Parse-DiscordHookLine ($reader.ReadLine())
                }
                $script:logPosition = $stream.Position
            } finally {
                $reader.Dispose()
            }
        } finally {
            $stream.Dispose()
        }
    } catch {}
}

function Prune-OverlayState {
    foreach ($key in @($overlayReady.Keys)) {
        $gamePid = [int]$key
        $entry = $overlayReady[$key]
        try {
            $proc = Get-Process -Id $gamePid -ErrorAction Stop
            if ($entry.At -ne [DateTimeOffset]::MinValue) {
                $started = [DateTimeOffset]$proc.StartTime
                if ($started -gt $entry.At.AddSeconds(5)) {
                    Remove-GameOverlay $gamePid
                }
            }
        } catch {
            Remove-GameOverlay $gamePid
        }
    }
}

function Get-LiveDiscordOverlayState([IntPtr]$foregroundMonitor) {
    $scan = @{
        Ready = $false
        Pid = 0
        Hwnd = [int64]0
    }

    try {
        $callback = [CensoredFlowSmartWindow+EnumWindowsProc]{
            param([IntPtr]$candidate, [IntPtr]$lParam)

            try {
                if (-not [CensoredFlowSmartWindow]::IsWindowVisible($candidate)) { return $true }

                $titleBuilder = New-Object Text.StringBuilder 256
                [void][CensoredFlowSmartWindow]::GetWindowText($candidate, $titleBuilder, $titleBuilder.Capacity)
                $title = $titleBuilder.ToString()
                if ($title -notlike 'Discord Overlay*') { return $true }

                [uint32]$candidatePid = 0
                [void][CensoredFlowSmartWindow]::GetWindowThreadProcessId($candidate, [ref]$candidatePid)
                if ($candidatePid -le 0) { return $true }

                $candidateProcess = Get-Process -Id $candidatePid -ErrorAction Stop
                if ($candidateProcess.ProcessName -ne 'Discord') { return $true }

                $candidateMonitor = [CensoredFlowSmartWindow]::MonitorFromWindow($candidate, 2)
                if ($foregroundMonitor -ne [IntPtr]::Zero -and $candidateMonitor -ne $foregroundMonitor) {
                    return $true
                }

                $rect = New-Object CensoredFlowSmartWindow+RECT
                if (-not [CensoredFlowSmartWindow]::GetWindowRect($candidate, [ref]$rect)) { return $true }
                if (($rect.Right - $rect.Left) -lt 300 -or ($rect.Bottom - $rect.Top) -lt 200) { return $true }

                $scan.Ready = $true
                $scan.Pid = [int]$candidatePid
                $scan.Hwnd = [int64]$candidate
                return $false
            } catch {
                return $true
            }
        }

        [void][CensoredFlowSmartWindow]::EnumWindows($callback, [IntPtr]::Zero)
    } catch {}

    return $scan
}

function Get-ForegroundState {
    $result = [ordered]@{
        foregroundPid = 0
        foregroundProcess = ''
        fullscreen = $false
        immersive = $false
        discordOverlayReady = $false
        discordOverlayWindowVisible = $false
        discordOverlaySource = ''
        detectorHealthy = $true
    }

    try {
        $hwnd = [CensoredFlowSmartWindow]::GetForegroundWindow()
        if ($hwnd -eq [IntPtr]::Zero) { return $result }

        [uint32]$targetPid = 0
        [void][CensoredFlowSmartWindow]::GetWindowThreadProcessId($hwnd, [ref]$targetPid)
        if ($targetPid -le 0) { return $result }

        $proc = Get-Process -Id $targetPid -ErrorAction Stop

        $rect = New-Object CensoredFlowSmartWindow+RECT
        if (-not [CensoredFlowSmartWindow]::GetWindowRect($hwnd, [ref]$rect)) { return $result }

        $monitor = [CensoredFlowSmartWindow]::MonitorFromWindow($hwnd, 2)
        $info = New-Object CensoredFlowSmartWindow+MONITORINFO
        $info.cbSize = [Runtime.InteropServices.Marshal]::SizeOf($info)
        if (-not [CensoredFlowSmartWindow]::GetMonitorInfo($monitor, [ref]$info)) { return $result }

        $windowWidth = [math]::Max(0, $rect.Right - $rect.Left)
        $windowHeight = [math]::Max(0, $rect.Bottom - $rect.Top)
        $monitorWidth = [math]::Max(1, $info.rcMonitor.Right - $info.rcMonitor.Left)
        $monitorHeight = [math]::Max(1, $info.rcMonitor.Bottom - $info.rcMonitor.Top)
        $areaRatio = ($windowWidth * $windowHeight) / [double]($monitorWidth * $monitorHeight)
        $tol = 6

        $full = (
            $rect.Left -le $info.rcMonitor.Left + $tol -and
            $rect.Top -le $info.rcMonitor.Top + $tol -and
            $rect.Right -ge $info.rcMonitor.Right - $tol -and
            $rect.Bottom -ge $info.rcMonitor.Bottom - $tol
        )

        $liveOverlay = Get-LiveDiscordOverlayState $monitor
        $logOverlayReady = [bool]$overlayReady.ContainsKey([int]$targetPid)

        $result.foregroundPid = [int]$targetPid
        $result.foregroundProcess = [string]$proc.ProcessName
        $result.fullscreen = [bool]$full
        $result.immersive = [bool]($full -or $areaRatio -ge 0.90)
        $result.discordOverlayWindowVisible = [bool]$liveOverlay.Ready
        $result.discordOverlayReady = [bool]($liveOverlay.Ready -or $logOverlayReady)
        $result.discordOverlaySource = if ($liveOverlay.Ready) { 'window' } elseif ($logOverlayReady) { 'log' } else { '' }
    } catch {
        $result.detectorHealthy = $false
    }

    return $result
}

Rebuild-OverlayState

do {
    if ($ParentPid -gt 0) {
        try { [void](Get-Process -Id $ParentPid -ErrorAction Stop) }
        catch { break }
    }

    Read-NewOverlayEvents
    Prune-OverlayState

    $state = Get-ForegroundState
    [Console]::Out.WriteLine(($state | ConvertTo-Json -Compress))
    [Console]::Out.Flush()

    if ($Once) { break }
    Start-Sleep -Milliseconds ([math]::Max(250, $PollMs))
} while ($true)
