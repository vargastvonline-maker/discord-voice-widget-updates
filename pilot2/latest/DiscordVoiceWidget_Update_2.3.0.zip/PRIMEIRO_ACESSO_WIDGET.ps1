﻿param([switch]$Diagnostico)

# Assistente de primeiro acesso do CensoredFlow 2.0.
# Nao solicita senha, nao chama APIs privadas e nao envia/aceita convites.
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$rpcConfig = Join-Path $root 'rpc.config.json'

function Test-RpcRegistered {
  try {
    if (-not (Test-Path -LiteralPath $rpcConfig)) { return $false }
    $cfg = Get-Content -LiteralPath $rpcConfig -Raw | ConvertFrom-Json
    return ([bool]$cfg.authorized)
  } catch { return $false }
}

if ($Diagnostico) {
  Write-Output 'FIRST_RUN_WIZARD=READY'
  Write-Output ('AUTHORIZATION_RECORDED=' + (Test-RpcRegistered))
  Write-Output ('ROOT=' + $root)
  exit 0
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$colors = @{
  bg       = [System.Drawing.Color]::FromArgb(20,21,30)
  panel    = [System.Drawing.Color]::FromArgb(31,33,45)
  field    = [System.Drawing.Color]::FromArgb(39,42,55)
  text     = [System.Drawing.Color]::FromArgb(244,245,249)
  secondary= [System.Drawing.Color]::FromArgb(174,180,196)
  purple   = [System.Drawing.Color]::FromArgb(88,101,242)
  purple2  = [System.Drawing.Color]::FromArgb(112,82,242)
  green    = [System.Drawing.Color]::FromArgb(46,204,113)
  disabled = [System.Drawing.Color]::FromArgb(72,75,88)
  border   = [System.Drawing.Color]::FromArgb(58,61,76)
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'CensoredFlow 2.0 - Primeiro acesso'
$form.Size = New-Object System.Drawing.Size(700,690)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.BackColor = $colors.bg
$form.ForeColor = $colors.text
$form.Font = New-Object System.Drawing.Font('Segoe UI',10)
$form.ShowInTaskbar = $true

function New-Label([string]$text,[int]$x,[int]$y,[int]$w,[int]$h,[float]$size=10,[bool]$bold=$false,[System.Windows.Forms.Control]$parent=$form) {
  $label = New-Object System.Windows.Forms.Label
  $label.Location = New-Object System.Drawing.Point($x,$y)
  $label.Size = New-Object System.Drawing.Size($w,$h)
  $label.Text = $text
  $style = if ($bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
  $label.Font = New-Object System.Drawing.Font('Segoe UI',$size,$style)
  $label.ForeColor = if ($bold) { $colors.text } else { $colors.secondary }
  $parent.Controls.Add($label)
  return $label
}

function New-Button([string]$text,[int]$x,[int]$y,[int]$w,[int]$h,[System.Windows.Forms.Control]$parent=$form) {
  $button = New-Object System.Windows.Forms.Button
  $button.Location = New-Object System.Drawing.Point($x,$y)
  $button.Size = New-Object System.Drawing.Size($w,$h)
  $button.Text = $text
  $button.FlatStyle = 'Flat'
  $button.FlatAppearance.BorderSize = 1
  $button.FlatAppearance.BorderColor = $colors.border
  $button.BackColor = $colors.field
  $button.ForeColor = $colors.text
  $button.Cursor = 'Hand'
  $parent.Controls.Add($button)
  return $button
}

function New-Step([int]$number,[string]$title,[string]$description,[int]$y,[int]$height) {
  $panel = New-Object System.Windows.Forms.Panel
  $panel.Location = New-Object System.Drawing.Point(22,$y)
  $panel.Size = New-Object System.Drawing.Size(640,$height)
  $panel.BackColor = $colors.panel
  $panel.BorderStyle = 'FixedSingle'
  $form.Controls.Add($panel)

  $accent = New-Object System.Windows.Forms.Panel
  $accent.Location = New-Object System.Drawing.Point(0,0)
  $accent.Size = New-Object System.Drawing.Size(5,$height)
  $accent.BackColor = $colors.disabled
  $panel.Controls.Add($accent)

  $badge = New-Object System.Windows.Forms.Label
  $badge.Location = New-Object System.Drawing.Point(16,13)
  $badge.Size = New-Object System.Drawing.Size(30,30)
  $badge.Text = [string]$number
  $badge.TextAlign = 'MiddleCenter'
  $badge.Font = New-Object System.Drawing.Font('Segoe UI',10,[System.Drawing.FontStyle]::Bold)
  $badge.BackColor = $colors.disabled
  $badge.ForeColor = $colors.text
  $panel.Controls.Add($badge)

  [void](New-Label $title 56 10 550 24 10 $true $panel)
  [void](New-Label $description 56 35 550 35 8.5 $false $panel)

  return @{
    Panel=$panel
    Accent=$accent
    Badge=$badge
  }
}

function Set-StepState($step,[string]$state) {
  switch ($state) {
    'done' {
      $step.Accent.BackColor = $colors.green
      $step.Badge.BackColor = $colors.green
      $step.Panel.BackColor = [System.Drawing.Color]::FromArgb(28,42,39)
    }
    'current' {
      $step.Accent.BackColor = $colors.purple
      $step.Badge.BackColor = $colors.purple
      $step.Panel.BackColor = [System.Drawing.Color]::FromArgb(31,34,55)
    }
    default {
      $step.Accent.BackColor = $colors.disabled
      $step.Badge.BackColor = $colors.disabled
      $step.Panel.BackColor = $colors.panel
    }
  }
}

function Set-ButtonEnabled($button,[bool]$enabled,[bool]$primary=$false) {
  $button.Enabled = $enabled
  if (-not $enabled) {
    $button.BackColor = $colors.disabled
    $button.ForeColor = [System.Drawing.Color]::FromArgb(145,149,160)
    $button.Cursor = 'Default'
    return
  }
  $button.Cursor = 'Hand'
  $button.ForeColor = $colors.text
  $button.BackColor = if ($primary) { $colors.purple } else { $colors.field }
}

[void](New-Label 'BEM-VINDO AO CENSOREDFLOW 2.0' 24 18 630 34 18 $true)
[void](New-Label 'Siga as etapas abaixo. A etapa azul e a atual; quando concluir, ela fica verde.' 24 54 470 28 9.5)

$progress = New-Label 'PASSO 1 DE 4' 520 53 130 25 9 $true
$progress.TextAlign = 'MiddleRight'

$step1 = New-Step 1 'Identifique sua conta Discord' 'Digite o nome de usuario da sua conta Discord (nao e o apelido do servidor).' 90 125
$usernameBox = New-Object System.Windows.Forms.TextBox
$usernameBox.Location = New-Object System.Drawing.Point(56,76)
$usernameBox.Size = New-Object System.Drawing.Size(340,30)
$usernameBox.Font = New-Object System.Drawing.Font('Segoe UI',10.5)
$usernameBox.BackColor = $colors.field
$usernameBox.ForeColor = $colors.text
$usernameBox.BorderStyle = 'FixedSingle'
$step1.Panel.Controls.Add($usernameBox)
$copy = New-Button 'Copiar pedido de liberacao' 408 74 210 34 $step1.Panel

$step2 = New-Step 2 'Autorize no Discord' 'Depois de copiar o pedido, abra o Discord e autorize o CensoredFlow quando for solicitado.' 226 100
$discord = New-Button 'Abrir Discord' 56 61 180 31 $step2.Panel
$checkFast = New-Button 'Ja autorizei - verificar' 248 61 205 31 $step2.Panel

$step3 = New-Step 3 'Liberacao de tester, se necessaria' 'Se o acesso ainda nao estiver liberado, envie o pedido copiado ao administrador e aceite o convite na conta Discord.' 337 118
$gmail = New-Button 'Abrir Gmail' 56 76 160 31 $step3.Panel
$outlook = New-Button 'Abrir Outlook' 228 76 160 31 $step3.Panel
$copyAgain = New-Button 'Copiar pedido novamente' 400 76 218 31 $step3.Panel

$step4 = New-Step 4 'Verifique e conclua' 'Depois de autorizar/aceitar o convite, verifique o acesso. O botao Concluir so libera quando a autorizacao estiver registrada.' 466 112
$check = New-Button 'Verificar acesso' 56 70 180 31 $step4.Panel
$finish = New-Button 'Concluir' 448 70 170 31 $step4.Panel

$status = New-Label '' 24 590 630 43 9.5
$note = New-Label 'Seguranca: o CensoredFlow nunca pede sua senha. O convite de tester nao e enviado automaticamente pelo aplicativo.' 24 632 630 30 8.5

$state = @{
  Copied = $false
  DiscordOpened = $false
  NeedTester = $false
}

function Valid-Username {
  $username = ([string]$usernameBox.Text).Trim()
  return ($username.Length -ge 2 -and $username.Length -le 100)
}

function Copy-ReleaseRequest {
  if (-not (Valid-Username)) {
    [System.Windows.Forms.MessageBox]::Show('Digite primeiro o nome de usuario exato do Discord.','CensoredFlow 2.0') | Out-Null
    return $false
  }
  $username = ([string]$usernameBox.Text).Trim()
  $message = "Ola! Meu usuario do Discord e: $username. Preciso ser convidado como testador do CensoredFlow 2.0. Depois aceito o convite na minha conta Discord e verifico o acesso no aplicativo."
  [System.Windows.Forms.Clipboard]::SetText($message)
  $state.Copied = $true
  return $true
}

function Refresh-Ui {
  $authorized = Test-RpcRegistered

  if ($authorized) {
    Set-StepState $step1 'done'
    Set-StepState $step2 'done'
    Set-StepState $step3 'done'
    Set-StepState $step4 'done'
    $progress.Text = 'ACESSO LIBERADO'
    Set-ButtonEnabled $copy $true $false
    Set-ButtonEnabled $discord $true $false
    Set-ButtonEnabled $checkFast $true $false
    Set-ButtonEnabled $gmail $true $false
    Set-ButtonEnabled $outlook $true $false
    Set-ButtonEnabled $copyAgain (Valid-Username) $false
    Set-ButtonEnabled $check $true $false
    Set-ButtonEnabled $finish $true $true
    $status.Text = 'Autorizacao registrada. Clique em Concluir e entre em uma chamada de voz para testar o widget.'
    return
  }

  Set-StepState $step1 $(if($state.Copied){'done'}else{'current'})
  Set-StepState $step2 $(if(-not $state.Copied){'locked'}elseif($state.DiscordOpened){'done'}else{'current'})
  Set-StepState $step3 $(if($state.NeedTester){'current'}elseif($state.Copied -and $state.DiscordOpened){'locked'}else{'locked'})
  Set-StepState $step4 $(if($state.Copied -and $state.DiscordOpened -and -not $state.NeedTester){'current'}else{'locked'})

  if (-not $state.Copied) {
    $progress.Text = 'PASSO 1 DE 4'
    $status.Text = 'Comece digitando seu nome de usuario Discord. Depois copie o pedido de liberacao.'
  } elseif (-not $state.DiscordOpened) {
    $progress.Text = 'PASSO 2 DE 4'
    $status.Text = 'Pedido copiado. Agora abra o Discord e tente autorizar o CensoredFlow.'
  } elseif ($state.NeedTester) {
    $progress.Text = 'PASSO 3 DE 4'
    $status.Text = 'Acesso ainda nao registrado. Envie o pedido ao administrador, aceite o convite e depois verifique novamente.'
  } else {
    $progress.Text = 'PASSO 4 DE 4'
    $status.Text = 'Discord aberto. Clique em Verificar acesso. Se ainda faltar liberacao, o assistente indicara o Passo 3.'
  }

  Set-ButtonEnabled $copy $true $true
  Set-ButtonEnabled $discord $state.Copied $true
  Set-ButtonEnabled $checkFast ($state.Copied -and $state.DiscordOpened) $false
  Set-ButtonEnabled $gmail $state.NeedTester $false
  Set-ButtonEnabled $outlook $state.NeedTester $false
  Set-ButtonEnabled $copyAgain $state.NeedTester $false
  Set-ButtonEnabled $check ($state.Copied -and $state.DiscordOpened) $true
  Set-ButtonEnabled $finish $false $true
}

$usernameBox.Add_TextChanged({ Refresh-Ui })

$copy.Add_Click({
  if (Copy-ReleaseRequest) {
    $status.Text = 'Pedido copiado. Agora siga para o Passo 2.'
    Refresh-Ui
  }
})

$copyAgain.Add_Click({
  if (Copy-ReleaseRequest) {
    $status.Text = 'Pedido copiado novamente. Envie ao administrador e aceite o convite na sua conta Discord.'
  }
})

$discord.Add_Click({
  if (-not $state.Copied) { return }
  Start-Process 'https://discord.com/channels/@me'
  $state.DiscordOpened = $true
  $state.NeedTester = $false
  Refresh-Ui
})

$gmail.Add_Click({ Start-Process 'https://mail.google.com/mail/u/0/#all' })
$outlook.Add_Click({ Start-Process 'https://outlook.live.com/mail/' })

$verifyAction = {
  if (Test-RpcRegistered) {
    $state.NeedTester = $false
    Refresh-Ui
  } else {
    $state.NeedTester = $true
    Refresh-Ui
  }
}

$checkFast.Add_Click($verifyAction)
$check.Add_Click($verifyAction)
$finish.Add_Click({
  if (Test-RpcRegistered) { $form.Close() }
})

if (Test-RpcRegistered) {
  $state.Copied = $true
  $state.DiscordOpened = $true
}
Refresh-Ui

[void]$form.ShowDialog()
$form.Dispose()
