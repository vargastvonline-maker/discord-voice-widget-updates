$ErrorActionPreference = 'SilentlyContinue'
$widgetRoot = $PSScriptRoot
$electron = Join-Path $widgetRoot 'node_modules\electron\dist\electron.exe'
$pidFile = Join-Path $widgetRoot 'watcher-v21.pid'
$modeMarker = Join-Path $widgetRoot 'watcher-v21.on-demand'
$updateLock = Join-Path $widgetRoot 'update.lock'

function Test-DiscordRunning {
  return @(Get-Process -Name Discord,DiscordPTB,DiscordCanary -ErrorAction SilentlyContinue).Count -gt 0
}

$createdNew = $false
$mutex = [System.Threading.Mutex]::new($true, 'Local\DiscordVoiceWidgetV21Watcher', [ref]$createdNew)
if (-not $createdNew) { exit }

try {
  # This watcher is an on-demand process, never a permanent Windows startup service.
  if (-not (Test-DiscordRunning)) { exit }
  Set-Content -Path $pidFile -Value $PID -Encoding ASCII
  Set-Content -Path $modeMarker -Value $PID -Encoding ASCII

  while ($true) {
    if (Test-Path $updateLock) {
      Start-Sleep -Seconds 1
      continue
    }

    $discordRunning = Test-DiscordRunning
    $widgetProcs = @(Get-Process electron -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $electron })

    if (-not $discordRunning) {
      if ($widgetProcs.Count -gt 0) { $widgetProcs | Stop-Process -Force }
      # Brief debounce avoids a false shutdown if Discord is temporarily restarting.
      Start-Sleep -Seconds 2
      if (-not (Test-DiscordRunning)) { break }
      continue
    }

    if ($widgetProcs.Count -eq 0 -and (Test-Path $electron)) {
      Start-Process -FilePath $electron -ArgumentList ('"' + $widgetRoot + '"')
    }

    Start-Sleep -Seconds 2
  }
}
finally {
  try {
    if (Test-Path $pidFile) {
      $recorded = (Get-Content $pidFile -Raw).Trim()
      if ($recorded -eq [string]$PID) { Remove-Item $pidFile -Force -ErrorAction SilentlyContinue }
    }
    if (Test-Path $modeMarker) {
      $recorded = (Get-Content $modeMarker -Raw).Trim()
      if ($recorded -eq [string]$PID) { Remove-Item $modeMarker -Force -ErrorAction SilentlyContinue }
    }
  } catch {}
  if ($mutex) {
    try { $mutex.ReleaseMutex() } catch {}
    $mutex.Dispose()
  }
}