const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('volumeApi', {
  setVolume: (userId, volume) => ipcRenderer.invoke('dw-volume-set', { userId, volume }),
  close: () => ipcRenderer.send('dw-volume-close')
});
