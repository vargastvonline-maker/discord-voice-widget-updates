const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('scaleApi', {
  setOpacity: (percent) => ipcRenderer.invoke('dw-scale-set', Number(percent)),
  close: () => ipcRenderer.send('dw-scale-close')
});
