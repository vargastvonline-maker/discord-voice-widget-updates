param(
  [switch]$Quiet,
  [switch]$KeepSettings
)

$ErrorActionPreference = 'Stop'
$AppName = 'CensoredFlow 2.0 Piloto'
$TaskNames = @(
  'Discord Voice Widget V2.1 Guardian',
  'Discord Voice Widget Guardian',
  'Discord Voice Widget Watcher'
)
$DefaultRoot = Join-Path $env:LOCALAPPDATA 'DiscordVoiceWidget-V2.1'
$TestMode = ([string]$env:DW_UNINSTALL_TESTMODE -eq '1')
$InstallRoot = $DefaultRoot

if ($TestMode) {
  if (-not $env:DW_UNINSTALL_TEST_ROOT) { throw 'QA root not specified.' }
  $InstallRoot = [IO.Path]::GetFullPath([string]$env:DW_UNINSTALL_TEST_ROOT).TrimEnd('\')
  if ($InstallRoot -notmatch '^[A-Za-z]:\\DiscordVoiceWidget-V2\.1-DEV\\_QA_UNINSTALL_[A-Za-z0-9_-]+$') {
    throw 'QA root not permitted.'
  }
}

$InstallRoot = [IO.Path]::GetFullPath($InstallRoot).TrimEnd('\')
if (-not $TestMode) {
  $local = [IO.Path]::GetFullPath($env:LOCALAPPDATA).TrimEnd('\')
  if (-not $InstallRoot.Equals((Join-Path $local 'DiscordVoiceWidget-V2.1'), [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Destination path not approved for removal.'
  }
}

$Errors = New-Object System.Collections.Generic.List[string]
$Steps = New-Object System.Collections.Generic.List[string]
$log = Join-Path $env:TEMP 'DiscordVoiceWidget-Uninstall.log'
function Say([string]$message) {
  Write-Host $message
  $script:Steps.Add($message)
}
function Warning([string]$message) {
  Write-Warning $message
  $script:Errors.Add($message)
}
function IsOurPath([string]$p) {
  if (-not $p) { return $false }
  return ($p.IndexOf($script:InstallRoot, [StringComparison]::OrdinalIgnoreCase) -ge 0)
}

try {
  if (-not $Quiet -and -not $TestMode) {
    Write-Host 'ATENCAO: isto removera por completo o CensoredFlow 2.0, incluindo configuracoes e autorizacao deste widget.'
    Write-Host 'O Discord e outros programas nao serao alterados.'
    $response = Read-Host 'Digite SIM para confirmar a desinstalacao'
    if ($response -cne 'SIM') {
      Say 'Desinstalacao cancelada.'
      exit 0
    }
  }
  Say ('Uninstall target: ' + $InstallRoot)
  $exists = Test-Path -LiteralPath $InstallRoot
  if ($exists) {
    # A partial install can omit package.json. Do not delete an unrelated directory.
    $markers = @(
      'main.js','WatchDiscordWidgetV21.ps1',
      'INSTALL_V22_PILOT.ps1','node_modules\electron',
      'rpc-client.js','RunGuardianV21.vbs',
      'config.json','updater-client.js'
    )
    $matched = @($markers | Where-Object { Test-Path -LiteralPath (Join-Path $InstallRoot $_) })
    if ($matched.Count -eq 0) {
      throw 'Directory lacks Discord Voice Widget markers. No deletion was performed.'
    }
  }

  if (-not $TestMode) {
    # Remove only tasks whose action references this app installation.
    foreach ($name in $TaskNames) {
      $task = Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
      if (-not $task) { continue }
      $actions = @($task.Actions)
      $actionText = ($actions | ForEach-Object { [string]$_.Execute + ' ' + [string]$_.Arguments + ' ' + [string]$_.WorkingDirectory }) -join ' '
      if (-not (IsOurPath $actionText)) {
        Warning ('Skipped unrelated task: ' + $name)
        continue
      }
      try {
        Stop-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue
        Unregister-ScheduledTask -TaskName $name -Confirm:$false -ErrorAction Stop
        Say ('Removed task: ' + $name)
      } catch {
        Warning ('Could not remove task '+$name+': '+$_.Exception.Message)
      }
    }

    # Stop only watcher/Guardian processes belonging to the installed widget.
    try {
      $psProcesses = @(Get-CimInstance Win32_Process -ErrorAction Stop |
        Where-Object {
          $_.Name -in @('powershell.exe','pwsh.exe','wscript.exe','cscript.exe') -and
          $_.CommandLine -and (IsOurPath $_.CommandLine) -and
          $_.ProcessId -ne $PID
        })
      foreach ($proc in $psProcesses) {
        try {
          Stop-Process -Id $proc.ProcessId -Force -ErrorAction Stop
          Say ('Stopped helper PID '+$proc.ProcessId)
        } catch {
          Warning ('Could not stop helper PID '+$proc.ProcessId)
        }
      }
    } catch {
      Warning ('Could not inspect helper processes: '+$_.Exception.Message)
    }

    # Stop only electron.exe launched from this installation; leave Discord and other Electron apps alone.
    try {
      $electrons = @(Get-CimInstance Win32_Process -Filter "Name='electron.exe'" -ErrorAction Stop |
        Where-Object { $_.ExecutablePath -and (IsOurPath $_.ExecutablePath) })
      foreach ($proc in $electrons) {
        try {
          Stop-Process -Id $proc.ProcessId -Force -ErrorAction Stop
          Say ('Stopped widget Electron PID '+$proc.ProcessId)
        } catch {
          # Electron may exit between enumeration and Stop-Process.
          # That is normal, not an incomplete removal, if the original app
          # process is no longer running from our installation path.
          $stillOurs = $false
          try {
            $remaining = Get-CimInstance Win32_Process -Filter ("ProcessId=" + [int]$proc.ProcessId) -ErrorAction Stop
            $stillOurs = [bool]($remaining -and $remaining.Name -eq 'electron.exe' -and $remaining.ExecutablePath -and (IsOurPath $remaining.ExecutablePath))
          } catch {
            # Unable to verify; keep the warning rather than claim success.
            $stillOurs = $true
          }
          if ($stillOurs) {
            Warning ('Could not stop widget Electron PID '+$proc.ProcessId)
          } else {
            Say ('Widget Electron already exited PID '+$proc.ProcessId)
          }
        }
      }
    } catch {
      Warning ('Could not inspect Electron processes: '+$_.Exception.Message)
    }

    # Delete shortcuts only if they really point to the widget installation.
    $sh = New-Object -ComObject WScript.Shell
    $shortcutPaths = @(
      (Join-Path ([Environment]::GetFolderPath('Startup')) 'Discord Voice Widget Watcher.lnk'),
      (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Discord Voice Widget.lnk'),
      (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Desinstalar Discord Voice Widget.lnk'),
      (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Primeiro acesso Discord Voice Widget.lnk')
    )
    foreach ($shortcutPath in $shortcutPaths) {
      if (-not (Test-Path -LiteralPath $shortcutPath)) { continue }
      try {
        $shortcut = $sh.CreateShortcut($shortcutPath)
        $targetText = [string]$shortcut.TargetPath + ' ' + [string]$shortcut.Arguments + ' ' + [string]$shortcut.WorkingDirectory
        if (IsOurPath $targetText) {
          Remove-Item -LiteralPath $shortcutPath -Force -ErrorAction Stop
          Say ('Removed shortcut: '+(Split-Path $shortcutPath -Leaf))
        } else {
          Warning ('Skipped unrelated shortcut: '+$shortcutPath)
        }
      } catch {
        Warning ('Could not remove shortcut: '+$shortcutPath)
      }
    }
    $reg = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\DiscordVoiceWidgetV22Pilot'
    if (Test-Path $reg) {
      $entry = Get-ItemProperty $reg -ErrorAction SilentlyContinue
      if ($entry -and (IsOurPath ([string]$entry.InstallLocation))) {
        try {
          Remove-Item -LiteralPath $reg -Recurse -Force -ErrorAction Stop
          Say 'Removed Windows installed-app entry.'
        } catch {
          Warning ('Could not unregister installed-app entry: '+$_.Exception.Message)
        }
      } else {
        Warning 'Skipped registry entry with unmatched install location.'
      }
    }
  }

  # This works for complete AND interrupted first installations.
  if ($exists) {
    if ($KeepSettings) {
      $save = Join-Path $env:LOCALAPPDATA 'DiscordVoiceWidget-Backup-Settings'
      if ($TestMode) { $save = $InstallRoot + '-settings' }
      New-Item -ItemType Directory -Path $save -Force | Out-Null
      foreach ($name in @('config.json','rpc.config.json','rpc.auth.bin')) {
        $file = Join-Path $InstallRoot $name
        if (Test-Path -LiteralPath $file) {
          Copy-Item -LiteralPath $file -Destination $save -Force
        }
      }
      Say ('Settings backup: '+$save)
    }

    $removed = $false
    for ($attempt=1; $attempt -le 6; $attempt++) {
      try {
        Remove-Item -LiteralPath $InstallRoot -Recurse -Force -ErrorAction Stop
        $removed = -not (Test-Path -LiteralPath $InstallRoot)
        if ($removed) { break }
      } catch {
        if ($attempt -eq 6) { Warning ('File deletion failure: '+$_.Exception.Message) }
      }
      Start-Sleep -Milliseconds 700
    }
    if ($removed) { Say 'Widget files removed.' }
    else { Warning ('Some widget files remain at '+$InstallRoot) }
  } else {
    Say 'App directory already absent (partial installation / already uninstalled).'
  }
  $ok = -not (Test-Path -LiteralPath $InstallRoot) -and $Errors.Count -eq 0
  if ($ok) { Say 'UNINSTALL_RESULT=SUCCESS' }
  else { Say 'UNINSTALL_RESULT=INCOMPLETE' }
  exit $(if ($ok) { 0 } else { 2 })
} catch {
  Warning ('UNINSTALL_RESULT=ERROR: '+$_.Exception.Message)
  exit 3
} finally {
  try {
    @('Discord Voice Widget uninstall log',('Time: '+(Get-Date -Format s))) +
      @($Steps) + @($Errors | ForEach-Object { 'WARNING: '+$_ }) |
      Set-Content -LiteralPath $log -Encoding UTF8
  } catch {}
}
