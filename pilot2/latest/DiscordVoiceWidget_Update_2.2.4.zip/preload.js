const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('widgetApi', {
  saveUrl: (url) => ipcRenderer.invoke('save-url', url),
  getClipboard: () => ipcRenderer.invoke('get-clipboard'),
  openStreamkit: () => ipcRenderer.invoke('open-streamkit'),
  beginResize: (x, y) => ipcRenderer.send('dw-resize-begin', { x, y }),
  resizeTo : (x, y) => ipcRenderer.send('dw-resize-move', { x, y }),
  endResize: () => ipcRenderer.send('dw-resize-end'),
  beginMove: (x, y) => ipcRenderer.send('dw-move-begin', { x, y }),
  moveTo : (x, y) => ipcRenderer.send('dw-move-move', { x, y }),
  endMove: () => ipcRenderer.send('dw-move-end'),
  showParticipantMenu: (participant) => ipcRenderer.send('dw-participant-menu', participant),
  getGlobalVoiceState: () => ipcRenderer.invoke('dw-global-get-state'),
  onGlobalVoiceState: (callback) => {
    if (typeof callback !== 'function') return () => {};
    const listener = (_event, state) => callback(state);
    ipcRenderer.on('dw-global-state', listener);
    return () => ipcRenderer.removeListener('dw-global-state', listener);
  }
});
