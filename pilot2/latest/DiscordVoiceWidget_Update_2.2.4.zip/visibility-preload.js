const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('visibilityApi', {
  setOpacity: (percent) => ipcRenderer.invoke('dw-visibility-set', Number(percent)),
  close: () => ipcRenderer.send('dw-visibility-close')
});
