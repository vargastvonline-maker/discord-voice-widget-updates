Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
pending = root & "\.updates\pending-apply.json"
Set sh = CreateObject("WScript.Shell")
cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & root & "\ApplyUpdateV21.ps1"" -PendingFile """ & pending & """"
sh.Run cmd, 0, False
