param(
  [Parameter(Mandatory=$true)][UInt64]$Hwnd,
  [ValidateSet('Pin','Unpin','Status','Current')][string]$Action = 'Pin'
)

$ErrorActionPreference = 'Stop'

$dll = Join-Path $PSScriptRoot 'VirtualDesktopAccessor.dll'
if (-not (Test-Path $dll)) {
  Write-Error 'VirtualDesktopAccessor.dll ausente.'
  exit 20
}

$signature = @"
using System;
using System.Runtime.InteropServices;

public static class VdaNative {
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
  public static extern IntPtr LoadLibrary(string lpFileName);

  [DllImport("kernel32.dll", CharSet=CharSet.Ansi, SetLastError=true)]
  public static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

  [UnmanagedFunctionPointer(CallingConvention.Cdecl)]
  public delegate int WindowFn(IntPtr hwnd);

  public static int Call(string dll, string proc, IntPtr hwnd) {
    var module = LoadLibrary(dll);
    if (module == IntPtr.Zero) return -1001;
    var fp = GetProcAddress(module, proc);
    if (fp == IntPtr.Zero) return -1002;
    var fn = (WindowFn)Marshal.GetDelegateForFunctionPointer(fp, typeof(WindowFn));
    return fn(hwnd);
  }
}
"@

Add-Type -TypeDefinition $signature -ErrorAction Stop

$ptr = [IntPtr]::new([Int64]$Hwnd)

switch ($Action) {
  'Pin'    { $rc = [VdaNative]::Call($dll, 'PinWindow', $ptr) }
  'Unpin'  { $rc = [VdaNative]::Call($dll, 'UnPinWindow', $ptr) }
  'Status' { $rc = [VdaNative]::Call($dll, 'IsPinnedWindow', $ptr) }
  'Current' { $rc = [VdaNative]::Call($dll, 'IsWindowOnCurrentVirtualDesktop', $ptr) }
}

Write-Output ("ACTION=" + $Action)
Write-Output ("HWND=" + $Hwnd)
Write-Output ("RESULT=" + $rc)

if ($rc -lt 0) { exit 30 }

