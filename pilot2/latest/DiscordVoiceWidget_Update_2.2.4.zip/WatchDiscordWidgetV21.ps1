$ErrorActionPreference = 'SilentlyContinue'
$widgetRoot = $PSScriptRoot
$electron = Join-Path $widgetRoot 'node_modules\electron\dist\electron.exe'
$pidFile = Join-Path $widgetRoot 'watcher-v21.pid'
$updateLock = Join-Path $widgetRoot 'update.lock'

function Test-DiscordRunning {
  return @(Get-Process -Name Discord,DiscordPTB,DiscordCanary -ErrorAction SilentlyContinue).Count -gt 0
}

$createdNew = $false
$mutex = [System.Threading.Mutex]::new($true, 'Local\DiscordVoiceWidgetV21Watcher', [ref]$createdNew)
if (-not $createdNew) { exit }

try {
  Set-Content -Path $pidFile -Value $PID -Encoding ASCII

  while ($true) {
    if (Test-Path $updateLock) {
      Start-Sleep -Seconds 1
      continue
    }

    $discordRunning = Test-DiscordRunning
    $widgetProcs = @(Get-Process electron -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $electron })

    if ($discordRunning -and $widgetProcs.Count -eq 0) {
      Start-Process -FilePath $electron -ArgumentList ('"' + $widgetRoot + '"')
    }
    elseif (-not $discordRunning -and $widgetProcs.Count -gt 0) {
      $widgetProcs | Stop-Process -Force
    }

    Start-Sleep -Seconds 1
  }
}
finally {
  try {
    if (Test-Path $pidFile) {
      $recorded = (Get-Content $pidFile -Raw).Trim()
      if ($recorded -eq [string]$PID) {
        Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
      }
    }
  } catch {}

  if ($mutex) {
    try { $mutex.ReleaseMutex() } catch {}
    $mutex.Dispose()
  }
}
