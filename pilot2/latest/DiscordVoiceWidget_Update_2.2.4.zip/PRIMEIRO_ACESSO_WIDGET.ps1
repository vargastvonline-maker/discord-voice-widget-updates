param([switch]$Diagnostico)

# Assistente de primeiro acesso. Nao solicita credenciais, nao chama APIs privadas
# e nao tenta enviar/aceitar convites em nome de usuarios do Discord.
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$rpcConfig = Join-Path $root 'rpc.config.json'

function Test-RpcRegistered {
  try {
    if (-not (Test-Path -LiteralPath $rpcConfig)) { return $false }
    $cfg = Get-Content -LiteralPath $rpcConfig -Raw | ConvertFrom-Json
    return ([bool]$cfg.authorized)
  } catch { return $false }
}

if ($Diagnostico) {
  Write-Output 'FIRST_RUN_WIZARD=READY'
  Write-Output ('AUTHORIZATION_RECORDED=' + (Test-RpcRegistered))
  Write-Output ('ROOT=' + $root)
  exit 0
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$colors = @{
  bg = [System.Drawing.Color]::FromArgb(22,24,34)
  text = [System.Drawing.Color]::FromArgb(242,243,247)
  secondary = [System.Drawing.Color]::FromArgb(183,188,202)
  field = [System.Drawing.Color]::FromArgb(38,41,54)
  purple = [System.Drawing.Color]::FromArgb(88,101,242)
}
$form = New-Object System.Windows.Forms.Form
$form.Text = 'CensoredFlow 2.0 - Primeiro acesso'
$form.Size = New-Object System.Drawing.Size(630,565)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.BackColor = $colors.bg
$form.ForeColor = $colors.text
$form.Font = New-Object System.Drawing.Font('Segoe UI',10)
$form.ShowInTaskbar = $true

function New-Label([string]$text,[int]$x,[int]$y,[int]$w,[int]$h,[int]$size,[bool]$bold=$false) {
  $label = New-Object System.Windows.Forms.Label
  $label.Location = New-Object System.Drawing.Point($x,$y)
  $label.Size = New-Object System.Drawing.Size($w,$h)
  $label.Text = $text
  $style = if ($bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
  $label.Font = New-Object System.Drawing.Font('Segoe UI',$size,$style)
  $label.ForeColor = if ($bold) { $colors.text } else { $colors.secondary }
  $form.Controls.Add($label)
  return $label
}
function New-Button([string]$text,[int]$x,[int]$y,[int]$w,[int]$h,[bool]$primary=$false) {
  $button = New-Object System.Windows.Forms.Button
  $button.Location = New-Object System.Drawing.Point($x,$y)
  $button.Size = New-Object System.Drawing.Size($w,$h)
  $button.Text = $text
  $button.FlatStyle = 'Flat'
  $button.FlatAppearance.BorderSize = 0
  $button.BackColor = if ($primary) { $colors.purple } else { $colors.field }
  $button.ForeColor = $colors.text
  $button.Cursor = 'Hand'
  $form.Controls.Add($button)
  return $button
}

[void](New-Label 'BEM-VINDO AO CENSOREDFLOW 2.0' 26 20 565 37 17 $true)
[void](New-Label 'Piloto fechado: o administrador precisa liberar sua conta antes do primeiro uso.' 26 61 570 45 10)
[void](New-Label '1. Abra o Discord para autorizar este aplicativo quando solicitado.' 26 110 570 29 10)
[void](New-Label '2. Se aparecer so um microfone roxo, solicite o convite de testador.' 26 141 570 29 10)
[void](New-Label '3. Aceite o convite no e-mail da sua conta Discord e reabra o widget.' 26 172 570 40 10)

[void](New-Label 'Seu nome de usuario Discord (nao e apelido):' 26 219 570 26 10 $true)
$input = New-Object System.Windows.Forms.TextBox
$input.Location = New-Object System.Drawing.Point(26,247)
$input.Size = New-Object System.Drawing.Size(565,32)
$input.Font = New-Object System.Drawing.Font('Segoe UI',11)
$input.BackColor = $colors.field
$input.ForeColor = $colors.text
$input.BorderStyle = 'FixedSingle'
$form.Controls.Add($input)

$copy = New-Button 'Copiar pedido de liberacao' 26 294 268 37 $true
$discord = New-Button 'Abrir Discord' 302 294 138 37
$check = New-Button 'Verificar acesso' 448 294 143 37
$gmail = New-Button 'Abrir Gmail' 26 345 175 36
$outlook = New-Button 'Abrir Outlook' 209 345 175 36
$close = New-Button 'Concluir' 392 345 199 36 $true

$status = New-Label '' 26 400 565 50 10
$note = New-Label 'Nenhum convite e enviado automaticamente. Envie o texto copiado ao administrador, que cadastrara seu usuario no Portal do Discord. Nunca compartilhe sua senha.' 26 449 565 48 9

$copy.Add_Click({
  $username = [string]$input.Text
  $username = $username.Trim()
  if (-not $username -or $username.Length -gt 100) {
    [System.Windows.Forms.MessageBox]::Show('Digite o nome de usuario exato do Discord.','CensoredFlow 2.0') | Out-Null
    return
  }
  $message = "Ola! Meu usuario do Discord e: $username. Preciso ser convidado como testador do aplicativo Widget de voz V2. Depois aceito o convite no meu e-mail."
  [System.Windows.Forms.Clipboard]::SetText($message)
  $status.Text = 'Pedido copiado. Envie por mensagem ao administrador.'
})
$discord.Add_Click({ Start-Process 'https://discord.com/channels/@me' })
$gmail.Add_Click({ Start-Process 'https://mail.google.com/mail/u/0/#all' })
$outlook.Add_Click({ Start-Process 'https://outlook.live.com/mail/' })
$check.Add_Click({
  if (Test-RpcRegistered) {
    $status.Text = 'Autorizacao registrada! Entre numa chamada de voz para conferir os avatares.'
  } else {
    $status.Text = 'Ainda sem autorizacao registrada. Verifique o convite e reinicie o widget depois de aceita-lo.'
  }
})
$close.Add_Click({ $form.Close() })
if (Test-RpcRegistered) {
  $status.Text = 'Autorizacao registrada. Entre numa chamada para confirmar os avatares.'
} else {
  $status.Text = 'Aguardando autorizacao. Se ja clicou em Autorizar, solicite o convite ao administrador.'
}
[void]$form.ShowDialog()
$form.Dispose()
