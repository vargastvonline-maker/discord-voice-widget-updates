$ErrorActionPreference = 'SilentlyContinue'

$utf8 = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $utf8
$OutputEncoding = $utf8

while ($true) {
    $active = $false

    try {
        $active = @(Get-Process -Name 'TslGame' -ErrorAction SilentlyContinue).Count -gt 0
    } catch {
        $active = $false
    }

    if ($active) {
        [Console]::Out.WriteLine('TslGame')
    } else {
        [Console]::Out.WriteLine('Desktop')
    }

    [Console]::Out.Flush()
    Start-Sleep -Milliseconds 1000
}
