@echo off
setlocal
title Desinstalar Discord Voice Widget
cd /d "%TEMP%"
echo.
echo Desinstalador - Discord Voice Widget V2.2
echo Apenas o widget sera removido. Discord e outros programas serao preservados.
echo.
if "%DW_UNINSTALL_TESTMODE%"=="1" goto Confirmed
choice /C SN /N /M "Deseja remover completamente o widget? [S/N]: "
if errorlevel 2 (
 echo Operacao cancelada.
 pause
 exit /b 0
)
:Confirmed
set "TEMP_UNINSTALL=%TEMP%\DiscordVoiceWidget-Uninstall-%RANDOM%-%RANDOM%.ps1"
copy /y "%~dp0DESINSTALAR_WIDGET.ps1" "%TEMP_UNINSTALL%" >nul
if errorlevel 1 (
 echo Falha ao preparar o desinstalador. Confira os arquivos do pacote.
 pause
 exit /b 10
)
rem Execute o trabalhador de fora da pasta instalada. O launcher pode ser apagado com seguranca.
if "%DW_UNINSTALL_TESTMODE%"=="1" (
 start "" /b powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%TEMP_UNINSTALL%" -Quiet
) else (
 start "Desinstalador Discord Voice Widget" powershell.exe -NoProfile -NoExit -ExecutionPolicy Bypass -File "%TEMP_UNINSTALL%" -Quiet
)
if errorlevel 1 (
 echo Falha ao iniciar a limpeza. Consulte %%TEMP%%\DiscordVoiceWidget-Uninstall.log
 if not "%DW_UNINSTALL_TESTMODE%"=="1" pause
 exit /b 11
)
echo Desinstalacao iniciada. Confira o resultado na janela do PowerShell.
echo Log: %TEMP%\DiscordVoiceWidget-Uninstall.log
exit /b 0
