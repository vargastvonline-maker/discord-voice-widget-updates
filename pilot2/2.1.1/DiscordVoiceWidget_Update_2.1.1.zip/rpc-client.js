const net = require('net');
const https = require('https');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { safeStorage } = require('electron');

class DiscordRpcClient {
  constructor(root, options = {}) {
    this.root = root;
    this.clientId = String(options.clientId || '');
    this.redirectUri = String(options.redirectUri || 'http://127.0.0.1/callback');
    this.scopes = Array.isArray(options.scopes) ? options.scopes : ['rpc','identify','rpc.voice.read','rpc.voice.write'];
    this.tokenFile = path.join(root, 'rpc.auth.bin');
    this.sock = null;
    this.buf = Buffer.alloc(0);
    this.waiters = new Map();
    this.connected = false;
    this.authenticated = false;
    this.authData = null;
  }

  _frame(op, obj) {
    const body = Buffer.from(JSON.stringify(obj), 'utf8');
    const out = Buffer.alloc(8 + body.length);
    out.writeUInt32LE(op, 0);
    out.writeUInt32LE(body.length, 4);
    body.copy(out, 8);
    return out;
  }

  _connectPipe(index) {
    return new Promise((resolve, reject) => {
      const pipe = '\\\\?\\pipe\\discord-ipc-' + index;
      const sock = net.createConnection(pipe);
      const fail = (e) => { cleanup(); try { sock.destroy(); } catch {} reject(e); };
      const ok = () => { cleanup(); resolve(sock); };
      const cleanup = () => { sock.off('error', fail); sock.off('connect', ok); };
      sock.once('error', fail);
      sock.once('connect', ok);
    });
  }

  async _connectRaw() {
    for (let i = 0; i < 10; i++) {
      try { return await this._connectPipe(i); } catch {}
    }
    throw new Error('Discord IPC não encontrado. Abra o Discord Desktop.');
  }

  _installReader(sock) {
    this.buf = Buffer.alloc(0);
    sock.on('data', (chunk) => {
      this.buf = Buffer.concat([this.buf, chunk]);
      while (this.buf.length >= 8) {
        const op = this.buf.readUInt32LE(0);
        const len = this.buf.readUInt32LE(4);
        if (this.buf.length < 8 + len) return;

        const raw = this.buf.subarray(8, 8 + len).toString('utf8');
        this.buf = this.buf.subarray(8 + len);

        let msg;
        try { msg = JSON.parse(raw); } catch { continue; }

        if (op === 2) {
          for (const [, w] of this.waiters) {
            clearTimeout(w.timer);
            w.reject(new Error('Discord encerrou a conexão RPC.'));
          }
          this.waiters.clear();
          this.connected = false;
          this.authenticated = false;
          continue;
        }

        const key = msg && msg.nonce ? msg.nonce : (msg && msg.evt === 'READY' ? '__READY__' : null);
        if (key && this.waiters.has(key)) {
          const w = this.waiters.get(key);
          this.waiters.delete(key);
          clearTimeout(w.timer);
          w.resolve(msg);
        }
      }
    });

    sock.on('close', () => {
      this.connected = false;
      this.authenticated = false;
      this.sock = null;
    });
    sock.on('error', () => {
      this.connected = false;
      this.authenticated = false;
    });
  }

  _wait(key, timeout = 15000) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.waiters.delete(key);
        reject(new Error('Timeout RPC: ' + key));
      }, timeout);
      this.waiters.set(key, { resolve, reject, timer });
    });
  }

  _request(cmd, args = {}, timeout = 15000) {
    if (!this.sock || this.sock.destroyed) return Promise.reject(new Error('RPC desconectado.'));
    const nonce = crypto.randomUUID();
    const p = this._wait(nonce, timeout);
    this.sock.write(this._frame(1, { cmd, args, nonce }));
    return p;
  }

  async _handshake() {
    if (this.sock && !this.sock.destroyed && this.connected) return;
    this.sock = await this._connectRaw();
    this._installReader(this.sock);
    const ready = this._wait('__READY__', 7000);
    this.sock.write(this._frame(0, { v: 1, client_id: this.clientId }));
    await ready;
    this.connected = true;
  }

  _saveToken(data) {
    try {
      if (!safeStorage.isEncryptionAvailable()) return false;
      const payload = JSON.stringify({
        access_token: data.access_token,
        expires_at: Date.now() + Math.max(60, Number(data.expires_in || 0)) * 1000
      });
      const encrypted = safeStorage.encryptString(payload);
      fs.writeFileSync(this.tokenFile, encrypted);
      return true;
    } catch {
      return false;
    }
  }

  _loadToken() {
    try {
      if (!fs.existsSync(this.tokenFile) || !safeStorage.isEncryptionAvailable()) return null;
      const encrypted = fs.readFileSync(this.tokenFile);
      const payload = JSON.parse(safeStorage.decryptString(encrypted));
      if (!payload.access_token || !payload.expires_at) return null;
      if (Date.now() > Number(payload.expires_at) - 60000) return null;
      return payload;
    } catch {
      return null;
    }
  }

  _deleteToken() {
    try { fs.rmSync(this.tokenFile, { force: true }); } catch {}
  }

  _exchangeCode(code, codeVerifier) {
    return new Promise((resolve, reject) => {
      const body = new URLSearchParams({
        client_id: this.clientId,
        grant_type: 'authorization_code',
        code,
        redirect_uri: this.redirectUri,
        code_verifier: codeVerifier
      }).toString();

      const req = https.request({
        hostname: 'discord.com',
        path: '/api/oauth2/token',
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(body)
        }
      }, (res) => {
        let data = '';
        res.on('data', c => data += c);
        res.on('end', () => {
          let obj = {};
          try { obj = JSON.parse(data); } catch {}
          if (res.statusCode >= 200 && res.statusCode < 300 && obj.access_token) {
            resolve(obj);
          } else {
            reject(new Error(obj.error_description || obj.message || obj.error || ('OAuth HTTP ' + res.statusCode)));
          }
        });
      });
      req.on('error', reject);
      req.end(body);
    });
  }

  async _authorizeInteractive() {
    const codeVerifier = crypto.randomBytes(48).toString('base64url');
    const codeChallenge = crypto.createHash('sha256').update(codeVerifier).digest('base64url');

    const auth = await this._request('AUTHORIZE', {
      client_id: this.clientId,
      scopes: this.scopes,
      code_challenge: codeChallenge,
      code_challenge_method: 'S256'
    }, 90000);

    if (auth.evt === 'ERROR' || !auth.data || typeof auth.data.code !== 'string') {
      throw new Error(auth.data && (auth.data.message || auth.data.code) || 'Autorização RPC recusada.');
    }

    const token = await this._exchangeCode(auth.data.code, codeVerifier);
    this._saveToken(token);
    return token.access_token;
  }

  async _authenticate(accessToken) {
    const msg = await this._request('AUTHENTICATE', { access_token: accessToken }, 15000);
    if (msg.evt === 'ERROR') {
      throw new Error(msg.data && (msg.data.message || msg.data.code) || 'Falha ao autenticar RPC.');
    }
    this.authenticated = true;
    this.authData = msg.data || null;
    return this.authData;
  }

  async ensureAuthenticated({ interactive = true } = {}) {
    await this._handshake();
    if (this.authenticated) return this.authData;

    const saved = this._loadToken();
    if (saved && saved.access_token) {
      try {
        return await this._authenticate(saved.access_token);
      } catch {
        this._deleteToken();
      }
    }

    if (!interactive) throw new Error('RPC ainda não autorizado.');
    const accessToken = await this._authorizeInteractive();
    return await this._authenticate(accessToken);
  }

  async getSelectedVoiceChannel() {
    await this.ensureAuthenticated();
    const msg = await this._request('GET_SELECTED_VOICE_CHANNEL', {}, 15000);
    if (msg.evt === 'ERROR') {
      throw new Error(msg.data && (msg.data.message || msg.data.code) || 'Não foi possível ler a call.');
    }
    return msg.data || null;
  }

  _logAction(entry) {
    try {
      const line = JSON.stringify({ at: new Date().toISOString(), ...entry }) + '\n';
      fs.appendFileSync(path.join(this.root, 'rpc-actions.log'), line, 'utf8');
    } catch {}
  }

  async setUserVoiceSettings(userId, patch) {
    await this.ensureAuthenticated();
    const args = { user_id: String(userId || '') };
    if (Object.prototype.hasOwnProperty.call(patch, 'volume')) args.volume = Math.max(0, Math.min(200, Math.round(Number(patch.volume))));
    if (Object.prototype.hasOwnProperty.call(patch, 'mute')) args.mute = Boolean(patch.mute);
    if (patch && patch.pan && typeof patch.pan === 'object') {
      const left = Math.max(0, Math.min(1, Number(patch.pan.left)));
      const right = Math.max(0, Math.min(1, Number(patch.pan.right)));
      if (Number.isFinite(left) && Number.isFinite(right)) args.pan = { left, right };
    }

    const msg = await this._request('SET_USER_VOICE_SETTINGS', args, 15000);
    if (msg.evt === 'ERROR') {
      const error = msg.data && (msg.data.message || msg.data.code) || 'Falha ao alterar voz.';
      this._logAction({ action: 'SET_USER_VOICE_SETTINGS', ok: false, user_id: args.user_id, volume: args.volume, mute: args.mute, pan: args.pan, error: String(error) });
      throw new Error(error);
    }
    this._logAction({ action: 'SET_USER_VOICE_SETTINGS', ok: true, user_id: args.user_id, volume: args.volume, mute: args.mute, pan: args.pan });
    return msg.data || null;
  }

  close() {
    try { this.sock?.end(); } catch {}
    this.sock = null;
    this.connected = false;
    this.authenticated = false;
  }
}

module.exports = { DiscordRpcClient };
