const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const http = require('http');
const https = require('https');
const { fileURLToPath } = require('url');
const { spawn } = require('child_process');

class WidgetUpdater {
  constructor(root, options = {}) {
    this.root = root;
    this.onState = typeof options.onState === 'function' ? options.onState : () => {};
    this.defaultsPath = path.join(root, 'updater.defaults.json');
    this.localPath = path.join(root, 'updater.local.json');
    this.publicKeyPath = path.join(root, 'updater-public-key.pem');
    this.applyScript = path.join(root, 'ApplyUpdateV21.ps1');
    this.updateDir = path.join(root, '.updates');
    this.readyPath = path.join(this.updateDir, 'ready.json');
    this.lockPath = path.join(root, 'update.lock');
    this.state = { status: 'idle', message: '', ready: null, lastCheck: null };
    fs.mkdirSync(this.updateDir, { recursive: true });
    this._loadReadyState();
  }

  _emit(patch) {
    this.state = { ...this.state, ...patch };
    try { this.onState({ ...this.state }); } catch {}
    return { ...this.state };
  }

  getCurrentVersion() {
    try {
      const pkg = JSON.parse(fs.readFileSync(path.join(this.root, 'package.json'), 'utf8'));
      return String(pkg.version || '0.0.0');
    } catch {
      return '0.0.0';
    }
  }

  getConfig() {
    const read = (p) => {
      try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return {}; }
    };
    return { ...read(this.defaultsPath), ...read(this.localPath) };
  }

  getState() {
    return { ...this.state };
  }

  getReadyUpdate() {
    return this.state.ready ? { ...this.state.ready } : null;
  }

  _loadReadyState() {
    try {
      const ready = JSON.parse(fs.readFileSync(this.readyPath, 'utf8'));
      if (ready && ready.packagePath && fs.existsSync(ready.packagePath) &&
          this._compareVersions(String(ready.version || '0.0.0'), this.getCurrentVersion()) > 0) {
        this.state.ready = ready;
        this.state.status = 'ready';
        this.state.message = 'Atualização ' + ready.version + ' pronta';
        return;
      }
    } catch {}
    try { fs.rmSync(this.readyPath, { force: true }); } catch {}
  }

  _parseVersion(v) {
    return String(v || '0.0.0').split('-')[0].split('.').map((x) => {
      const n = Number.parseInt(x, 10);
      return Number.isFinite(n) ? n : 0;
    }).slice(0, 3).concat([0, 0, 0]).slice(0, 3);
  }

  _compareVersions(a, b) {
    const av = this._parseVersion(a);
    const bv = this._parseVersion(b);
    for (let i = 0; i < 3; i++) {
      if (av[i] > bv[i]) return 1;
      if (av[i] < bv[i]) return -1;
    }
    return 0;
  }

  _canonicalManifest(m) {
    return JSON.stringify({
      schemaVersion: Number(m.schemaVersion || 1),
      channel: String(m.channel || ''),
      version: String(m.version || ''),
      publishedAt: String(m.publishedAt || ''),
      packageUrl: String(m.packageUrl || ''),
      sha256: String(m.sha256 || '').toUpperCase(),
      runNpmCi: Boolean(m.runNpmCi),
      minVersion: String(m.minVersion || ''),
      notes: String(m.notes || '')
    });
  }

  _validateTransport(urlString, cfg) {
    let u;
    try { u = new URL(urlString); } catch { throw new Error('URL de atualização inválida.'); }
    if (u.protocol === 'https:') return u;
    if (u.protocol === 'file:' && cfg.allowInsecureLocalTest === true) return u;
    if (u.protocol === 'http:' && cfg.allowInsecureLocalTest === true &&
        (u.hostname === '127.0.0.1' || u.hostname === 'localhost')) return u;
    throw new Error('Fonte de atualização deve usar HTTPS.');
  }

  _fetchBuffer(urlString, cfg, redirects = 0) {
    const u = this._validateTransport(urlString, cfg);
    if (u.protocol === 'file:') {
      return fs.promises.readFile(fileURLToPath(u));
    }

    const transport = u.protocol === 'https:' ? https : http;
    return new Promise((resolve, reject) => {
      const req = transport.get(u, {
        headers: {
          'User-Agent': 'DiscordVoiceWidget-Updater/' + this.getCurrentVersion(),
          'Cache-Control': 'no-cache'
        }
      }, (res) => {
        const code = Number(res.statusCode || 0);
        if (code >= 300 && code < 400 && res.headers.location) {
          res.resume();
          if (redirects >= 5) return reject(new Error('Muitos redirecionamentos na atualização.'));
          let next;
          try { next = new URL(res.headers.location, u).toString(); } catch { return reject(new Error('Redirecionamento inválido.')); }
          return this._fetchBuffer(next, cfg, redirects + 1).then(resolve, reject);
        }
        if (code < 200 || code >= 300) {
          res.resume();
          return reject(new Error('HTTP ' + code + ' ao buscar atualização.'));
        }

        const chunks = [];
        let total = 0;
        const maxBytes = 64 * 1024 * 1024;
        res.on('data', (chunk) => {
          total += chunk.length;
          if (total > maxBytes) {
            req.destroy(new Error('Pacote de atualização excede 64 MB.'));
            return;
          }
          chunks.push(chunk);
        });
        res.on('end', () => resolve(Buffer.concat(chunks)));
      });
      req.setTimeout(15000, () => req.destroy(new Error('Timeout ao buscar atualização.')));
      req.on('error', reject);
    });
  }

  _verifyManifest(manifest, cfg) {
    if (!manifest || Number(manifest.schemaVersion) !== 1) throw new Error('Manifesto incompatível.');
    if (String(manifest.channel || '') !== String(cfg.channel || '')) throw new Error('Canal de atualização incorreto.');
    if (!manifest.version || !manifest.packageUrl || !manifest.sha256 || !manifest.signature) {
      throw new Error('Manifesto incompleto.');
    }

    const publicKey = fs.readFileSync(this.publicKeyPath, 'utf8');
    const data = Buffer.from(this._canonicalManifest(manifest), 'utf8');
    const signature = Buffer.from(String(manifest.signature), 'base64');
    if (!crypto.verify(null, data, publicKey, signature)) {
      throw new Error('Assinatura da atualização inválida.');
    }
  }

  async checkForUpdates(options = {}) {
    const cfg = this.getConfig();
    const now = new Date().toISOString();

    if (cfg.enabled === false) {
      return this._emit({ status: 'disabled', message: 'Atualizações desativadas', lastCheck: now });
    }
    if (!cfg.manifestUrl) {
      return this._emit({ status: 'unconfigured', message: 'Fonte de atualização ainda não configurada', lastCheck: now });
    }

    this._emit({ status: 'checking', message: 'Verificando atualizações...', lastCheck: now });
    try {
      const manifestUrl = this._validateTransport(String(cfg.manifestUrl), cfg).toString();
      const raw = await this._fetchBuffer(manifestUrl, cfg);
      const manifest = JSON.parse(raw.toString('utf8'));
      this._verifyManifest(manifest, cfg);

      const current = this.getCurrentVersion();
      if (manifest.minVersion && this._compareVersions(current, manifest.minVersion) < 0) {
        return this._emit({
          status: 'full_install_required',
          message: 'Esta atualização exige reinstalação completa.',
          available: manifest
        });
      }

      if (this._compareVersions(manifest.version, current) <= 0) {
        return this._emit({ status: 'up_to_date', message: 'Você já está na versão mais recente.', ready: null });
      }

      if (options.download === false) {
        return this._emit({
          status: 'available',
          message: 'Versão ' + manifest.version + ' disponível.',
          available: manifest
        });
      }

      return await this.downloadUpdate(manifest, manifestUrl, cfg);
    } catch (error) {
      return this._emit({
        status: 'error',
        message: error && error.message ? error.message : String(error)
      });
    }
  }

  async downloadUpdate(manifest, manifestUrl, cfg = this.getConfig()) {
    this._verifyManifest(manifest, cfg);
    const resolvedPackageUrl = new URL(String(manifest.packageUrl), String(manifestUrl || cfg.manifestUrl)).toString();
    this._validateTransport(resolvedPackageUrl, cfg);

    this._emit({ status: 'downloading', message: 'Baixando versão ' + manifest.version + '...' });
    const data = await this._fetchBuffer(resolvedPackageUrl, cfg);
    const hash = crypto.createHash('sha256').update(data).digest('hex').toUpperCase();
    const expected = String(manifest.sha256 || '').toUpperCase();
    if (hash !== expected) throw new Error('SHA256 do pacote não confere.');

    const packagePath = path.join(this.updateDir, 'DiscordVoiceWidget_Update_' + manifest.version + '.zip');
    fs.writeFileSync(packagePath, data);

    const ready = {
      version: String(manifest.version),
      packagePath,
      sha256: expected,
      runNpmCi: Boolean(manifest.runNpmCi),
      notes: String(manifest.notes || ''),
      downloadedAt: new Date().toISOString()
    };
    fs.writeFileSync(this.readyPath, JSON.stringify(ready, null, 2), 'utf8');

    return this._emit({
      status: 'ready',
      message: 'Atualização ' + ready.version + ' pronta para instalar.',
      ready,
      available: manifest
    });
  }

  _verifyReadyPackage(ready) {
    if (!ready || !ready.packagePath || !fs.existsSync(ready.packagePath)) {
      throw new Error('Pacote de atualização não encontrado.');
    }
    const data = fs.readFileSync(ready.packagePath);
    const hash = crypto.createHash('sha256').update(data).digest('hex').toUpperCase();
    if (hash !== String(ready.sha256 || '').toUpperCase()) {
      throw new Error('Pacote pronto falhou na verificação SHA256.');
    }
  }


  launchApply() {
    const ready = this.getReadyUpdate();
    this._verifyReadyPackage(ready);
    if (!fs.existsSync(this.applyScript)) throw new Error('Aplicador de atualização ausente.');

    const runner = path.join(this.root, 'RunApplyUpdateV21.vbs');
    if (!fs.existsSync(runner)) throw new Error('Launcher silencioso do updater ausente.');

    const current = this.getCurrentVersion();
    const pendingPath = path.join(this.updateDir, 'pending-apply.json');

    fs.writeFileSync(pendingPath, JSON.stringify({
      root: this.root,
      package: ready.packagePath,
      fromVersion: current,
      toVersion: ready.version,
      expectedSha256: ready.sha256,
      runNpmCi: ready.runNpmCi ? '1' : '0',
      requestedAt: new Date().toISOString()
    }, null, 2), 'utf8');

    fs.writeFileSync(this.lockPath, JSON.stringify({
      fromVersion: current,
      toVersion: ready.version,
      startedAt: new Date().toISOString()
    }, null, 2), 'utf8');

    const wscript = path.join(process.env.WINDIR || 'C:\\Windows', 'System32', 'wscript.exe');

    try {
      const child = spawn(wscript, ['//B', '//NoLogo', runner], {
        detached: true,
        stdio: 'ignore',
        windowsHide: true
      });
      child.unref();
    } catch (error) {
      try { fs.rmSync(pendingPath, { force: true }); } catch {}
      try { fs.rmSync(this.lockPath, { force: true }); } catch {}
      throw error;
    }

    this._emit({ status: 'applying', message: 'Aplicando versão ' + ready.version + '...' });
    return { ...ready };
  }
}

module.exports = { WidgetUpdater };
