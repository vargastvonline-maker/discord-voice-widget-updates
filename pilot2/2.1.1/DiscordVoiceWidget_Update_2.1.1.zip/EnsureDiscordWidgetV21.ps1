$ErrorActionPreference = 'SilentlyContinue'
$widgetRoot = $PSScriptRoot
$electron = Join-Path $widgetRoot 'node_modules\electron\dist\electron.exe'
$watcherScript = Join-Path $widgetRoot 'WatchDiscordWidgetV21.ps1'
$watcherVbs = Join-Path $widgetRoot 'StartDiscordWidgetV21Watcher.vbs'
$pidFile = Join-Path $widgetRoot 'watcher-v21.pid'
$log = Join-Path $widgetRoot 'guardian-v21.log'
$updateLock = Join-Path $widgetRoot 'update.lock'

function Log($msg) {
  try {
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + ' ' + $msg
    Add-Content -Path $log -Value $line -Encoding UTF8
    if ((Get-Item $log -ErrorAction SilentlyContinue).Length -gt 1048576) {
      Get-Content $log -Tail 500 | Set-Content $log -Encoding UTF8
    }
  } catch {}
}

function Test-WatcherAlive {
  if (-not (Test-Path $pidFile)) { return $false }
  try {
    $raw = (Get-Content $pidFile -Raw).Trim()
    $watcherPid = 0
    if (-not [int]::TryParse($raw, [ref]$watcherPid)) { return $false }
    $p = Get-Process -Id $watcherPid -ErrorAction Stop
    if ($p.ProcessName -notin @('powershell','pwsh')) { return $false }
    $cim = Get-CimInstance Win32_Process -Filter "ProcessId=$watcherPid" -ErrorAction Stop
    return [bool]($cim.CommandLine -and $cim.CommandLine -like '*WatchDiscordWidgetV21.ps1*')
  } catch {
    return $false
  }
}

if (Test-Path $updateLock) {
  Log 'Atualizacao em andamento; Guardian aguardando.'
  exit
}

if (-not (Test-Path $electron)) { Log 'Electron V2.1 ausente; nenhuma acao.'; exit }
if (-not (Test-Path $watcherScript)) { Log 'Watcher V2.1 ausente; nenhuma acao.'; exit }

$discordRunning = @(Get-Process Discord -ErrorAction SilentlyContinue).Count -gt 0
$widgetProcs = @(Get-Process electron -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $electron })
$watcherAlive = Test-WatcherAlive

if (-not $watcherAlive) {
  Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
  if (Test-Path $watcherVbs) {
    Start-Process -FilePath (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('//B //NoLogo "' + $watcherVbs + '"')
    Log 'Watcher V2.1 estava ausente e foi relancado.'
  } else {
    Start-Process powershell.exe -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $watcherScript + '"') -WindowStyle Hidden
    Log 'Watcher V2.1 estava ausente e foi relancado via PowerShell.'
  }
}

if ($discordRunning -and $widgetProcs.Count -eq 0) {
  Start-Process -FilePath $electron -ArgumentList ('"' + $widgetRoot + '"')
  Log 'Discord aberto e V2.1 ausente; widget relancado.'
}
elseif (-not $discordRunning -and $widgetProcs.Count -gt 0) {
  $widgetProcs | Stop-Process -Force
  Log 'Discord fechado; V2.1 encerrada.'
}
