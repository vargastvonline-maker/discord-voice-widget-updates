const { app, BrowserWindow, globalShortcut, ipcMain, clipboard, shell, screen, Menu, dialog } = require('electron');
const fs = require('fs');
const path = require('path');
const { DiscordRpcClient } = require('./rpc-client');
const { WidgetUpdater } = require('./updater-client');

const CONFIG = path.join(__dirname, 'config.json');
let win;
let volumeWin = null;
let rpcClient = null;
let updateClient = null;
let updaterState = { status: 'idle', message: '', ready: null };
let updaterTimer = null;
let clickThrough = false;
let saveTimer;
let fitTimer;
let manualResize = false;
let resizeOrigin = null;
let moveOrigin = null;

function readConfig() {
  try { return JSON.parse(fs.readFileSync(CONFIG, 'utf8')); }
  catch { return {}; }
}
function writeConfig(patch) {
  const cfg = { ...readConfig(), ...patch };
  fs.writeFileSync(CONFIG, JSON.stringify(cfg, null, 2), 'utf8');
}
function validOverlayUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' &&
      u.hostname === 'streamkit.discord.com' &&
      u.pathname.startsWith('/overlay/voice/');
  } catch { return false; }
}
function positionForNewWindow(width, height) {
  const display = screen.getPrimaryDisplay();
  const a = display.workArea;
  return { x: Math.max(a.x, a.x + a.width - width - 24), y: a.y + 90 };
}

const overlayCss = `
html, body {
  background: transparent !important;
  overflow: hidden !important;
  font-family: Inter, "Segoe UI", sans-serif !important;
}
body {
  margin: 0 !important;
  padding: 42px 10px 10px !important;
  box-sizing: border-box !important;
}
#dw-handle {
  position: fixed;
  z-index: 2147483647;
  left: 8px; right: 8px; top: 7px;
  height: 28px;
  border-radius: 11px;
  background: rgba(18, 20, 29, .88);
  border: 1px solid rgba(255,255,255,.10);
  box-shadow: 0 10px 30px rgba(0,0,0,.28);
  backdrop-filter: blur(16px);
  display: flex;
  align-items: center;
  padding: 0 10px;
  color: rgba(255,255,255,.82);
  font-size: 11px;
  font-weight: 700;
  letter-spacing: .45px;
  -webkit-app-region: drag;
  user-select: none;
}
#dw-handle .dot {
  width: 7px; height: 7px; border-radius: 50%;
  background: #23d18b;
  box-shadow: 0 0 12px rgba(35,209,139,.8);
  margin-right: 7px;
}
#dw-handle .hint {
  margin-left: auto;
  opacity: .48;
  font-weight: 600;
  letter-spacing: 0;
}
ul.voice_states, .voice_states {
  margin: 0 !important;
  padding: 0 !important;
  list-style: none !important;
  display: flex !important;
  flex-direction: column !important;
  gap: 7px !important;
}
li.voice_state, .voice_state {
  position: relative !important;
  min-height: 48px !important;
  box-sizing: border-box !important;
  padding: 7px 38px 7px 8px !important;
  border-radius: 15px !important;
  background: rgba(18,20,29,.88) !important;
  border: 1px solid rgba(255,255,255,.09) !important;
  box-shadow: 0 10px 28px rgba(0,0,0,.22) !important;
  backdrop-filter: blur(18px) !important;
  display: flex !important;
  align-items: center !important;
}
li.voice_state.wrapper_speaking,
li.voice_state[class*="speaking"],
.voice_state.wrapper_speaking,
.voice_state[class*="speaking"] {
  border-color: rgba(35,209,139,.78) !important;
  box-shadow: 0 0 0 1px rgba(35,209,139,.25), 0 0 24px rgba(35,209,139,.22) !important;
}
img.voice_avatar, .voice_avatar {
  width: 34px !important;
  height: 34px !important;
  border-radius: 50% !important;
  margin: 0 9px 0 0 !important;
  border: 2px solid rgba(255,255,255,.18) !important;
  opacity: 1 !important;
}
li.voice_state.wrapper_speaking img.voice_avatar,
li.voice_state[class*="speaking"] img.voice_avatar {
  border-color: #23d18b !important;
}
.voice_name, .name {
  color: #f7f8fb !important;
  font-size: 13px !important;
  font-weight: 650 !important;
  text-shadow: none !important;
  opacity: .96 !important;
}
li.voice_state.mute::after,
li.voice_state.self_mute::after,
li.voice_state[class~="mute"]::after,
li.voice_state[class~="self_mute"]::after {
  content: "MIC OFF" !important;
  position: absolute !important;
  right: 8px !important;
  top: 50% !important;
  transform: translateY(-50%) !important;
  padding: 4px 6px !important;
  border-radius: 8px !important;
  background: rgba(244,67,82,.18) !important;
  border: 1px solid rgba(244,67,82,.42) !important;
  color: #ff6b77 !important;
  font-size: 8px !important;
  font-weight: 800 !important;
  letter-spacing: .5px !important;
}
li.voice_state.deaf::after,
li.voice_state.self_deaf::after,
li.voice_state[class~="deaf"]::after,
li.voice_state[class~="self_deaf"]::after {
  content: "DEAF" !important;
  position: absolute !important;
  right: 8px !important;
  top: 50% !important;
  transform: translateY(-50%) !important;
  padding: 4px 6px !important;
  border-radius: 8px !important;
  background: rgba(255,176,32,.16) !important;
  border: 1px solid rgba(255,176,32,.38) !important;
  color: #ffc257 !important;
  font-size: 8px !important;
  font-weight: 800 !important;
}
`;

const miniCss = `
:root {
  --dw-avatar: clamp(22px, calc(100vw - 16px), 54px);
  --dw-row: calc(var(--dw-avatar) + 4px);
}
html {
  background: transparent !important;
  width: 100% !important;
  height: 100% !important;
  overflow: visible !important;
}
body {
  background: transparent !important;
  width: 100% !important;
  height: 100% !important;
  min-height: 100% !important;
  overflow: visible !important;
  margin: 0 !important;
  padding: 5px !important;
  box-sizing: border-box !important;
  -webkit-app-region: drag !important;
}
html, body, .voice_container, .voice_states, [class*="Voice_voiceContainer"], [class*="Voice_voiceStates"] {
  scrollbar-width: none !important;
  -ms-overflow-style: none !important;
}
html::-webkit-scrollbar,
body::-webkit-scrollbar,
.voice_container::-webkit-scrollbar,
.voice_states::-webkit-scrollbar,
[class*="Voice_voiceContainer"]::-webkit-scrollbar,
[class*="Voice_voiceStates"]::-webkit-scrollbar,
*::-webkit-scrollbar {
  width: 0 !important;
  height: 0 !important;
  display: none !important;
  background: transparent !important;
}
#dw-handle { display: none !important; }
#dw-resize {
  position: fixed !important;
  right: 1px !important;
  bottom: 1px !important;
  width: 10px !important;
  height: 10px !important;
  z-index: 99999 !important;
  cursor: nwse-resize !important;
  -webkit-app-region: no-drag !important;
  opacity: .28 !important;
  border-right: 2px solid rgba(255,255,255,.55) !important;
  border-bottom: 2px solid rgba(255,255,255,.55) !important;
  border-bottom-right-radius: 2px !important;
}
#dw-resize:hover { opacity: .78 !important; }

#dw-move {
  position: fixed !important;
  top: 1px !important;
  left: 50% !important;
  transform: translateX(-50%) !important;
  width: 16px !important;
  height: 6px !important;
  z-index: 100000 !important;
  -webkit-app-region: drag !important;
  cursor: move !important;
  opacity: .10 !important;
  border-top: 2px solid rgba(255,255,255,.72) !important;
  border-radius: 999px !important;
  transition: opacity .12s ease !important;
}
#dw-move:hover { opacity: .72 !important; }

li.voice_state,
.voice_state,
img.voice_avatar,
.voice_avatar,
[class*="Voice_voiceState"],
[class*="Voice_avatar"] {
  -webkit-app-region: no-drag !important;
}
li.voice_state,
.voice_state,
[class*="Voice_voiceState"] {
  cursor: context-menu !important;
}

.voice_container,
[class*="Voice_voiceContainer"] {
  background: transparent !important;
  width: auto !important;
  min-width: 0 !important;
  overflow: visible !important;
  height: auto !important;
}

ul.voice_states,
.voice_states,
[class*="Voice_voiceStates"] {
  display: flex !important;
  flex-direction: column !important;
  align-items: flex-start !important;
  gap: 2px !important;
  margin: 0 !important;
  padding: 0 !important;
  list-style: none !important;
  background: transparent !important;
  height: auto !important;
  min-height: 0 !important;
}

body[data-dw-layout="horizontal"] {
  --dw-avatar: clamp(22px, calc(100vh - 16px), 54px);
  --dw-row: calc(var(--dw-avatar) + 4px);
}

body[data-dw-layout="horizontal"] ul.voice_states,
body[data-dw-layout="horizontal"] .voice_states,
body[data-dw-layout="horizontal"] [class*="Voice_voiceStates"] {
  flex-direction: row !important;
  align-items: center !important;
  flex-wrap: nowrap !important;
  gap: 3px !important;
}

body[data-dw-layout="horizontal"] li.voice_state.self_mute::before,
body[data-dw-layout="horizontal"] li.voice_state.mute::before,
body[data-dw-layout="horizontal"] li.voice_state[class~="self_mute"]::before,
body[data-dw-layout="horizontal"] li.voice_state[class~="mute"]::before,
body[data-dw-layout="horizontal"] li.voice_state.self_deaf::before,
body[data-dw-layout="horizontal"] li.voice_state.deaf::before,
body[data-dw-layout="horizontal"] li.voice_state[class~="self_deaf"]::before,
body[data-dw-layout="horizontal"] li.voice_state[class~="deaf"]::before {
  left: 4.5px !important;
  top: 4.5px !important;
  width: calc(var(--dw-avatar) - 5px) !important;
  height: calc(var(--dw-avatar) - 5px) !important;
  transform: none !important;
  border-width: 1.5px !important;
  background: rgba(215, 0, 18, .24) !important;
  box-shadow: 0 0 5px rgba(235,0,20,.26) !important;
}

body[data-dw-layout="horizontal"] li.voice_state.self_mute::after,
body[data-dw-layout="horizontal"] li.voice_state.mute::after,
body[data-dw-layout="horizontal"] li.voice_state[class~="self_mute"]::after,
body[data-dw-layout="horizontal"] li.voice_state[class~="mute"]::after,
body[data-dw-layout="horizontal"] li.voice_state.self_deaf::after,
body[data-dw-layout="horizontal"] li.voice_state.deaf::after,
body[data-dw-layout="horizontal"] li.voice_state[class~="self_deaf"]::after,
body[data-dw-layout="horizontal"] li.voice_state[class~="deaf"]::after {
  left: 50% !important;
  right: auto !important;
  top: 46% !important;
  width: calc(var(--dw-avatar) + 2px) !important;
  padding: 1px 0 !important;
  border-width: 1px !important;
  font-size: clamp(4px, 11vh, 7px) !important;
  font-weight: 980 !important;
  letter-spacing: -.15px !important;
  white-space: nowrap !important;
  transform: translate(-50%, -50%) rotate(-21deg) !important;
  box-shadow: 0 1px 4px rgba(0,0,0,.34) !important;
}

li.voice_state,
.voice_state,
[class*="Voice_voiceState"] {
  position: relative !important;
  width: var(--dw-row) !important;
  min-width: var(--dw-row) !important;
  height: var(--dw-row) !important;
  min-height: var(--dw-row) !important;
  margin: 0 !important;
  padding: 0 !important;
  background: transparent !important;
  border: 0 !important;
  box-shadow: none !important;
  backdrop-filter: none !important;
  display: block !important;
  overflow: visible !important;
  opacity: 1 !important;
  visibility: visible !important;
}

li.voice_state *,
.voice_state *,
[class*="Voice_voiceState"] * {
  visibility: visible !important;
}

img.voice_avatar,
img[class*="Voice_avatar"] {
  width: var(--dw-avatar) !important;
  height: var(--dw-avatar) !important;
  min-width: var(--dw-avatar) !important;
  min-height: var(--dw-avatar) !important;
  margin: 2px !important;
  padding: 0 !important;
  float: none !important;
  display: block !important;
  visibility: visible !important;
  border-radius: 50% !important;
  box-sizing: border-box !important;
  border: 1px solid rgba(190,200,220,.16) !important;
  box-shadow: 0 1px 5px rgba(0,0,0,.10) !important;
  opacity: .37 !important;
  filter: grayscale(.10) brightness(.82) !important;
  transition: border-color .12s ease, box-shadow .12s ease, filter .12s ease, transform .12s ease, opacity .12s ease !important;
}

li.voice_state.wrapper_speaking img.voice_avatar,
li.voice_state[class*="speaking"] img.voice_avatar,
img.voice_avatar.speaking,
img[class*="Voice_avatarSpeaking"] {
  border-color: #2eea98 !important;
  box-shadow: 0 0 0 2px rgba(46,234,152,.34), 0 0 16px rgba(46,234,152,.92) !important;
  filter: brightness(1.14) saturate(1.08) !important;
  opacity: 1 !important;
  transform: scale(1.055) !important;
}

.voice_name,
.name,
[class*="Voice_name"] {
  display: none !important;
}

li.voice_state.self_mute img.voice_avatar,
li.voice_state.mute img.voice_avatar,
li.voice_state[class~="self_mute"] img.voice_avatar,
li.voice_state[class~="mute"] img.voice_avatar,
li.voice_state.self_deaf img.voice_avatar,
li.voice_state.deaf img.voice_avatar,
li.voice_state[class~="self_deaf"] img.voice_avatar,
li.voice_state[class~="deaf"] img.voice_avatar {
  filter: grayscale(.74) brightness(.44) !important;
  opacity: .62 !important;
  border-color: rgba(235,0,20,.78) !important;
  box-shadow: 0 0 0 1px rgba(235,0,20,.18), 0 2px 8px rgba(0,0,0,.24) !important;
}

li.voice_state.self_mute::before,
li.voice_state.mute::before,
li.voice_state[class~="self_mute"]::before,
li.voice_state[class~="mute"]::before,
li.voice_state.self_deaf::before,
li.voice_state.deaf::before,
li.voice_state[class~="self_deaf"]::before,
li.voice_state[class~="deaf"]::before {
  content: "" !important;
  position: absolute !important;
  left: 50% !important;
  top: 50% !important;
  width: calc(var(--dw-avatar) + 2px) !important;
  height: calc(var(--dw-avatar) + 2px) !important;
  transform: translate(-50%, -50%) !important;
  z-index: 20 !important;
  box-sizing: border-box !important;
  border-radius: 50% !important;
  border: 2px solid rgba(235, 0, 20, .98) !important;
  background: rgba(215, 0, 18, .28) !important;
  box-shadow:
    0 0 0 1px rgba(255,255,255,.14) inset,
    0 0 8px rgba(235,0,20,.32) !important;
  pointer-events: none !important;
}

li.voice_state.self_mute::after,
li.voice_state.mute::after,
li.voice_state[class~="self_mute"]::after,
li.voice_state[class~="mute"]::after,
li.voice_state.self_deaf::after,
li.voice_state.deaf::after,
li.voice_state[class~="self_deaf"]::after,
li.voice_state[class~="deaf"]::after {
  content: "CENSORED" !important;
  position: absolute !important;
  left: -6px !important;
  right: -6px !important;
  top: 50% !important;
  transform: translateY(-50%) rotate(-10deg) !important;
  z-index: 21 !important;
  padding: 2px 1px !important;
  box-sizing: border-box !important;
  border-radius: 2px !important;
  border: 2px solid rgba(180, 0, 14, 1) !important;
  background: rgba(220, 0, 18, .98) !important;
  color: #ffffff !important;
  font-size: clamp(6px, 15vw, 9px) !important;
  font-weight: 950 !important;
  letter-spacing: .35px !important;
  line-height: 1 !important;
  text-align: center !important;
  text-shadow: 0 1px 1px rgba(85,0,0,.85) !important;
  box-shadow: 0 2px 7px rgba(0,0,0,.42) !important;
  pointer-events: none !important;
}
`;

function currentWidgetLayout() {
  return readConfig().layout === 'horizontal' ? 'horizontal' : 'vertical';
}

function fitMiniToPeople() {
  if (!win || win.isDestroyed() || manualResize) return;
  win.webContents.executeJavaScript(`(() => {
    const avatars = Array.from(document.querySelectorAll('img.voice_avatar, img[class*="Voice_avatar"], .voice_avatar'));
    const unique = Array.from(new Set(avatars));
    return unique.filter(el => el && el.getBoundingClientRect().height > 0).length;
  })()`).then(count => {
    if (!win || win.isDestroyed()) return;

    const layout = currentWidgetLayout();
  const readyUpdate = updateClient ? updateClient.getReadyUpdate() : null;
  const currentAppVersion = updateClient ? updateClient.getCurrentVersion() : '2.1.1';
    const display = screen.getDisplayMatching(win.getBounds());
    const b = win.getBounds();
    const people = Number(count) || 1;

    if (layout === 'horizontal') {
      const maxW = Math.max(64, display.workArea.width - 40);
      const targetW = Math.min(maxW, Math.max(38, people * 30 + 6));
      if (b.width !== targetW || b.height !== 40) {
        win.setBounds({ x:b.x, y:b.y, width:targetW, height:40 });
      }
      return;
    }

    const maxH = Math.max(64, display.workArea.height - 40);
    const targetH = Math.min(maxH, Math.max(38, people * 30 + 6));
    if (b.height !== targetH || b.width !== 40) {
      win.setBounds({ x:b.x, y:b.y, width:40, height:targetH });
    }
  }).catch(() => {});
}

function setWidgetLayout(layout) {
  const next = layout === 'horizontal' ? 'horizontal' : 'vertical';
  manualResize = false;
  writeConfig({ layout: next, manualSize: false });

  if (!win || win.isDestroyed()) return;

  win.webContents.executeJavaScript(`(() => {
    document.body.dataset.dwLayout = ${JSON.stringify(next)};
  })()`).catch(() => {});

  fitMiniToPeople();
}

function decorate() {
  if (!win || win.isDestroyed()) return;
  win.webContents.insertCSS(overlayCss).catch(() => {});
  win.webContents.insertCSS(miniCss).catch(() => {});
  win.webContents.executeJavaScript(`
    (() => {
      document.body.dataset.dwLayout = ${JSON.stringify(currentWidgetLayout())};

      if (!document.getElementById('dw-handle')) {
        const h = document.createElement('div');
        h.id = 'dw-handle';
        h.innerHTML = '<span class="dot"></span><span>DISCORD VOICE</span><span class="hint">Ctrl+Alt+F10 trava</span>';
        document.body.appendChild(h);
      }
      if (!document.getElementById('dw-move')) {
        const m = document.createElement('div');
        m.id = 'dw-move';
        m.title = 'Arrastar widget';
        document.body.appendChild(m);
      }
      if (!document.getElementById('dw-resize')) {
        const r = document.createElement('div');
        r.id = 'dw-resize';
        document.body.appendChild(r);
        let resizing = false;
        r.addEventListener('mousedown', (e) => {
          resizing = true;
          window.widgetApi?.beginResize(e.screenX, e.screenY);
          e.preventDefault();
          e.stopPropagation();
        });
        window.addEventListener('mousemove', (e) => {
          if (!resizing) return;
          window.widgetApi?.resizeTo(e.screenX, e.screenY);
          e.preventDefault();
        });
        window.addEventListener('mouseup', () => {
          if (!resizing) return;
          resizing = false;
          window.widgetApi?.endResize();
        });
      }

      if (!window.__dwUniversalDragBound) {
        window.__dwUniversalDragBound = true;
        let moving = false;

        document.addEventListener('dragstart', (e) => {
          if (e.target?.closest?.('img.voice_avatar, img[class*="Voice_avatar"], .voice_avatar')) {
            e.preventDefault();
          }
        }, true);

        document.addEventListener('mousedown', (e) => {
          if (e.button !== 0) return;
          if (e.target?.closest?.('#dw-resize')) return;
          const row = e.target?.closest?.('li.voice_state, .voice_state, [class*="Voice_voiceState"]');
          if (!row) return;

          moving = true;
          window.widgetApi?.beginMove(e.screenX, e.screenY);
          e.preventDefault();
          e.stopPropagation();
        }, true);

        window.addEventListener('mousemove', (e) => {
          if (!moving) return;
          window.widgetApi?.moveTo(e.screenX, e.screenY);
          e.preventDefault();
        }, true);

        window.addEventListener('mouseup', (e) => {
          if (!moving || e.button !== 0) return;
          moving = false;
          window.widgetApi?.endMove();
          e.preventDefault();
        }, true);

        window.addEventListener('blur', () => {
          if (!moving) return;
          moving = false;
          window.widgetApi?.endMove();
        });
      }

      if (!window.__dwParticipantMenuBound) {
        window.__dwParticipantMenuBound = true;
        document.addEventListener('contextmenu', (e) => {
          const row = e.target?.closest?.('li.voice_state, .voice_state, [class*="Voice_voiceState"]');
          if (!row) return;

          const avatar = row.querySelector('img.voice_avatar, img[class*="Voice_avatar"], .voice_avatar');
          const nameEl = row.querySelector('.voice_name, .name, [class*="Voice_name"]');
          const participant = {
            name: String(nameEl?.textContent || row.textContent || 'Participante').trim().replace(/\s+/g, ' ').slice(0, 120),
            avatarUrl: String(avatar?.src || ''),
            rowClass: String(row.className || ''),
            rowText: String(row.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 240)
          };

          e.preventDefault();
          e.stopPropagation();
          window.widgetApi?.showParticipantMenu(participant);
        }, true);
      }
    })();
  `).catch(() => {});
  clearInterval(fitTimer);
  fitMiniToPeople();
  fitTimer = setInterval(fitMiniToPeople, 1000);
}

function loadContent() {
  const cfg = readConfig();
  if (validOverlayUrl(cfg.overlayUrl || '')) {
    win.loadURL(cfg.overlayUrl);
  } else {
    win.loadFile(path.join(__dirname, 'setup.html'));
  }
}

function createWindow() {
  const cfg = readConfig();
  manualResize = Boolean(cfg.manualSize);
  const width = Number(cfg.width) || 350;
  const height = Number(cfg.height) || 260;
  const pos = (Number.isFinite(cfg.x) && Number.isFinite(cfg.y)) ? {x:cfg.x,y:cfg.y} : positionForNewWindow(width,height);

  win = new BrowserWindow({
    ...pos,
    width, height,
    minWidth: 38,
    minHeight: 38,
    maxWidth: 900,
    maxHeight: 900,
    frame: false,
    transparent: true,
    resizable: true,
    thickFrame: true,
    alwaysOnTop: true,
    skipTaskbar: true,
    show: false,
    backgroundColor: '#00000000',
    title: 'Discord Voice Widget V2.1.1',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });
  win.setAlwaysOnTop(true, 'floating');
  win.setSkipTaskbar(true);
  win.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  if (!validOverlayUrl(cfg.overlayUrl || '')) win.center();
  win.once('ready-to-show', () => {
    win.show();
    win.restore();
    win.moveTop();
    win.focus();
  });

  win.webContents.on('did-finish-load', () => {
    const u = win.webContents.getURL();
    if (u.startsWith('https://streamkit.discord.com/overlay/voice/')) decorate();
  });

  loadContent();

  const remember = () => {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      if (!win || win.isDestroyed()) return;
      const b = win.getBounds();
      writeConfig({ x:b.x, y:b.y, width:b.width, height:b.height });
    }, 250);
  };
  win.on('move', remember);
  win.on('will-resize', () => {
    manualResize = true;
    clearInterval(fitTimer);
    writeConfig({ manualSize: true });
  });
  win.on('resize', remember);
}

function setClickThrough(next) {
  clickThrough = next;
  if (!win || win.isDestroyed()) return;
  win.setIgnoreMouseEvents(clickThrough, { forward: true });
  if (!clickThrough) win.focus();
}

const RPC_CONFIG = path.join(__dirname, 'rpc.config.json');

function readRpcConfig() {
  try { return JSON.parse(fs.readFileSync(RPC_CONFIG, 'utf8')); }
  catch { return {}; }
}

function participantMenuPayload(raw) {
  const p = raw && typeof raw === 'object' ? raw : {};
  const name = String(p.name || p.rowText || 'Participante').replace(/\s+/g, ' ').trim().slice(0, 80) || 'Participante';
  return {
    name,
    avatarUrl: String(p.avatarUrl || '').slice(0, 1000)
  };
}

function normalizeParticipantName(value) {
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function clampVoiceVolume(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return 100;
  return Math.max(0, Math.min(200, n));
}

// Curva perceptual em três zonas.
// 0–50 = ambiente/baixo (RPC 0–15), 50–100 = normal progressivo (15–100),
// 100–200 = ganho alto linear. O RPC individual só aceita inteiros 0–200.
function uiVolumeToRpc(value) {
  const ui = clampVoiceVolume(value);

  if (ui <= 1) return 0;

  if (ui <= 50) {
    const t = (ui - 2) / 48;
    return Math.max(1, Math.min(15, Math.round(1 + 14 * Math.pow(Math.max(0, t), 1.35))));
  }

  if (ui <= 100) {
    const t = (ui - 50) / 50;
    return Math.round(15 + 85 * Math.pow(t, 1.45));
  }

  return Math.round(ui);
}

function rpcVolumeToUi(value) {
  const rpc = clampVoiceVolume(value);

  if (rpc <= 0) return 1;

  if (rpc <= 15) {
    const t = Math.max(0, Math.min(1, (rpc - 1) / 14));
    return Math.max(2, Math.min(50, Math.round(2 + 48 * Math.pow(t, 1 / 1.35))));
  }

  if (rpc <= 100) {
    return Math.round(50 + 50 * Math.pow((rpc - 15) / 85, 1 / 1.45));
  }

  return Math.round(rpc);
}

function voiceStateToUiVolume(state) {
  if (!state) return 100;
  return rpcVolumeToUi(state.volume);
}

async function applyPerceivedUserVolume(userId, uiVolume) {
  const ui = Math.max(0, Math.min(200, Math.round(Number(uiVolume))));
  return await rpcClient.setUserVoiceSettings(userId, { volume: uiVolumeToRpc(ui) });
}

function matchVoiceState(participant, channel) {
  const states = channel && Array.isArray(channel.voice_states) ? channel.voice_states : [];
  if (!states.length) return null;

  const avatarUrl = String(participant.avatarUrl || '');
  for (const state of states) {
    const hash = state && state.user && state.user.avatar ? String(state.user.avatar) : '';
    if (hash && avatarUrl.includes(hash)) return state;
  }

  const wanted = normalizeParticipantName(participant.name);
  if (!wanted) return null;
  for (const state of states) {
    const candidates = [
      state && state.nick,
      state && state.user && state.user.global_name,
      state && state.user && state.user.username
    ].map(normalizeParticipantName).filter(Boolean);
    if (candidates.includes(wanted)) return state;
  }
  return null;
}

function openVolumeSlider(participant, state) {
  if (!state || !state.user || !state.user.id) return;

  if (volumeWin && !volumeWin.isDestroyed()) {
    try { volumeWin.close(); } catch {}
  }

  const width = 300;
  const height = 126;
  const cursor = screen.getCursorScreenPoint();
  const display = screen.getDisplayNearestPoint(cursor);
  const area = display.workArea;
  const x = Math.max(area.x, Math.min(cursor.x + 10, area.x + area.width - width));
  const y = Math.max(area.y, Math.min(cursor.y + 10, area.y + area.height - height));

  volumeWin = new BrowserWindow({
    width,
    height,
    x,
    y,
    frame: false,
    resizable: false,
    minimizable: false,
    maximizable: false,
    fullscreenable: false,
    skipTaskbar: true,
    alwaysOnTop: true,
    show: false,
    backgroundColor: '#1e1f22',
    webPreferences: {
      preload: path.join(__dirname, 'volume-preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });

  volumeWin.setAlwaysOnTop(true, 'floating');
  volumeWin.loadFile('volume.html', {
    query: {
      userId: String(state.user.id),
      name: String(participant.name || state.nick || state.user.global_name || state.user.username || 'Participante').slice(0, 80),
      volume: String(Number.isFinite(Number(state.volume)) ? voiceStateToUiVolume(state) : 100)
    }
  });

  volumeWin.once('ready-to-show', () => {
    if (!volumeWin || volumeWin.isDestroyed()) return;
    volumeWin.show();
    volumeWin.focus();
  });

  volumeWin.on('blur', () => {
    setTimeout(() => {
      if (volumeWin && !volumeWin.isDestroyed() && !volumeWin.isFocused()) {
        try { volumeWin.close(); } catch {}
      }
    }, 120);
  });

  volumeWin.on('closed', () => {
    volumeWin = null;
  });
}

function updaterStatusLabel() {
  const s = updaterState || {};
  if (s.status === 'ready' && s.ready) return 'Pronta: ' + s.ready.version;
  if (s.status === 'checking') return 'Verificando...';
  if (s.status === 'downloading') return 'Baixando atualização...';
  if (s.status === 'up_to_date') return 'Versão atualizada';
  if (s.status === 'error') return 'Erro: ' + String(s.message || 'falha').slice(0, 80);
  if (s.status === 'unconfigured') return 'Fonte ainda não configurada';
  if (s.status === 'disabled') return 'Atualizações desativadas';
  if (s.status === 'full_install_required') return 'Reinstalação completa necessária';
  return 'Atualizador pronto';
}

async function beginApplyUpdate() {
  if (!updateClient) return;
  try {
    const ready = updateClient.launchApply();
    updaterState = updateClient.getState();
    await dialog.showMessageBox(win, {
      type: 'info',
      title: 'Discord Voice Widget',
      message: 'Atualização ' + ready.version + ' será aplicada agora.',
      detail: 'O widget vai fechar por alguns segundos e voltar sozinho se o Discord estiver aberto.',
      buttons: ['OK'],
      defaultId: 0
    });
    setTimeout(() => app.quit(), 250);
  } catch (error) {
    await dialog.showMessageBox(win, {
      type: 'error',
      title: 'Falha na atualização',
      message: 'Não foi possível iniciar a atualização.',
      detail: error && error.message ? error.message : String(error),
      buttons: ['OK']
    });
  }
}

async function checkUpdatesInteractive() {
  if (!updateClient) return;
  const result = await updateClient.checkForUpdates({ download: true });
  updaterState = updateClient.getState();

  if (result.status === 'ready' && result.ready) {
    const response = await dialog.showMessageBox(win, {
      type: 'info',
      title: 'Atualização disponível',
      message: 'Discord Voice Widget ' + result.ready.version + ' está pronto.',
      detail: result.ready.notes || 'A atualização já foi baixada e validada.',
      buttons: ['Reiniciar e atualizar', 'Depois'],
      defaultId: 0,
      cancelId: 1
    });
    if (response.response === 0) await beginApplyUpdate();
    return;
  }

  if (result.status === 'up_to_date') {
    await dialog.showMessageBox(win, {
      type: 'info',
      title: 'Discord Voice Widget',
      message: 'Você já está na versão mais recente.',
      buttons: ['OK']
    });
    return;
  }

  if (result.status === 'unconfigured') {
    await dialog.showMessageBox(win, {
      type: 'info',
      title: 'Atualizações',
      message: 'A infraestrutura de atualização está instalada.',
      detail: 'A fonte pública de atualização ainda não foi configurada neste build.',
      buttons: ['OK']
    });
    return;
  }

  if (result.status === 'error' || result.status === 'full_install_required') {
    await dialog.showMessageBox(win, {
      type: 'warning',
      title: 'Atualizações',
      message: result.message || 'Não foi possível verificar atualizações.',
      buttons: ['OK']
    });
  }
}

function startUpdaterSchedule() {
  updateClient = new WidgetUpdater(__dirname, {
    onState: (state) => { updaterState = state; }
  });
  updaterState = updateClient.getState();

  const cfg = updateClient.getConfig();
  const minutes = Math.max(5, Number(cfg.checkIntervalMinutes) || 360);

  const silentCheck = async () => {
    try {
      if (!cfg.manifestUrl || cfg.enabled === false) return;
      await updateClient.checkForUpdates({ download: cfg.autoDownload !== false });
      updaterState = updateClient.getState();
    } catch {}
  };

  setTimeout(silentCheck, 15000);
  updaterTimer = setInterval(silentCheck, minutes * 60 * 1000);
}

async function showParticipantMenu(raw) {
  if (!win || win.isDestroyed()) return;
  const participant = participantMenuPayload(raw);

  let channel = null;
  let state = null;
  let rpcError = null;
  try {
    if (!rpcClient) throw new Error('RPC não iniciado.');
    channel = await rpcClient.getSelectedVoiceChannel();
    state = matchVoiceState(participant, channel);
  } catch (e) {
    rpcError = e && e.message ? e.message : 'RPC indisponível.';
  }

  const userId = state && state.user && state.user.id ? String(state.user.id) : '';
  const currentVolume = Number.isFinite(Number(state && state.volume)) ? voiceStateToUiVolume(state) : null;
  const currentMute = Boolean(state && state.mute);
  const canControl = Boolean(userId && rpcClient && rpcClient.authenticated);
  const layout = currentWidgetLayout();
  const readyUpdate = updateClient ? updateClient.getReadyUpdate() : null;
  const currentAppVersion = updateClient ? updateClient.getCurrentVersion() : '2.1.1';

  const setMute = (mute) => {
    if (!canControl) return;
    rpcClient.setUserVoiceSettings(userId, { mute }).catch(() => {});
  };

  const template = [
    { label: participant.name, enabled: false },
    {
      label: state
        ? ('RPC identificado • ' + (state.nick || state.user?.global_name || state.user?.username || 'usuário'))
        : (rpcError ? 'RPC indisponível' : 'Participante não identificado no RPC'),
      enabled: false
    },
    { type: 'separator' },
    {
      label: currentVolume === null
        ? 'Ajustar volume…'
        : ('Ajustar volume… • atual ' + currentVolume + '%'),
      enabled: canControl,
      click: () => openVolumeSlider(participant, state)
    },
    {
      label: currentMute ? 'Desmutar somente para mim' : 'Mutar somente para mim',
      enabled: canControl,
      click: () => setMute(!currentMute)
    },
    { type: 'separator' },
    {
      label: 'Orientação',
      submenu: [
        {
          label: 'Vertical',
          type: 'radio',
          checked: layout === 'vertical',
          click: () => setWidgetLayout('vertical')
        },
        {
          label: 'Horizontal',
          type: 'radio',
          checked: layout === 'horizontal',
          click: () => setWidgetLayout('horizontal')
        }
      ]
    },

    { type: 'separator' },
    {
      label: 'Atualizações',
      submenu: [
        {
          label: 'Versão ' + currentAppVersion,
          enabled: false
        },
        {
          label: 'Verificar atualizações',
          enabled: !['checking','downloading','applying'].includes(updaterState.status),
          click: () => checkUpdatesInteractive()
        },
        {
          label: readyUpdate ? ('Reiniciar e atualizar para ' + readyUpdate.version) : 'Nenhuma atualização pronta',
          enabled: Boolean(readyUpdate),
          click: () => beginApplyUpdate()
        },
        {
          label: updaterStatusLabel(),
          enabled: false
        }
      ]
    },
    {
      label: 'Copiar nome',
      click: () => clipboard.writeText(participant.name)
    },
    {
      label: canControl ? 'V2.1.1 DEV • RPC conectado' : 'V2.1.1 DEV • controle RPC indisponível',
      enabled: false
    }
  ];

  Menu.buildFromTemplate(template).popup({ window: win });
}

app.whenReady().then(() => {
  createWindow();
  startUpdaterSchedule();

  const rpcCfg = readRpcConfig();
  rpcClient = new DiscordRpcClient(__dirname, {
    clientId: rpcCfg.clientId,
    redirectUri: rpcCfg.redirectUri,
    scopes: rpcCfg.scopes
  });

  rpcClient.ensureAuthenticated({ interactive: true }).then(() => {
    try {
      const next = { ...readRpcConfig(), authorized: true };
      fs.writeFileSync(RPC_CONFIG, JSON.stringify(next, null, 2), 'utf8');
    } catch {}
  }).catch(() => {
    try {
      const next = { ...readRpcConfig(), authorized: false };
      fs.writeFileSync(RPC_CONFIG, JSON.stringify(next, null, 2), 'utf8');
    } catch {}
  });

  const toggleVisibility = () => {
    if (!win) return;
    if (win.isVisible()) win.hide(); else { win.show(); win.restore(); win.moveTop(); win.focus(); win.setAlwaysOnTop(true, 'floating'); }
  };
  const toggleClickThrough = () => setClickThrough(!clickThrough);
  const toggleLayout = () => setWidgetLayout(currentWidgetLayout() === 'horizontal' ? 'vertical' : 'horizontal');

  globalShortcut.register('CommandOrControl+Alt+F9', toggleVisibility);
  globalShortcut.register('CommandOrControl+Alt+F10', toggleClickThrough);
  globalShortcut.register('CommandOrControl+Alt+F11', toggleLayout);

  // Atalhos DEV antigos mantidos como reserva.
  globalShortcut.register('CommandOrControl+Alt+F7', toggleVisibility);
  globalShortcut.register('CommandOrControl+Alt+F8', toggleClickThrough);
});

ipcMain.handle('save-url', (event, url) => {
  if (!event.senderFrame.url.startsWith('file://')) return { ok:false, error:'Origem inválida' };
  const value = String(url || '').trim();
  if (!validOverlayUrl(value)) return { ok:false, error:'Cole o link do Voice Widget do StreamKit.' };
  writeConfig({ overlayUrl:value });
  loadContent();
  return { ok:true };
});
ipcMain.handle('get-clipboard', (event) => {
  if (!event.senderFrame.url.startsWith('file://')) return '';
  return clipboard.readText();
});
ipcMain.handle('open-streamkit', (event) => {
  if (!event.senderFrame.url.startsWith('file://')) return false;
  shell.openExternal('https://streamkit.discord.com/overlay');
  return true;
});

function voiceFrame(event) {
  return Boolean(event.senderFrame && event.senderFrame.url.startsWith('https://streamkit.discord.com/overlay/voice/'));
}

function volumeFrame(event) {
  const url = event.senderFrame && event.senderFrame.url ? event.senderFrame.url : '';
  return url.startsWith('file://') && url.includes('/volume.html');
}

ipcMain.on('dw-participant-menu', (event, participant) => {
  if (!voiceFrame(event)) return;
  showParticipantMenu(participant);
});

ipcMain.handle('dw-volume-set', async (event, payload) => {
  if (!volumeFrame(event)) return { ok: false, error: 'Origem inválida.' };
  if (!rpcClient) return { ok: false, error: 'RPC indisponível.' };

  const userId = String(payload && payload.userId || '');
  const uiVolume = Math.round(Number(payload && payload.volume));
  if (!/^\d{10,24}$/.test(userId)) return { ok: false, error: 'Usuário inválido.' };
  if (!Number.isFinite(uiVolume) || uiVolume < 0 || uiVolume > 200) return { ok: false, error: 'Volume inválido.' };

  try {
    await applyPerceivedUserVolume(userId, uiVolume);
    return { ok: true, volume: uiVolume };
  } catch (e) {
    return { ok: false, error: e && e.message ? e.message : 'Falha ao alterar volume.' };
  }
});

ipcMain.on('dw-volume-close', (event) => {
  if (!volumeFrame(event)) return;
  if (volumeWin && !volumeWin.isDestroyed()) {
    try { volumeWin.close(); } catch {}
  }
});

ipcMain.on('dw-move-begin', (event, point) => {
  if (!voiceFrame(event) || !win || win.isDestroyed()) return;
  const x = Number(point && point.x);
  const y = Number(point && point.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return;
  moveOrigin = { x, y, bounds: win.getBounds() };
});

ipcMain.on('dw-move-move', (event, point) => {
  if (!voiceFrame(event) || !moveOrigin || !win || win.isDestroyed()) return;
  const x = Number(point && point.x);
  const y = Number(point && point.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return;

  win.setBounds({
    x: Math.round(moveOrigin.bounds.x + (x - moveOrigin.x)),
    y: Math.round(moveOrigin.bounds.y + (y - moveOrigin.y)),
    width: moveOrigin.bounds.width,
    height: moveOrigin.bounds.height
  });
});

ipcMain.on('dw-move-end', (event) => {
  if (!voiceFrame(event)) return;
  moveOrigin = null;
  if (!win || win.isDestroyed()) return;
  const b = win.getBounds();
  writeConfig({ x:b.x, y:b.y, width:b.width, height:b.height });
});

ipcMain.on('dw-resize-begin', (event, point) => {
  if (!voiceFrame(event) || !win || win.isDestroyed()) return;
  const x = Number(point && point.x);
  const y = Number(point && point.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return;
  manualResize = true;
  clearInterval(fitTimer);
  resizeOrigin = { x, y, bounds: win.getBounds() };
  writeConfig({ manualSize: true });
});

ipcMain.on('dw-resize-move', (event, point) => {
  if (!voiceFrame(event) || !resizeOrigin || !win || win.isDestroyed()) return;
  const x = Number(point && point.x);
  const y = Number(point && point.y);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return;
  const layout = currentWidgetLayout();
  const readyUpdate = updateClient ? updateClient.getReadyUpdate() : null;
  const currentAppVersion = updateClient ? updateClient.getCurrentVersion() : '2.1.1';
  const maxWidth = layout === 'horizontal' ? 900 : 90;
  const maxHeight = layout === 'horizontal' ? 90 : 900;
  const width = Math.max(38, Math.min(maxWidth, resizeOrigin.bounds.width + (x - resizeOrigin.x)));
  const height = Math.max(38, Math.min(maxHeight, resizeOrigin.bounds.height + (y - resizeOrigin.y)));
  win.setBounds({
    x: resizeOrigin.bounds.x,
    y: resizeOrigin.bounds.y,
    width: Math.round(width),
    height: Math.round(height)
  });
});

ipcMain.on('dw-resize-end', (event) => {
  if (!voiceFrame(event)) return;
  resizeOrigin = null;
  if (!win || win.isDestroyed()) return;
  const b = win.getBounds();
  writeConfig({ x:b.x, y:b.y, width:b.width, height:b.height, manualSize:true });
});

app.on('will-quit', () => {
  try { if (updaterTimer) clearInterval(updaterTimer); } catch {}
  try { rpcClient?.close(); } catch {}
  globalShortcut.unregisterAll();
});
app.on('window-all-closed', () => app.quit());
